# Auditoría final — DATA-04, DATA-05 y DATA-06

**Veredicto: aprobado para entregar el módulo de Datos 1.0.0, con dos observaciones históricas no bloqueantes.** Los **26 puntos de checklist** se encuentran implementados. Los **11 criterios de aceptación** se verifican en los artefactos, adaptadores y aplicación de referencia incluidos, con los límites de integración y de política futura descritos abajo.

Auditoría: 22 de octubre de 2026, America/Monterrey. Se auditó el ZIP final `Ine-hacktoon-DATA-06-v1.0.0.zip`, SHA-256 `1799bba4821927f92e649e27d190adbdde8c5d84859f5e3c3309159e6d035545`. Ese snapshot contenía **190 archivos**. La revisión documental posterior amplió `README.md` y actualizó `DELIVERY-MANIFEST.json`: los otros **188 archivos** conservan sus bytes. El inventario interno comprueba 189 archivos más el propio manifiesto. Los 13 artefactos y 14 archivos de contratos congelados permanecen intactos; los documentos generales de esta auditoría están fuera del módulo.

## Comprobaciones ejecutadas nuevamente

Se extrajo el ZIP en una carpeta nueva y se instalaron ocho dependencias desde una caché npm, con `npm ci --offline --ignore-scripts --no-audit --no-fund`. `npm run ccpc:check` terminó satisfactoriamente: TypeScript, **149 pruebas aprobadas, 0 fallos y 0 omitidas**, validaciones DATA-04/05, release 1.0.0 y privacidad. `ccpc:verify-delivery` verificó los 189 archivos del inventario por tamaño y SHA-256. Runtime probado: Node.js 26.7.0 y Python 3.14.7.

La revisión independiente reconstruyó la cobertura desde el compacto sin importar el ETL: **31,104 posiciones**, **20,755 observadas**, **10,349 ausentes** y **77,760 comparaciones atómicas**, de las que 51,749 son válidas y 26,011 inválidas. Coinciden matriz, CSV y catálogo. Se ejecutaron **192 resúmenes entidad/año** del servicio congelado y se recalcularon independientemente sus indicadores oficiales. Se consultaron además **las 10,349 selecciones ausentes**: todas devolvieron `no_data`, `result: null` y cero sugerencias de onboarding.

Se ejecutó nuevamente el regenerador distribuido sobre una extracción nueva: los cinco archivos del release son idénticos byte a byte. Una prueba HTTP adicional, iniciada desde `/tmp` en puerto local temporal, comprobó las cuatro consultas, dos escenarios `no_data`, un cero observado, siete sugerencias respondibles, igualdad del catálogo, nueve advertencias y respuestas HTTP iguales al servicio en memoria.

Evidencias: [checks.log](evidencias/checks.log), [inventario](evidencias/zip-audit.json), [cobertura independiente](evidencias/requirements/independent-requirements.json), [consultas independientes](evidencias/requirements/runtime-requirements.json), [regeneración](evidencias/freeze/freeze-reproduction.json) y [HTTP](evidencias/handoff/http-smoke.json).

## DATA-04 — 8/8

| Punto solicitado | Resultado |
| --- | --- |
| Procesar 2009, 2012, 2015, 2018, 2021 y 2024 | PASS: los seis cortes están presentes. |
| Incluir las 32 entidades | PASS: 32 claves INE en cada año, 192 fuentes. |
| Conservar sexo, grupo de edad y tipo de sección | PASS: dimensiones presentes; 18 bandas de edad y tres tipos de sección. |
| Generar JSON optimizado, SQLite o ambos | PASS: compacto JSON de 850,227 bytes. SQLite no es necesario porque se solicitó una alternativa. |
| Diferenciar claramente sample y full | PASS: rutas, etiquetas, cargadores y comandos diferenciados; la entrada final utiliza full. |
| Incluir versión, fecha, hash y procedencia | PASS: manifiestos históricos y release final 1.0.0, fuente INE y hashes fijados. |
| No subir los 54 millones de registros originales | PASS: el ZIP contiene agregados y documentación; no originales, ZIP INE ni dependencias. |
| Ejecutar las cuatro consultas sobre el agregado | PASS: resumen, desglose, comparación y registros de respaldo funcionan en módulo y HTTP. |

**Criterios de aceptación:** seis años y 32 entidades consultables; cuatro consultas operativas; participación y abstención oficiales con **SV+NV**; consumo por el backend sin modificar ni ejecutar el ETL. Todos se verifican en el módulo entregado. Los campos oficiales son `ccpcParticipationPct` y `ccpcAbstentionPct`; los campos heredados sobre LN conservan su significado.

La revisión anterior de originales leyó 54,872,712 filas y 192 CSV con una implementación independiente. Esta auditoría final **no volvió a releer esos originales**: conserva esa [evidencia histórica](evidencias/historico-DATA04/comparacion-originales.json) y comprueba que el compacto y los registros auditados mantienen sus hashes. Los conteos de origen representados siguen siendo 54,872,712.

## DATA-05 — 9/9

| Punto solicitado | Resultado |
| --- | --- |
| Enumerar años disponibles | PASS: los seis años se declaran en el catálogo. |
| Enumerar entidades y claves INE | PASS: 32 claves de dos dígitos, con nombres e historia de etiquetas. |
| Registrar categorías de sexo por año | PASS: hombre/mujer en todos; no_binario únicamente en 2024. |
| Registrar grupos de edad | PASS: 18 grupos, de 18–19 a 100+. |
| Registrar tipos de sección | PASS: urbana, mixta y rural. |
| Identificar combinaciones sin registros | PASS: matriz exacta y CSV con las 10,349 ausencias. |
| Identificar comparaciones inválidas | PASS: reglas y CSV de 15 parejas; verificación independiente de 77,760 selecciones atómicas. |
| Documentar preguntas fuera del alcance de CCPC | PASS: nueve categorías con razones explícitas. |
| Exportar catálogo de capacidades en JSON | PASS: `ccpc-capabilities/v1`, compartido por cliente y backend. |

**Criterios de aceptación:** frontend y backend de referencia consumen el mismo catálogo; onboarding filtra cada sugerencia por cobertura; las combinaciones inexistentes producen `no_data` sin cifras. Todos se verifican en el contrato y la aplicación incluidos. El cero observado permanece como dato válido. Las categorías solicitadas no se descartan silenciosamente para generar una comparación parcial.

## DATA-06 — 9/9

| Punto solicitado | Resultado |
| --- | --- |
| Etiquetar dataset como 1.0.0 | PASS: manifiesto, diccionario, metadatos y respuestas declaran 1.0.0. |
| Calcular SHA-256 | PASS: pin externo, 13 artefactos y 14 archivos bloqueados; checksums de release e inventarios. |
| Actualizar diccionario | PASS: 21 campos normalizados y nueve columnas compactas, dominios, unidades y fórmulas. |
| Registrar fuente oficial | PASS: INE, manual, seis URLs de archivo, hashes y adquisiciones. |
| Registrar fecha de extracción | PASS: día UTC 2026-10-22, precisión explícita y fechas originales preservadas; no se inventa una hora exacta de extracción de filas. |
| Documentar limitaciones | PASS: advertencias frontend y guías de cobertura, metodología y privacidad. |
| Conservar script de regeneración | PASS: regeneración a staging externo y comparación exacta de cinco archivos; ETL histórico conservado. |
| Guardar resultados de validación | PASS: informes de esta auditoría más evidencias por cada etapa. |
| Confirmar que no hay datos personales directos | PASS: 16 archivos revisados; no se detectaron identificadores personales directos. Persisten celdas pequeñas documentadas. |

**Criterios de aceptación:**

1. **Esquema congelado:** la versión queda fijada antes del 26 de octubre de 2026, America/Monterrey. El mecanismo rechaza deriva con independencia del reloj; cualquier modificación requiere otra versión. Se verifica la política implementada, no decisiones humanas futuras fuera del paquete.
2. **Integridad al iniciar:** `createFrozenParticipationService()` verifica el release y los archivos antes de crear las consultas. El servidor de referencia espera ese arranque antes de escuchar.
3. **Metadatos frontend:** el snapshot verificado sirve fuente, metodología, extracción, versión y nueve advertencias mediante `GET /api/dataset`.
4. **Reproducción:** el regenerador publicado produce los cinco archivos idénticos, preservando el pin `5992059695eac4920cf959b1589114d4327e149f237c467c7574d75c4d51d2e4`.

## Observaciones que se conservan

No se identificaron bloqueantes del flujo final. Permanecen dos debilidades de herramientas históricas DATA-04: su auditor Python aislado admite estructuras que el cargador final rechaza, y su constructor histórico acepta algunas fechas de calendario imposibles. La entrada congelada y el auditor DATA-06 comprueban los bytes fijados y rechazan esas alteraciones. No deben sustituirse por esas herramientas aisladas la cadena `ccpc:check` o la entrada `createFrozenParticipationService()`.

No se modificaron los archivos congelados para corregir herramientas históricas durante esta auditoría. El mínimo Python ≥3.10 ya figura en las instrucciones. Los límites de privacidad también permanecen explícitos: 54 celdas full con LN=1 y 124 con LN entre 1 y 4; ausencia de identificadores directos no significa anonimato absoluto.

## Qué falta para que funcione dentro del proyecto del equipo

La entrega de Datos está lista. **La conexión y el despliegue en los repositorios reales de frontend y backend no fueron ejecutados**, porque no se proporcionaron esas aplicaciones. La guía [INTEGRACION.md](INTEGRACION.md) especifica cómo incorporar la carpeta completa, esperar el arranque verificado, servir los cuatro endpoints de referencia y conectar catálogo, metadatos y consultas al frontend.

Entrega el ZIP consolidado completo y su checksum. Conserva `.gitattributes`, las rutas y bytes interiores; no reformatees el módulo congelado. Ejecuta la comprobación de integración en el repositorio del equipo después de conectar las rutas. La auditoría se realizó antes de la publicación en GitHub. La revisión documental posterior prepara este ZIP versionado, su checksum y el README para la rama `Data`; no crea una etiqueta Git ni un release en la sección Releases.

## Revisión documental para la publicación

Se amplió el README con el proceso DATA-04/05/06, su cumplimiento y las instrucciones de uso. Se actualizaron los inventarios de distribución y el ZIP. Los pins de datos y release permanecen idénticos; la validación de integridad se repite para esta revisión documental. Los reportes de la auditoría anterior conservan el nombre y hash del snapshot que auditaron.

Evidencia de esta revisión: [`release-verification.json`](evidencias/documentation-revision/release-verification.json) e [`independent-release-audit.json`](evidencias/documentation-revision/independent-release-audit.json), ambos con `status: pass`, 13 artefactos y 14 archivos bloqueados. La comparación con el ZIP DATA-06 original confirma 188 archivos idénticos y sólo dos cambios documentales: README e inventario.
