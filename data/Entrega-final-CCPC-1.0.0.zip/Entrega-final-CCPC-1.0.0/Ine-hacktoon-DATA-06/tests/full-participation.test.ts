import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import {
  electionComparisonSchema, participationBreakdownSchema, participationSummarySchema, supportingRecordsSchema,
} from '../src/application/ports/participation-data.ts';
import { calculateMetrics } from '../src/domain/civic/participation.ts';
import {
  createFullParticipationService, decodeCompactDataset, loadFullParticipationDataset,
} from '../src/data/full-participation.ts';
import { CCPC_FULL_FILE_SHA256, CCPC_FULL_RECORDS_SHA256 } from '../src/data/ccpc-release.ts';

const artifact = new URL('../data/ccpc/full/participation.compact.json', import.meta.url);
const bytes = await readFile(artifact);
type CompactInput = {
  schemaVersion: string; kind: string; scope: string; years: number[];
  metricDefinitions: Record<string, string>;
  dictionaries: { sex: string[]; ageGroup: string[]; sectionType: string[] };
  sources: Array<Record<string, unknown>>; sourceEntityNames: string[]; columns: string[];
  records: number[][]; recordsSha256: string;
};
const compact = JSON.parse(bytes.toString('utf8')) as CompactInput;
const dataset = await loadFullParticipationDataset();
const service = await createFullParticipationService();
const copy = () => structuredClone(compact);
const digest = (input: string | Buffer) => createHash('sha256').update(input).digest('hex');
function canonicalJson(input: unknown): string {
  const canonical = (value: unknown): unknown => {
    if (Array.isArray(value)) return value.map(canonical);
    if (value !== null && typeof value === 'object') return Object.fromEntries(Object.entries(value)
      .sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, child]) => [key, canonical(child)]));
    return value;
  };
  return JSON.stringify(canonical(input), null, 2) + '\n';
}

test('portable full artifact is externally pinned and rehydrates all six years and original records', () => {
  assert.equal(digest(bytes), CCPC_FULL_FILE_SHA256);
  assert.equal(digest(canonicalJson(dataset.records)), CCPC_FULL_RECORDS_SHA256);
  assert.equal(dataset.kind, 'full');
  assert.deepEqual(dataset.years, [2009, 2012, 2015, 2018, 2021, 2024]);
  assert.equal(dataset.sources.length, 192);
  assert.equal(dataset.records.length, 20_755);
  for (const year of dataset.years) {
    const sources = dataset.sources.filter(source => source.year === year);
    assert.equal(sources.length, 32);
    assert.equal(new Set(sources.map(source => source.entityCode)).size, 32);
  }
  assert.equal(dataset.sources.reduce((sum, source) => sum + source.rawRows, 0), 54_872_712);
});

test('loader rejects a corrupt copied file and a missing file without sample fallback', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'ccpc-portable-'));
  try {
    const path = join(directory, 'participation.compact.json');
    await writeFile(path, Buffer.concat([bytes, Buffer.from('\n')]));
    await assert.rejects(loadFullParticipationDataset(path), /FULL_FILE_HASH_MISMATCH/);
    await assert.rejects(loadFullParticipationDataset(join(directory, 'missing.json')), /FULL_DATASET_NOT_FOUND/);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test('decoder rejects a sample label, sample disguised as full, missing years and missing sources', () => {
  const sample = copy(); sample.kind = 'sample';
  assert.throws(() => decodeCompactDataset(sample), /INVALID_COMPACT_SCHEMA/);
  const disguised = copy(); disguised.records = disguised.records.slice(0, 150);
  assert.throws(() => decodeCompactDataset(disguised), /FULL_DATASET_COVERAGE/);
  const partial = copy(); partial.years = [2024];
  assert.throws(() => decodeCompactDataset(partial), /INVALID_COMPACT_SCHEMA/);
  const missingSource = copy(); missingSource.sources.pop();
  assert.throws(() => decodeCompactDataset(missingSource), /FULL_DATASET_COVERAGE/);
  const duplicateSource = copy(); duplicateSource.sources[1] = structuredClone(duplicateSource.sources[0]);
  assert.throws(() => decodeCompactDataset(duplicateSource), /DUPLICATE_SOURCE|ENTITY_NAME_MISMATCH/);
});

test('decoder rejects altered dictionaries, column order, dimensions and extra fields', () => {
  const dictionary = copy(); dictionary.dictionaries.sex.reverse();
  assert.throws(() => decodeCompactDataset(dictionary), /INVALID_COMPACT_SCHEMA/);
  const columns = copy(); [columns.columns[0], columns.columns[1]] = [columns.columns[1], columns.columns[0]];
  assert.throws(() => decodeCompactDataset(columns), /INVALID_COMPACT_SCHEMA/);
  const denominator = copy(); denominator.metricDefinitions.ccpcDenominator = 'nominalList';
  assert.throws(() => decodeCompactDataset(denominator), /INVALID_METRIC_DEFINITION/);
  assert.throws(() => decodeCompactDataset({ ...compact, municipality: '001' }), /INVALID_COMPACT_SCHEMA/);
});

test('decoder rejects noninteger, unsafe, negative and out of range tuple indexes', () => {
  for (const invalid of [-1, 0.5, Number.MAX_SAFE_INTEGER + 1, NaN, Infinity]) {
    const changed = copy(); changed.records[0][0] = invalid;
    assert.throws(() => decodeCompactDataset(changed), /INVALID_COMPACT_INDEX/);
  }
  for (const [column, invalid] of [[0, 192], [1, 3], [2, 18], [3, 3]]) {
    const changed = copy(); changed.records[0][column] = invalid;
    assert.throws(() => decodeCompactDataset(changed), /INVALID_COMPACT_INDEX/);
  }
  const shortTuple = copy(); shortTuple.records[0].pop();
  assert.throws(() => decodeCompactDataset(shortTuple), /INVALID_COMPACT_TUPLE/);
});

test('decoder rejects count changes even if source totals are conserved and the embedded hash is recomputed', () => {
  const changed = copy();
  const first = changed.records.findIndex(row => row[5] > 0 && row[6] > 0);
  const second = changed.records.findIndex((row, i) => i !== first && row[0] === changed.records[first][0] && row[5] > 0 && row[6] > 0);
  assert.ok(first >= 0 && second >= 0);
  changed.records[first][5]++; changed.records[first][6]--;
  changed.records[second][5]--; changed.records[second][6]++;
  const forgedRecords = structuredClone(dataset.records);
  for (const i of [first, second]) {
    forgedRecords[i].voted = changed.records[i][5];
    forgedRecords[i].didNotVote = changed.records[i][6];
    Object.assign(forgedRecords[i], calculateMetrics(forgedRecords[i]));
  }
  changed.recordsSha256 = digest(canonicalJson(forgedRecords));
  assert.notEqual(changed.recordsSha256, CCPC_FULL_RECORDS_SHA256);
  assert.throws(() => decodeCompactDataset(changed), /FULL_RECORDS_HASH_MISMATCH/);
});

test('full national 2024 summary preserves official counts and both distinct denominators', () => {
  const result = participationSummarySchema.parse(service.getParticipationSummary({ year: 2024 }));
  const totals = result.totals!;
  assert.equal(result.status, 'ok');
  assert.deepEqual([totals.nominalList, totals.voted, totals.didNotVote, totals.unspecified],
    [98_330_348, 54_899_228, 37_105_466, 6_325_654]);
  assert.equal(totals.participationRate, 54_899_228 / 98_330_348);
  assert.equal(totals.participationPct, (54_899_228 / 98_330_348) * 100);
  assert.equal(totals.ccpcParticipationPct, (54_899_228 / (54_899_228 + 37_105_466)) * 100);
  assert.equal(totals.ccpcAbstentionPct, (37_105_466 / (54_899_228 + 37_105_466)) * 100);
  assert.equal(totals.unspecifiedPct, (6_325_654 / 98_330_348) * 100);
  assert.notEqual(totals.participationPct, totals.ccpcParticipationPct);
  assert.equal(result.evidence.matchedRecords, 3503);
  assert.equal(result.evidence.matchedSourceRows, 9_773_730);
  assert.equal(result.evidence.sources.length, 32);
  assert.equal(result.evidence.dataset.kind, 'full');
  assert.equal(result.evidence.dataset.validation, 'runtime_schema');
  assert.ok(result.warnings.some(warning => warning.code === 'NS_EXCLUDED_FROM_CCPC'));
  assert.ok(!result.warnings.some(warning => warning.code === 'SAMPLE_DATA'));
});

test('portable full dataset satisfies the unchanged four query contracts and evidence', () => {
  const filters = { year: 2024, entityCodes: ['01'], sexes: ['hombre'], ageGroups: ['18-19'], sectionTypes: ['urbana'] } as const;
  const summary = participationSummarySchema.parse(service.getParticipationSummary(filters));
  const support = supportingRecordsSchema.parse(service.getSupportingRecords(filters));
  assert.deepEqual([summary.totals!.nominalList, summary.totals!.voted, summary.totals!.didNotVote, summary.totals!.unspecified],
    [14_908, 7288, 7297, 323]);
  assert.equal(support.records.length, 1);
  assert.equal(support.records[0].sourceRows, 1025);
  assert.equal(support.evidence.recordsSha256, summary.evidence.recordsSha256);
  assert.equal(support.evidence.dataset.recordsSha256, CCPC_FULL_RECORDS_SHA256);
  const comparison = electionComparisonSchema.parse(service.compareElections({}, [2024, 2018]));
  assert.deepEqual(comparison.years, [2018, 2024]);
  assert.equal(comparison.changes[0].participationPercentagePoints, -2.272347980101898);
  assert.equal(comparison.changes[0].ccpcParticipationPercentagePoints, -2.695073969880262);
  const breakdown = participationBreakdownSchema.parse(service.getParticipationBreakdown({ year: 2024 }, 'sex'));
  assert.deepEqual(breakdown.groups.map(group => group.value), ['hombre', 'mujer', 'no_binario']);
  assert.equal(breakdown.groups.reduce((sum, group) => sum + group.summary.totals!.nominalList, 0), 98_330_348);
  const missing = service.getParticipationSummary({ year: 2018, sexes: ['no_binario'] });
  assert.equal(missing.status, 'no_data');
  assert.equal(missing.totals, null);
  assert.ok(missing.warnings.some(warning => warning.code === 'NON_BINARY_UNAVAILABLE'));
});
