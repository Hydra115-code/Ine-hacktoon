import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import { createCatalogClient, validateCapabilitiesCatalog, COVERAGE_QUERIES } from '../src/client/coverage-client.ts';
import type { CapabilitiesCatalog, CoverageRequest } from '../src/client/coverage-client.ts';

/** Hand-defined sparse fixture, independent from the production catalogue builder. */
function fixture(): CapabilitiesCatalog {
  // year, entity, sex, age, section: 2*2*2*2*2 = 32 cells.
  // 2021: entity01/hombre/18-19/urbana; entity02/hombre/20-24/rural.
  // 2024 adds non-binary in entity01 and a zero-denominator cell in entity02.
  const cells = Array<string>(32).fill('0');
  for (const [index, status] of [[0, '2'], [11, '2'], [16, '2'], [20, '2'], [27, '1']] as const) cells[index] = status;
  return {
    schemaVersion: 'ccpc-capabilities/v1', catalogVersion: '1.0.0', generatedAt: '2026-10-22T01:00:00Z',
    dataset: { kind: 'full', schemaVersion: 'ccpc-participation/v1', fileSha256: 'a'.repeat(64), recordsSha256: 'b'.repeat(64), recordCount: 5, sourceCount: 4 },
    dimensions: {
      years: [2021, 2024], entities: [
        { code: '01', name: 'Aguascalientes', namesByYear: { '2021': 'Aguascalientes', '2024': 'Aguascalientes' } },
        { code: '02', name: 'Baja California', namesByYear: { '2021': 'Baja California', '2024': 'Baja California' } },
      ], sexes: ['hombre', 'no_binario'], sexesByYear: { '2021': ['hombre'], '2024': ['hombre', 'no_binario'] },
      ageGroups: ['18-19', '20-24'], sectionTypes: ['urbana', 'rural'],
    },
    matrix: { axes: ['year', 'entityCode', 'sex', 'ageGroup', 'sectionType'], shape: [2, 2, 2, 2, 2],
      encoding: { '0': 'no_records', '1': 'records_without_official_denominator', '2': 'records_with_official_denominator' },
      cells: cells.join(''), statistics: { possible: 32, observed: 5, missing: 27, zeroDenominator: 1 } },
    queries: [...COVERAGE_QUERIES], breakdownDimensions: ['entity', 'year', 'sex', 'ageGroup', 'sectionType'], defaultYear: 2024,
    metricDefinitions: { participation: { field: 'ccpcParticipationPct', denominator: 'voted+didNotVote', unit: 'percent' },
      abstention: { field: 'ccpcAbstentionPct', denominator: 'voted+didNotVote', unit: 'percent' }, zeroDenominator: 'null' },
    comparisonPolicy: { minimumYears: 2, maximumYears: 6, requireDataInEveryYear: true, requireExplicitCategoriesInEveryYear: true,
      missingCells: 'never_impute', warnings: ['ELECTIONS_NOT_A_PANEL'] },
    outOfScope: [{ id: 'party', question: '¿Por qué partido votaron?', reason: 'CCPC no contiene preferencias partidarias.' }],
    questionTemplates: [
      { id: 'summary', title: '¿Cuál es la participación?', query: 'getParticipationSummary' },
      { id: 'sex', title: '¿Cómo cambia por sexo?', query: 'getParticipationBreakdown', dimension: 'sex' },
      { id: 'comparison', title: '¿Qué cambió desde la elección anterior?', query: 'compareElections' },
      { id: 'evidence', title: '¿Qué registros respaldan la respuesta?', query: 'getSupportingRecords' },
    ],
  };
}
test('catalogue defensive snapshot cannot be changed by its caller or getCatalog consumer', () => {
  const source = fixture(), client = createCatalogClient(source);
  source.matrix.cells = '0'.repeat(32); source.dimensions.years[0] = 2000;
  assert.equal(client.getCatalog().matrix.statistics.observed, 5);
  assert.deepEqual(client.getCatalog().dimensions.years, [2021, 2024]);
  assert.throws(() => client.getCatalog().dimensions.years.push(2027), TypeError);
  assert.throws(() => { client.getCatalog().dimensions.entities[0].namesByYear['2024'] = 'Inventado'; }, TypeError);
});
test('catalogue rejects unknown fields, false statistics, wrong axes and false availability', () => {
  const invalid: unknown[] = [{ ...fixture(), extra: true }];
  const statistic = fixture(); statistic.matrix.statistics.observed = 4; invalid.push(statistic);
  const shape = fixture(); shape.matrix.shape[0] = 3; invalid.push(shape);
  const sex = fixture(); sex.dimensions.sexesByYear['2021'].push('no_binario'); invalid.push(sex);
  const hash = fixture(); hash.dataset.fileSha256 = 'bad'; invalid.push(hash);
  const denominator = fixture(); (denominator.metricDefinitions.participation as { denominator: string }).denominator = 'nominalList'; invalid.push(denominator);
  const date = fixture(); date.generatedAt = '2026-02-30T01:00:00Z'; invalid.push(date);
  const duplicate = fixture(); duplicate.dimensions.entities[1].code = '01'; invalid.push(duplicate);
  const sparse = fixture(); delete sparse.matrix.shape[0]; invalid.push(sparse);
  for (const value of invalid) assert.throws(() => validateCapabilitiesCatalog(value), /INVALID_CAPABILITIES_CATALOG/);
});
test('all four canonical methods can consult observed categories', () => {
  const client = createCatalogClient(fixture());
  const requests: CoverageRequest[] = [
    { query: 'getParticipationSummary', filters: { year: 2024, entityCodes: ['01'] } },
    { query: 'getParticipationBreakdown', filters: { year: 2024, entityCodes: ['01'] }, dimension: 'sex' },
    { query: 'compareElections', filters: { entityCodes: ['01'], sexes: ['hombre'] }, years: [2024, 2021] },
    { query: 'getSupportingRecords', filters: { year: 2024, entityCodes: ['01'] } },
  ];
  for (const request of requests) assert.equal(client.evaluate(request).status, 'ok');
  assert.deepEqual(client.evaluate(requests[2]).request?.years, [2021, 2024]);
});
test('missing cross-cell returns no_data and zero measured records, not a numeric answer', () => {
  const result = createCatalogClient(fixture()).evaluate({ query: 'getParticipationSummary', filters: {
    year: 2024, entityCodes: ['01'], sexes: ['hombre'], ageGroups: ['20-24'], sectionTypes: ['rural'],
  } });
  assert.equal(result.status, 'no_data'); assert.equal(result.reason, 'no_matching_records');
  assert.equal(result.matchedCells, 0); assert.equal(result.missingCells, 1);
  assert.equal('totals' in result, false);
});
test('broad selection exposes sparse coverage while summing only observed groups', () => {
  const result = createCatalogClient(fixture()).evaluate({ query: 'getParticipationSummary' });
  assert.equal(result.status, 'ok'); assert.equal(result.matchedCells, 3); assert.equal(result.missingCells, 13);
  assert.ok(result.warnings.some(warning => warning.startsWith('SPARSE_SELECTION')));
  assert.ok(result.warnings.some(warning => warning.startsWith('ZERO_OFFICIAL_DENOMINATOR_CELLS')));
});
test('zero denominator is answerable as evidence, but not as an official percentage', () => {
  const client = createCatalogClient(fixture()), filters = { year: 2024, entityCodes: ['02'], sexes: ['hombre'], ageGroups: ['20-24'], sectionTypes: ['rural'] };
  assert.equal(client.evaluate({ query: 'getSupportingRecords', filters }).status, 'ok');
  const result = client.evaluate({ query: 'getParticipationSummary', filters });
  assert.equal(result.status, 'no_data'); assert.equal(result.reason, 'zero_official_denominator');
  assert.equal(result.matchedCells, 1);
});
test('unsupported fields, malformed values and invalid comparisons safely produce no_data', () => {
  const client = createCatalogClient(fixture());
  for (const request of [
    null, 'hola', [], { query: 'voteByParty' }, { query: 'getParticipationSummary', invented: true },
    { query: 'getParticipationSummary', filters: { municipality: '001' } },
    { query: 'getParticipationSummary', filters: { year: 2027 } },
    { query: 'getParticipationSummary', filters: { entityCodes: ['00'] } },
    { query: 'getParticipationSummary', filters: { ageGroups: [] } },
    { query: 'getParticipationSummary', filters: { sexes: ['hombre', 'hombre'] } },
    { query: 'getParticipationSummary', years: [2021, 2024] },
    { query: 'getParticipationSummary', dimension: 'sex' },
    { query: 'getParticipationBreakdown', dimension: 'party' },
    { query: 'compareElections', years: [2024] }, { query: 'compareElections', years: [2024, 2024] },
    { query: 'compareElections', years: [2021, 2024], filters: { year: 2024 } },
    { query: 'compareElections', years: [2018, 2024] },
  ]) assert.equal(client.evaluate(request).status, 'no_data', JSON.stringify(request));
});
test('sparse JavaScript arrays cannot silently remove requested values or comparison years', () => {
  const client = createCatalogClient(fixture()), sexes: string[] = ['hombre', 'no_binario'], years = [2021, 2024];
  delete sexes[1]; delete years[0];
  assert.equal(client.evaluate({ query: 'getParticipationSummary', filters: { sexes } }).reason, 'invalid_filter_values');
  assert.equal(client.evaluate({ query: 'compareElections', years }).reason, 'invalid_comparison_years');
});
test('an explicit unavailable category is never silently dropped from a historical comparison', () => {
  const result = createCatalogClient(fixture()).evaluate({ query: 'compareElections', years: [2021, 2024], filters: { sexes: ['hombre', 'no_binario'] } });
  assert.equal(result.status, 'no_data'); assert.equal(result.reason, 'category_unavailable_for_year');
});
test('a category known in a year but absent from the selected entity cannot be silently dropped', () => {
  const result = createCatalogClient(fixture()).evaluate({ query: 'getParticipationSummary', filters: { year: 2024, entityCodes: ['02'], sexes: ['hombre', 'no_binario'] } });
  assert.equal(result.status, 'no_data'); assert.equal(result.reason, 'requested_category_without_records');
});
test('onboarding evaluates every suggestion and excludes invalid cross-year suggestions', () => {
  const client = createCatalogClient(fixture());
  const questions = client.getOnboardingQuestions({ year: 2024, entityCodes: ['01'], sexes: ['no_binario'] });
  assert.ok(questions.length > 0); assert.equal(questions.some(item => item.request.query === 'compareElections'), false);
  for (const question of questions) assert.equal(client.evaluate(question.request).status, 'ok');
  assert.ok(questions.every(question => question.title.includes('2024')));
  assert.equal(client.getOnboardingQuestions({ year: 2021 }).some(item => item.request.query === 'compareElections'), false);
  assert.deepEqual(client.getOnboardingQuestions({ year: 2027 }), []);
  assert.deepEqual(client.getOnboardingQuestions({ year: 2024, entityCodes: ['01'], sexes: ['hombre'], ageGroups: ['20-24'] }), []);
  assert.equal(client.getOnboardingQuestions({}, 2).length, 2);
  assert.deepEqual(client.getOnboardingQuestions({}, 0), []);
});

const actualCatalog = JSON.parse(await readFile(new URL('../data/ccpc/catalog/capabilities.json', import.meta.url), 'utf8')) as unknown;
test('published catalogue is accepted by the shared client and exposes all six years and 32 entities', () => {
  const client = createCatalogClient(actualCatalog), catalog = client.getCatalog();
  assert.deepEqual(catalog.dimensions.years, [2009, 2012, 2015, 2018, 2021, 2024]);
  assert.equal(catalog.dimensions.entities.length, 32);
  for (const year of catalog.dimensions.years) for (const entity of catalog.dimensions.entities) {
    assert.equal(client.evaluate({ query: 'getParticipationSummary', filters: { year, entityCodes: [entity.code] } }).status, 'ok', `${year}/${entity.code}`);
  }
  assert.equal(catalog.matrix.statistics.observed, 20_755);
});
test('published onboarding offers only supported questions for historical and non-binary selections', () => {
  const client = createCatalogClient(actualCatalog);
  for (const context of [{}, { year: 2009 }, { year: 2024, sexes: ['no_binario'] }, { year: 2018, entityCodes: ['09'] }]) {
    const questions = client.getOnboardingQuestions(context, 20);
    assert.ok(questions.length > 0);
    for (const question of questions) assert.equal(client.evaluate(question.request).status, 'ok');
    if (context.sexes?.includes('no_binario')) assert.equal(questions.some(question => question.request.query === 'compareElections'), false);
  }
  assert.deepEqual(client.getOnboardingQuestions({ year: 2021, sexes: ['no_binario'] }), []);
});
