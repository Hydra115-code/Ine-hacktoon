import assert from 'node:assert/strict';
import test from 'node:test';
import { mkdtemp, readFile, writeFile, mkdir, rm, symlink, unlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { createFrozenParticipationService, verifyDatasetV1 } from '../src/data/dataset-v1.ts';
import { RELEASE_DIRECTORY, RELEASE_ASSET_FILES, SCHEMA_FILES } from '../src/data/dataset-v1-definition.ts';
import { CCPC_DATASET_V1_RELEASE_SHA256 } from '../src/data/dataset-v1-release.ts';

const ROOT = fileURLToPath(new URL('../', import.meta.url));
const service = await createFrozenParticipationService();
const release = service.getRelease();
async function copyRelease() {
  const root = await mkdtemp(join(tmpdir(), 'ccpc-frozen-'));
  for (const path of [...RELEASE_ASSET_FILES, ...SCHEMA_FILES, `${RELEASE_DIRECTORY}/release.json`, `${RELEASE_DIRECTORY}/checksums.sha256`]) {
    await mkdir(dirname(join(root, path)), { recursive: true }); await writeFile(join(root, path), await readFile(join(ROOT, path)));
  }
  return root;
}
test('frozen version 1.0.0 starts with all sources, methodology, warnings and a separate release pin', async () => {
  const verified = await verifyDatasetV1();
  assert.equal(release.datasetVersion, '1.0.0'); assert.equal(release.status, 'frozen');
  assert.equal(release.freeze.deadlineLocalDate, '2026-10-26'); assert.equal(release.freeze.immutable, true);
  assert.equal(verified.metadata.source.archives.length, 6); assert.ok(verified.metadata.warnings.length >= 8);
  assert.equal(verified.metadata.extraction.date, '2026-10-22'); assert.equal(verified.metadata.extraction.exactRowExtractionTimestamp, null);
  assert.equal(verified.metadata.methodology.participation.denominator, 'voted+didNotVote');
  assert.equal(verified.metadata.privacy.directIdentifiersIncluded, false);
  assert.equal(verified.metadata.privacy.anonymityGuarantee, false);
  assert.equal(createHash('sha256').update(await readFile(join(ROOT, RELEASE_DIRECTORY, 'release.json'))).digest('hex'), CCPC_DATASET_V1_RELEASE_SHA256);
});
test('all four queries expose the frozen version and preserve the catalogue guard', () => {
  const results = [service.getParticipationSummary({ year: 2024, entityCodes: ['19'] }), service.getSupportingRecords({ year: 2024, entityCodes: ['19'] }),
    service.getParticipationBreakdown({ year: 2024, entityCodes: ['19'] }, 'ageGroup'), service.compareElections({ entityCodes: ['19'] }, [2021, 2024])];
  for (const result of results) { assert.equal(result.status, 'ok'); assert.equal(result.schemaVersion, 'ccpc-query-response/v1'); assert.equal(result.release.datasetVersion, '1.0.0'); assert.equal(result.release.sha256, CCPC_DATASET_V1_RELEASE_SHA256); }
  const missing = service.getParticipationSummary({ year: 2024, entityCodes: ['03'], sexes: ['no_binario'] });
  assert.equal(missing.status, 'no_data'); assert.equal(missing.result, null);
  const invalidComparison = service.compareElections({ sexes: ['no_binario'] }, [2021, 2024]);
  assert.equal(invalidComparison.status, 'no_data'); assert.equal(invalidComparison.result, null);
});
test('metadata, manifest and dictionary are immutable after verification', () => {
  assert.throws(() => { service.getDatasetMetadata().source.publisher = 'Otro'; }, TypeError);
  assert.throws(() => { (service.getRelease().freeze as { immutable: boolean }).immutable = false; }, TypeError);
  assert.throws(() => { (service.getDictionary() as { datasetVersion: string }).datasetVersion = 'inventada'; }, TypeError);
});
test('each pinned data artifact and each frozen schema rejects byte drift before backend startup', async () => {
  const root = await copyRelease();
  try {
    await verifyDatasetV1(root);
    for (const path of [...RELEASE_ASSET_FILES, ...SCHEMA_FILES]) {
      const target = join(root, path), original = await readFile(target);
      await writeFile(target, Buffer.concat([original, Buffer.from('\n')]));
      await assert.rejects(verifyDatasetV1(root), /FROZEN_RELEASE_INVALID/);
      await writeFile(target, original);
    }
  } finally { await rm(root, { recursive: true, force: true }); }
});
test('manifest corruption and rehashed metadata cannot bypass the external release pin', async () => {
  const root = await copyRelease();
  try {
    const path = join(root, RELEASE_DIRECTORY, 'release.json');
    const changed = JSON.parse(await readFile(path, 'utf8'));
    const dictionary = join(root, RELEASE_DIRECTORY, 'dictionary.json');
    await writeFile(dictionary, Buffer.from('inventado\n'));
    const entry = changed.artifacts.find((item: { path: string }) => item.path.endsWith('/dictionary.json'));
    entry.bytes = (await readFile(dictionary)).length; entry.sha256 = createHash('sha256').update(await readFile(dictionary)).digest('hex');
    await writeFile(path, JSON.stringify(changed, null, 2) + '\n');
    await assert.rejects(createFrozenParticipationService({ root }), /SHA-256 del manifiesto/);
  } finally { await rm(root, { recursive: true, force: true }); }
});
test('missing files, symlink substitution and altered checksums stop startup', async () => {
  const root = await copyRelease();
  try {
    const target = join(root, RELEASE_DIRECTORY, 'dictionary.json'), original = await readFile(target);
    await unlink(target); await assert.rejects(verifyDatasetV1(root), /ENOENT/);
    const outside = join(root, 'dictionary-copy.json'); await writeFile(outside, original); await symlink(outside, target);
    await assert.rejects(verifyDatasetV1(root), /enlace no permitido/); await unlink(target); await writeFile(target, original);
    await writeFile(join(root, RELEASE_DIRECTORY, 'checksums.sha256'), 'alterado\n');
    await assert.rejects(verifyDatasetV1(root), /checksums del release/);
  } finally { await rm(root, { recursive: true, force: true }); }
});
test('portable startup works from a copied root with only the frozen assets and code', async () => {
  const root = await copyRelease();
  try {
    const copied = await createFrozenParticipationService({ root });
    assert.equal(copied.getParticipationSummary({ year: 2024 }).status, 'ok');
    assert.equal(copied.getDatasetMetadata().datasetVersion, '1.0.0');
  } finally { await rm(root, { recursive: true, force: true }); }
});
