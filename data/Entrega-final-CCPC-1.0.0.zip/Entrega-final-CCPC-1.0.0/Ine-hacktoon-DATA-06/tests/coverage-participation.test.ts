import assert from 'node:assert/strict';
import test from 'node:test';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createCoverageParticipationService, loadCapabilitiesCatalog } from '../src/data/coverage-participation.ts';
import { createFullParticipationService } from '../src/data/full-participation.ts';

const service = await createCoverageParticipationService();
test('DATA-05 all four backend queries use the same pinned full catalogue', () => {
  const outputs = [
    service.getParticipationSummary({ year: 2024, entityCodes: ['19'] }),
    service.getParticipationBreakdown({ year: 2024, entityCodes: ['19'] }, 'sex'),
    service.getSupportingRecords({ year: 2024, entityCodes: ['19'] }),
    service.compareElections({ entityCodes: ['19'] }, [2021, 2024]),
  ];
  for (const output of outputs) {
    assert.equal(output.status, 'ok');
    assert.equal(output.result?.evidence.dataset.kind, 'full');
    assert.equal(output.result?.evidence.matchedRecords, output.coverage.matchedCells);
    assert.equal(output.catalog.datasetRecordsSha256, service.getCatalog().dataset.recordsSha256);
  }
});
test('missing atomic selection returns no_data/null for every applicable backend method', () => {
  const filters = { year: 2012, entityCodes: ['02'], sexes: ['mujer'], ageGroups: ['100+'], sectionTypes: ['mixta'] };
  for (const output of [service.getParticipationSummary(filters), service.getSupportingRecords(filters), service.getParticipationBreakdown(filters, 'sex')]) {
    assert.equal(output.status, 'no_data'); assert.equal(output.result, null);
    assert.equal(output.coverage.matchedCells, 0); assert.equal(output.coverage.reason, 'no_matching_records');
  }
});
test('a single missing comparison endpoint is blocked even when the legacy service returns ok', async () => {
  const filters = { entityCodes: ['02'], sexes: ['mujer'], ageGroups: ['100+'], sectionTypes: ['mixta'] };
  const guarded = service.compareElections(filters, [2009, 2012]);
  assert.equal(guarded.status, 'no_data'); assert.equal(guarded.result, null);
  assert.ok(guarded.coverage.matchedCells > 0);
  const legacy = await createFullParticipationService();
  const before = legacy.compareElections({ entityCodes: ['02'], sexes: ['mujer'], ageGroups: ['100+'], sectionTypes: ['mixta'] }, [2009, 2012]);
  assert.equal(before.status, 'ok');
  assert.deepEqual(before.elections.map(item => item.summary.status), ['ok', 'no_data']);
});
test('a measured zero percent is ok and retains the official denominator', () => {
  const output = service.getParticipationSummary({ year: 2024, entityCodes: ['02'], sexes: ['no_binario'], ageGroups: ['20-24'], sectionTypes: ['urbana'] });
  assert.equal(output.status, 'ok');
  const result = output.result;
  assert.ok(result && 'totals' in result && result.totals);
  assert.equal(result.totals.voted, 0); assert.equal(result.totals.didNotVote, 1);
  assert.equal(result.totals.ccpcParticipationPct, 0); assert.equal(result.totals.ccpcAbstentionPct, 100);
});
test('unsupported requests and mixed absent categories never fall through to partial figures', () => {
  for (const request of [
    { query: 'getParticipationSummary', filters: { year: 2021, sexes: ['hombre', 'no_binario'] } },
    { query: 'compareElections', filters: { sexes: ['hombre', 'no_binario'] }, years: [2021, 2024] },
    { query: 'getParticipationSummary', filters: { year: 2024, entityCodes: ['03'], sexes: ['no_binario'] } },
    { query: 'getParticipationSummary', filters: { year: 2027 } },
    { query: 'getParticipationSummary', filters: { district: '01' } },
    { query: 'getParticipationSummary', filters: { entityCodes: ['33'] } },
    { query: 'predictWinner', filters: { year: 2024 } },
  ]) {
    const output = service.execute(request);
    assert.equal(output.status, 'no_data'); assert.equal(output.result, null); assert.ok(output.coverage.reason);
  }
});
test('real onboarding suggestions execute successfully and do not propose an invalid nonbinary comparison', () => {
  const context = { year: 2024, entityCodes: ['19'], sexes: ['no_binario'] };
  const questions = service.getOnboardingQuestions(context, 20);
  assert.ok(questions.length > 0); assert.ok(questions.every(question => question.request.query !== 'compareElections'));
  for (const question of questions) assert.equal(service.execute(question.request).status, 'ok');
  assert.deepEqual(service.getOnboardingQuestions({ year: 2024, entityCodes: ['03'], sexes: ['no_binario'] }), []);
});
test('catalogue corruption and missing catalogue fail startup without falling back to sample', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'ccpc-coverage-'));
  try {
    const bytes = await readFile(new URL('../data/ccpc/catalog/capabilities.json', import.meta.url));
    const altered = join(directory, 'capabilities.json');
    await writeFile(altered, Buffer.concat([bytes, Buffer.from('\n')]));
    await assert.rejects(loadCapabilitiesCatalog(altered), /CAPABILITIES_HASH_MISMATCH/);
    await assert.rejects(createCoverageParticipationService({ catalogPath: altered }), /CAPABILITIES_HASH_MISMATCH/);
    await assert.rejects(loadCapabilitiesCatalog(join(directory, 'missing.json')), /ENOENT/);
  } finally { await rm(directory, { recursive: true, force: true }); }
});
