/** Shared DATA-05 contract. Pure TypeScript: runs unchanged in a browser or backend. */
export const COVERAGE_QUERIES = [
  'getParticipationSummary', 'compareElections', 'getParticipationBreakdown', 'getSupportingRecords',
] as const;
export type CoverageQuery = typeof COVERAGE_QUERIES[number];
export type CoverageFilters = {
  year?: number;
  entityCodes?: string[];
  sexes?: string[];
  ageGroups?: string[];
  sectionTypes?: string[];
};
export type CoverageRequest = {
  query: CoverageQuery;
  filters?: CoverageFilters;
  years?: number[];
  dimension?: string;
};
export type CapabilitiesCatalog = {
  schemaVersion: 'ccpc-capabilities/v1';
  catalogVersion: '1.0.0';
  generatedAt: string;
  dataset: {
    kind: 'full'; schemaVersion: 'ccpc-participation/v1'; fileSha256: string; recordsSha256: string;
    recordCount: number; sourceCount: number;
  };
  dimensions: {
    years: number[];
    entities: { code: string; name: string; namesByYear: Record<string, string> }[];
    sexes: string[];
    sexesByYear: Record<string, string[]>;
    ageGroups: string[];
    sectionTypes: string[];
  };
  matrix: {
    axes: ['year', 'entityCode', 'sex', 'ageGroup', 'sectionType'];
    shape: number[];
    encoding: { '0': 'no_records'; '1': 'records_without_official_denominator'; '2': 'records_with_official_denominator' };
    cells: string;
    statistics: { possible: number; observed: number; missing: number; zeroDenominator: number };
  };
  queries: CoverageQuery[];
  breakdownDimensions: string[];
  defaultYear: number;
  metricDefinitions: {
    participation: { field: 'ccpcParticipationPct'; denominator: 'voted+didNotVote'; unit: 'percent' };
    abstention: { field: 'ccpcAbstentionPct'; denominator: 'voted+didNotVote'; unit: 'percent' };
    zeroDenominator: 'null';
  };
  comparisonPolicy: {
    minimumYears: 2; maximumYears: 6; requireDataInEveryYear: true; requireExplicitCategoriesInEveryYear: true;
    missingCells: 'never_impute'; warnings: string[];
  };
  outOfScope: { id: string; question: string; reason: string }[];
  questionTemplates: { id: string; title: string; query: CoverageQuery; dimension?: string }[];
};
export type CoverageEvaluation = {
  status: 'ok' | 'no_data'; reason: string | null; message: string; request: CoverageRequest | null;
  matchedCells: number; missingCells: number;
  byYear: { year: number; matchedCells: number; missingCells: number }[];
  warnings: string[];
};
export type OnboardingQuestion = { id: string; title: string; request: CoverageRequest };

type ObjectValue = Record<string, unknown>;
function object(value: unknown): value is ObjectValue {
  return value !== null && typeof value === 'object' && !Array.isArray(value) &&
    (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}
function check(condition: unknown, path: string): asserts condition {
  if (!condition) throw new Error(`INVALID_CAPABILITIES_CATALOG: ${path}`);
}
function keys(value: unknown, expected: readonly string[], path: string, optional: readonly string[] = []): asserts value is ObjectValue {
  check(object(value), path);
  check(expected.every(key => Object.hasOwn(value, key)), `${path}: missing fields`);
  check(Object.keys(value).every(key => expected.includes(key) || optional.includes(key)), `${path}: unknown fields`);
}
function text(value: unknown): value is string { return typeof value === 'string' && value.trim().length > 0; }
function integer(value: unknown): value is number { return Number.isSafeInteger(value) && (value as number) >= 0; }
function strings(value: unknown, path: string, allowEmpty = false): asserts value is string[] {
  check(Array.isArray(value) && (allowEmpty || value.length > 0) && Array.from(value).every(text) && new Set(value).size === value.length, path);
}
function exact(value: unknown, expected: readonly unknown[], path: string): void {
  check(Array.isArray(value) && value.length === expected.length && Array.from(value).every((item, i) => item === expected[i]), path);
}
function freeze<T>(value: T): T {
  if (value !== null && typeof value === 'object') {
    for (const item of Object.values(value)) freeze(item);
    Object.freeze(value);
  }
  return value;
}
/** Validates structural AND matrix consistency, then returns an immutable defensive snapshot. */
export function validateCapabilitiesCatalog(input: unknown): CapabilitiesCatalog {
  keys(input, ['schemaVersion', 'catalogVersion', 'generatedAt', 'dataset', 'dimensions', 'matrix', 'queries',
    'breakdownDimensions', 'defaultYear', 'metricDefinitions', 'comparisonPolicy', 'outOfScope', 'questionTemplates'], 'catalog');
  check(input.schemaVersion === 'ccpc-capabilities/v1' && input.catalogVersion === '1.0.0', 'schemaVersion/catalogVersion');
  check(typeof input.generatedAt === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/.test(input.generatedAt) &&
    Number.isFinite(Date.parse(input.generatedAt)) && new Date(input.generatedAt).toISOString().replace('.000Z', 'Z') === input.generatedAt, 'generatedAt');
  keys(input.dataset, ['kind', 'schemaVersion', 'fileSha256', 'recordsSha256', 'recordCount', 'sourceCount'], 'dataset');
  const dataset = input.dataset;
  check(dataset.kind === 'full' && dataset.schemaVersion === 'ccpc-participation/v1', 'dataset kind/schema');
  check([dataset.fileSha256, dataset.recordsSha256].every(value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value)), 'dataset hashes');
  check(integer(dataset.recordCount) && dataset.recordCount > 0 && integer(dataset.sourceCount) && dataset.sourceCount > 0, 'dataset counts');
  keys(input.dimensions, ['years', 'entities', 'sexes', 'sexesByYear', 'ageGroups', 'sectionTypes'], 'dimensions');
  const dimensions = input.dimensions;
  check(Array.isArray(dimensions.years) && dimensions.years.length > 0 && Array.from(dimensions.years).every(integer) &&
    dimensions.years.every((year, i, years) => i === 0 || year > years[i - 1]), 'dimensions.years');
  const years = dimensions.years as number[];
  check(years.includes(input.defaultYear as number), 'defaultYear');
  strings(dimensions.sexes, 'dimensions.sexes'); strings(dimensions.ageGroups, 'dimensions.ageGroups');
  strings(dimensions.sectionTypes, 'dimensions.sectionTypes');
  check(Array.isArray(dimensions.entities) && dimensions.entities.length > 0, 'dimensions.entities');
  const entityCodes: string[] = [];
  for (const entity of dimensions.entities) {
    keys(entity, ['code', 'name', 'namesByYear'], 'entity');
    check(typeof entity.code === 'string' && /^\d{2}$/.test(entity.code) && text(entity.name), 'entity code/name');
    entityCodes.push(entity.code);
    keys(entity.namesByYear, years.map(String), 'entity.namesByYear');
    check(Object.values(entity.namesByYear).every(text), 'entity.namesByYear labels');
  }
  check(new Set(entityCodes).size === entityCodes.length, 'duplicate entity codes');
  keys(dimensions.sexesByYear, years.map(String), 'dimensions.sexesByYear');
  for (const year of years) {
    const values = dimensions.sexesByYear[String(year)];
    strings(values, 'dimensions.sexesByYear values');
    check(values.every(sex => (dimensions.sexes as string[]).includes(sex)), 'dimensions.sexesByYear unknown sex');
  }
  keys(input.matrix, ['axes', 'shape', 'encoding', 'cells', 'statistics'], 'matrix');
  const matrix = input.matrix;
  exact(matrix.axes, ['year', 'entityCode', 'sex', 'ageGroup', 'sectionType'], 'matrix.axes');
  const shape = [years.length, entityCodes.length, dimensions.sexes.length, dimensions.ageGroups.length, dimensions.sectionTypes.length];
  exact(matrix.shape, shape, 'matrix.shape');
  keys(matrix.encoding, ['0', '1', '2'], 'matrix.encoding');
  check(matrix.encoding['0'] === 'no_records' && matrix.encoding['1'] === 'records_without_official_denominator' &&
    matrix.encoding['2'] === 'records_with_official_denominator', 'matrix.encoding values');
  const possible = shape.reduce((total, size) => total * size, 1);
  check(Number.isSafeInteger(possible) && typeof matrix.cells === 'string' && matrix.cells.length === possible && /^[012]+$/.test(matrix.cells), 'matrix.cells');
  const missing = [...matrix.cells].filter(cell => cell === '0').length;
  const zeroDenominator = [...matrix.cells].filter(cell => cell === '1').length;
  const observed = possible - missing;
  keys(matrix.statistics, ['possible', 'observed', 'missing', 'zeroDenominator'], 'matrix.statistics');
  for (const [key, expected] of Object.entries({ possible, observed, missing, zeroDenominator })) {
    check(matrix.statistics[key] === expected, `matrix.statistics.${key}`);
  }
  check(dataset.recordCount === observed, 'dataset.recordCount/matrix.observed');
  check(dataset.sourceCount === years.length * entityCodes.length, 'dataset.sourceCount');
  const perYear = possible / years.length, perSex = shape[3] * shape[4];
  for (let y = 0; y < years.length; y++) {
    const observedSexes = dimensions.sexes.filter((_sex, s) => entityCodes.some((_entity, e) => {
      const start = y * perYear + (e * shape[2] + s) * perSex;
      return /[12]/.test((matrix.cells as string).slice(start, start + perSex));
    }));
    const declared = dimensions.sexesByYear[String(years[y])] as string[];
    check(observedSexes.length === declared.length && observedSexes.every(sex => declared.includes(sex)), 'sexesByYear/matrix');
  }
  strings(input.queries, 'queries');
  check(input.queries.length === COVERAGE_QUERIES.length && COVERAGE_QUERIES.every(query => (input.queries as string[]).includes(query)), 'queries canonical methods');
  strings(input.breakdownDimensions, 'breakdownDimensions');
  check(input.breakdownDimensions.every(dimension => ['entity', 'year', 'sex', 'ageGroup', 'sectionType'].includes(dimension)), 'breakdownDimensions values');
  keys(input.metricDefinitions, ['participation', 'abstention', 'zeroDenominator'], 'metricDefinitions');
  for (const [metric, field] of [['participation', 'ccpcParticipationPct'], ['abstention', 'ccpcAbstentionPct']]) {
    const definition = input.metricDefinitions[metric];
    keys(definition, ['field', 'denominator', 'unit'], `metricDefinitions.${metric}`);
    check(definition.field === field && definition.denominator === 'voted+didNotVote' && definition.unit === 'percent', `metricDefinitions.${metric} values`);
  }
  check(input.metricDefinitions.zeroDenominator === 'null', 'metricDefinitions.zeroDenominator');
  keys(input.comparisonPolicy, ['minimumYears', 'maximumYears', 'requireDataInEveryYear', 'requireExplicitCategoriesInEveryYear', 'missingCells', 'warnings'], 'comparisonPolicy');
  const policy = input.comparisonPolicy;
  check(policy.minimumYears === 2 && policy.maximumYears === 6 && policy.requireDataInEveryYear === true &&
    policy.requireExplicitCategoriesInEveryYear === true && policy.missingCells === 'never_impute', 'comparisonPolicy values');
  strings(policy.warnings, 'comparisonPolicy.warnings', true);
  check(Array.isArray(input.outOfScope) && input.outOfScope.length > 0, 'outOfScope');
  const scopeIds: string[] = [];
  for (const item of input.outOfScope) {
    keys(item, ['id', 'question', 'reason'], 'outOfScope item');
    check(text(item.id) && text(item.question) && text(item.reason), 'outOfScope item values');
    scopeIds.push(item.id);
  }
  check(new Set(scopeIds).size === scopeIds.length, 'duplicate outOfScope ids');
  check(Array.isArray(input.questionTemplates) && input.questionTemplates.length > 0, 'questionTemplates');
  const templateIds: string[] = [];
  for (const template of input.questionTemplates) {
    keys(template, ['id', 'title', 'query'], 'questionTemplate', ['dimension']);
    check(text(template.id) && text(template.title) && COVERAGE_QUERIES.includes(template.query as CoverageQuery), 'questionTemplate values');
    check(template.query === 'getParticipationBreakdown' ? (input.breakdownDimensions as unknown[]).includes(template.dimension) : template.dimension === undefined, 'questionTemplate dimension');
    templateIds.push(template.id);
  }
  check(new Set(templateIds).size === templateIds.length, 'duplicate questionTemplate ids');
  // JSON semantics are intentional: callers cannot mutate a validated catalogue afterwards.
  return freeze(JSON.parse(JSON.stringify(input)) as CapabilitiesCatalog);
}

function reject(reason: string, message: string, request: CoverageRequest | null = null,
  byYear: CoverageEvaluation['byYear'] = [], warnings: string[] = []): CoverageEvaluation {
  return { status: 'no_data', reason, message, request,
    matchedCells: byYear.reduce((sum, item) => sum + item.matchedCells, 0),
    missingCells: byYear.reduce((sum, item) => sum + item.missingCells, 0), byYear, warnings };
}

/** One catalogue and one decision algorithm for onboarding and backend guards. */
export function createCatalogClient(input: unknown) {
  const catalog = validateCapabilitiesCatalog(input), dimensions = catalog.dimensions;
  const axes = [dimensions.years, dimensions.entities.map(entity => entity.code), dimensions.sexes, dimensions.ageGroups, dimensions.sectionTypes];
  const fields = ['entityCodes', 'sexes', 'ageGroups', 'sectionTypes'] as const;
  const reasons = ['unsupported_entity', 'unsupported_sex', 'unsupported_age_group', 'unsupported_section_type'];
  const strides = catalog.matrix.shape.map((_size, axis, shape) => shape.slice(axis + 1).reduce((total, size) => total * size, 1));

  function evaluateUnsafe(raw: unknown): CoverageEvaluation {
    if (!object(raw)) return reject('invalid_request', 'Se requiere un objeto de consulta.');
    if (Object.keys(raw).some(key => !['query', 'filters', 'years', 'dimension'].includes(key))) return reject('unsupported_request_field', 'La consulta contiene campos fuera del contrato CCPC.');
    if (!COVERAGE_QUERIES.includes(raw.query as CoverageQuery)) return reject('unsupported_query', 'Esta pregunta no está soportada por CCPC.');
    const query = raw.query as CoverageQuery;
    if (raw.filters !== undefined && !object(raw.filters)) return reject('invalid_filters', 'Los filtros deben ser un objeto.');
    const sourceFilters = raw.filters as ObjectValue | undefined ?? {};
    if (Object.keys(sourceFilters).some(key => !['year', ...fields].includes(key))) return reject('unsupported_filter', 'El filtro solicita una dimensión fuera del alcance de CCPC.');
    if (raw.dimension !== undefined && (query !== 'getParticipationBreakdown' || !catalog.breakdownDimensions.includes(raw.dimension as string))) {
      return reject('invalid_breakdown_dimension', 'La dimensión sólo es válida para un desglose soportado.');
    }
    if (query === 'getParticipationBreakdown' && !catalog.breakdownDimensions.includes(raw.dimension as string)) return reject('invalid_breakdown_dimension', 'Debe indicarse una dimensión de desglose disponible.');
    if (query !== 'compareElections' && raw.years !== undefined) return reject('unexpected_comparison_years', 'years sólo corresponde a compareElections.');
    const filters: CoverageFilters = {};
    if (sourceFilters.year !== undefined) {
      if (!dimensions.years.includes(sourceFilters.year as number)) return reject('unsupported_year', 'El año solicitado no está disponible.');
      filters.year = sourceFilters.year as number;
    }
    for (let axis = 0; axis < fields.length; axis++) {
      const field = fields[axis], values = sourceFilters[field];
      if (values === undefined) continue;
      if (!Array.isArray(values) || !values.length || Array.from(values).some(value => typeof value !== 'string') || new Set(values).size !== values.length) {
        return reject('invalid_filter_values', `El filtro ${field} requiere una lista no vacía de valores únicos.`);
      }
      const known = axes[axis + 1] as string[];
      if (values.some(value => !known.includes(value))) return reject(reasons[axis], `El filtro ${field} contiene una categoría no disponible.`);
      filters[field] = known.filter(value => values.includes(value));
    }
    let years: number[];
    if (query === 'compareElections') {
      if (filters.year !== undefined) return reject('conflicting_year_filter', 'Las comparaciones usan years; omita filters.year.');
      if (!Array.isArray(raw.years) || raw.years.length < catalog.comparisonPolicy.minimumYears || raw.years.length > catalog.comparisonPolicy.maximumYears ||
        new Set(raw.years).size !== raw.years.length || !Array.from(raw.years).every(year => Number.isSafeInteger(year))) {
        return reject('invalid_comparison_years', 'Se requieren entre dos y seis años únicos.');
      }
      if (raw.years.some(year => !dimensions.years.includes(year))) return reject('unsupported_year', 'Al menos un año de comparación no está disponible.');
      years = [...raw.years as number[]].sort((a, b) => a - b);
    } else { filters.year ??= catalog.defaultYear; years = [filters.year]; }
    const request: CoverageRequest = { query, filters };
    if (query === 'compareElections') request.years = years;
    if (query === 'getParticipationBreakdown') request.dimension = raw.dimension as string;
    for (const year of years) {
      if (filters.sexes?.some(sex => !dimensions.sexesByYear[String(year)].includes(sex))) {
        return reject('category_unavailable_for_year', `Una categoría de sexo solicitada no está documentada en ${year}.`, request);
      }
    }
    const selected = fields.map((field, axis) => (axes[axis + 1] as string[])
      .map((value, index) => ({ value, index })).filter(({ value }) => !filters[field] || filters[field]!.includes(value)));
    const byYear: CoverageEvaluation['byYear'] = [], warnings: string[] = query === 'compareElections' ? [...catalog.comparisonPolicy.warnings] : [];
    let answerable = 0, explicitAbsent = false, anyYearWithoutRecords = false, anyYearWithoutDenominator = false, hasZeroDenominatorCells = false;
    for (const year of years) {
      const yearIndex = dimensions.years.indexOf(year), seen = fields.map(() => new Set<string>());
      let matchedCells = 0, missingCells = 0, officialCells = 0;
      for (const entity of selected[0]) for (const sex of selected[1]) for (const age of selected[2]) for (const section of selected[3]) {
        const values = [entity, sex, age, section];
        const index = yearIndex * strides[0] + values.reduce((sum, value, axis) => sum + value.index * strides[axis + 1], 0);
        const cell = catalog.matrix.cells[index];
        if (cell === '0') { missingCells++; continue; }
        matchedCells++;
        if (cell === '2') officialCells++;
        values.forEach((value, axis) => seen[axis].add(value.value));
      }
      byYear.push({ year, matchedCells, missingCells });
      anyYearWithoutRecords ||= matchedCells === 0;
      anyYearWithoutDenominator ||= officialCells === 0;
      answerable += officialCells;
      hasZeroDenominatorCells ||= matchedCells > officialCells;
      for (let axis = 0; axis < fields.length; axis++) {
        if (filters[fields[axis]]?.some(value => !seen[axis].has(value))) explicitAbsent = true;
      }
    }
    if (byYear.some(item => item.missingCells > 0)) warnings.push('SPARSE_SELECTION: Se consultan sólo los grupos observados; los cruces ausentes no se convierten en ceros.');
    if (hasZeroDenominatorCells) warnings.push('ZERO_OFFICIAL_DENOMINATOR_CELLS: Los grupos con SV+NV=0 conservan registros, pero sus porcentajes oficiales son null.');
    if (anyYearWithoutRecords) return reject('no_matching_records', 'No hay registros para la combinación solicitada en todos los años requeridos.', request, byYear, warnings);
    if (explicitAbsent) return reject('requested_category_without_records', 'Al menos una categoría solicitada carece de registros en la selección de alguno de los años; no se elimina silenciosamente.', request, byYear, warnings);
    if (query !== 'getSupportingRecords' && (answerable === 0 || anyYearWithoutDenominator)) {
      return reject('zero_official_denominator', 'Hay registros, pero falta un denominador oficial positivo en al menos uno de los años; no se inventan porcentajes.', request, byYear, warnings);
    }
    return { status: 'ok', reason: null, message: 'La consulta puede responderse con los registros observados y el denominador oficial documentado.', request,
      matchedCells: byYear.reduce((sum, item) => sum + item.matchedCells, 0), missingCells: byYear.reduce((sum, item) => sum + item.missingCells, 0), byYear, warnings };
  }
  function evaluate(raw: unknown): CoverageEvaluation {
    try { return evaluateUnsafe(raw); }
    catch { return reject('invalid_request', 'No se pudo interpretar la consulta; no se generaron cifras.'); }
  }
  function getOnboardingQuestions(context: CoverageFilters = {}, limit = 6): OnboardingQuestion[] {
    if (!Number.isSafeInteger(limit) || limit < 0) return [];
    const baseline = evaluate({ query: 'getParticipationSummary', filters: context });
    if (baseline.status !== 'ok' || !baseline.request) return [];
    const filters = baseline.request.filters!, year = filters.year!, questions: OnboardingQuestion[] = [];
    for (const template of catalog.questionTemplates) {
      let request: CoverageRequest;
      if (template.query === 'compareElections') {
        const previous = dimensions.years.filter(candidate => candidate < year).at(-1);
        if (previous === undefined) continue;
        const { year: _omitted, ...comparisonFilters } = filters;
        request = { query: template.query, filters: comparisonFilters, years: [previous, year] };
      } else {
        request = { query: template.query, filters: { ...filters } };
        if (template.dimension !== undefined) request.dimension = template.dimension;
      }
      const result = evaluate(request);
      if (result.status === 'ok' && result.request) questions.push({ id: template.id,
        title: `${template.title} (${result.request.years?.join(' / ') ?? year})`, request: result.request });
      if (questions.length >= limit) break;
    }
    return limit === 0 ? [] : questions;
  }
  return Object.freeze({ getCatalog: () => catalog, evaluate, getOnboardingQuestions });
}
