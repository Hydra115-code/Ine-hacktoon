/** Immutable definition of the final data release. Dataset version is independent of npm versions. */
export const DATASET_VERSION = '1.0.0' as const;
export const RELEASED_AT = '2026-10-23T01:44:23Z';
export const RELEASE_DIRECTORY = 'data/ccpc/releases/1.0.0';
export const FREEZE = {
  effectiveAt: RELEASED_AT, deadlineLocalDate: '2026-10-26', timeZone: 'America/Monterrey',
  immutable: true, changesRequireNewVersion: true,
} as const;
export const CONTRACT_VERSIONS = ['ccpc-participation/v1', 'ccpc-compact/v1', 'ccpc-capabilities/v1',
  'ccpc-dataset-release/v1', 'ccpc-frontend-metadata/v1', 'ccpc-data-dictionary/v1', 'ccpc-schema-lock/v1', 'ccpc-query-response/v1'] as const;
export const SCHEMA_FILES = [
  'src/application/ports/participation-data.ts', 'src/client/coverage-client.ts',
  'src/data/capabilities-release.ts', 'src/data/ccpc-release.ts', 'src/data/coverage-participation.ts',
  'src/data/dataset-v1-definition.ts', 'src/data/dataset-v1.ts', 'src/data/full-participation.ts',
  'src/domain/civic/participation.ts', 'src/repositories/participation.repository.ts',
  'src/schemas/civic/participation.schema.ts', 'src/services/participation.service.ts',
  'scripts/ccpc/build-dataset-v1.ts', 'scripts/ccpc/regenerate-dataset-v1.ts',
] as const;
export const RELEASE_ASSET_FILES = [
  'data/ccpc/full/participation.compact.json', 'data/ccpc/full/manifest.json', 'data/ccpc/full/checksums.sha256',
  'data/ccpc/sources.json', 'data/ccpc/source-anchors.json',
  'data/ccpc/catalog/capabilities.json', 'data/ccpc/catalog/missing-combinations.csv',
  'data/ccpc/catalog/matrix-by-year.csv', 'data/ccpc/catalog/comparison-coverage.csv', 'data/ccpc/catalog/checksums.sha256',
  `${RELEASE_DIRECTORY}/dictionary.json`, `${RELEASE_DIRECTORY}/frontend-metadata.json`, `${RELEASE_DIRECTORY}/schema-lock.json`,
] as const;
export type FrozenFile = { path: string; bytes: number; sha256: string };
export type ExtractionDate = { date: string; timeZone: 'UTC'; precision: 'day'; exactRowExtractionTimestamp: null; aggregatePackagedAt: string };
export type OfficialProvenance = { publisher: string; landingUrl: string; manualUrl: string;
  archives: { year: number; url: string; sha256: string; acquiredAt: string }[] };
export type OfficialMetric = { field: string; numerator: string; denominator: string; unit: string };
export type FrontendMetadataV1 = {
  schemaVersion: 'ccpc-frontend-metadata/v1'; datasetVersion: '1.0.0'; releasedAt: string;
  source: OfficialProvenance & { title: string }; extraction: ExtractionDate;
  methodology: { unitOfAnalysis: string; dimensions: string[]; aggregation: string;
    participation: OfficialMetric; abstention: OfficialMetric; unspecified: OfficialMetric; noData: string; samplePolicy: string };
  warnings: { code: string; message: string }[];
  coverage: { years: number[]; entityCount: number; ageGroupCount: number; sectionTypeCount: number; observedCombinations: number; missingCombinations: number };
  privacy: { directIdentifiersIncluded: false; assessment: string; smallCellsPresent: true; anonymityGuarantee: false };
  contracts: { dataset: string; compact: string; capabilities: string; frontendMetadata: string };
  reproducibility: { command: string; documentation: string };
};
export type DatasetReleaseV1 = {
  schemaVersion: 'ccpc-dataset-release/v1'; datasetVersion: '1.0.0'; status: 'frozen'; releasedAt: string; freeze: typeof FREEZE;
  dataset: { kind: 'full'; compactSchemaVersion: string; normalizedSchemaVersion: string; capabilitiesSchemaVersion: string;
    file: string; sha256: string; recordsSha256: string; recordCount: number; sourceCount: number; sourceRows: number };
  extraction: ExtractionDate; provenance: OfficialProvenance; artifacts: FrozenFile[];
  schemaLock: { path: string; sha256: string; contractVersions: string[] };
  frontendMetadata: { path: string; sha256: string; schemaVersion: string };
  validation: { commands: string[]; evidenceDirectory: string };
  reproducibility: { regenerator: string; fixedMetadata: true; noRawRecordsInRelease: true };
};
