/** Immutable published dataset 1.0.0; never refresh this pin for changed bytes. */
export const CCPC_DATASET_VERSION = '1.0.0';
export const CCPC_DATASET_V1_RELEASE_SHA256 = '5992059695eac4920cf959b1589114d4327e149f237c467c7574d75c4d51d2e4';
