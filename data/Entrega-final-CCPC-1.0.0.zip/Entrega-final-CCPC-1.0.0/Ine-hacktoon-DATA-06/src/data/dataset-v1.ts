/** Final backend entry point. Verify all release bytes and frozen contracts before accepting queries. */
import { createHash } from 'node:crypto';
import { lstat, readFile } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createCoverageParticipationService } from './coverage-participation.ts';
import type { CoverageFilters } from '../client/coverage-client.ts';
import { CCPC_FULL_FILE_SHA256, CCPC_FULL_RECORDS_SHA256 } from './ccpc-release.ts';
import { CCPC_DATASET_V1_RELEASE_SHA256 } from './dataset-v1-release.ts';
import { CONTRACT_VERSIONS, DATASET_VERSION, FREEZE, RELEASE_ASSET_FILES, RELEASE_DIRECTORY, RELEASED_AT, SCHEMA_FILES } from './dataset-v1-definition.ts';
import type { DatasetReleaseV1, FrontendMetadataV1, FrozenFile } from './dataset-v1-definition.ts';

const DEFAULT_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const digest = (bytes: Buffer) => createHash('sha256').update(bytes).digest('hex');
function require(condition: unknown, reason: string): asserts condition {
  if (!condition) throw new Error(`FROZEN_RELEASE_INVALID: ${reason}`);
}
function freeze<T>(value: T): T {
  if (value !== null && typeof value === 'object') { Object.values(value).forEach(freeze); Object.freeze(value); }
  return value;
}
function fields(value: unknown, expected: readonly string[]): asserts value is Record<string, unknown> {
  require(value !== null && typeof value === 'object' && !Array.isArray(value), 'objeto requerido');
  const keys = Object.keys(value);
  require(keys.length === expected.length && keys.every(key => expected.includes(key)), 'campos ausentes o desconocidos');
}
async function safeRead(root: string, path: string): Promise<Buffer> {
  require(/^[A-Za-z0-9._/-]+$/.test(path) && path.split('/').every(part => part && part !== '.' && part !== '..'), 'ruta inválida');
  let current = root;
  for (const part of path.split('/')) {
    current = resolve(current, part);
    require(!(await lstat(current)).isSymbolicLink(), `enlace no permitido: ${path}`);
  }
  return readFile(current);
}
async function verifyFile(root: string, entry: FrozenFile): Promise<Buffer> {
  fields(entry, ['path', 'bytes', 'sha256']);
  require(typeof entry.path === 'string' && Number.isSafeInteger(entry.bytes) && entry.bytes >= 0 &&
    typeof entry.sha256 === 'string' && /^[a-f0-9]{64}$/.test(entry.sha256), 'entrada de archivo inválida');
  const bytes = await safeRead(root, entry.path);
  require(bytes.length === entry.bytes && digest(bytes) === entry.sha256, `integridad: ${entry.path}`);
  return bytes;
}
function parse(bytes: Buffer): unknown { return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); }

export async function verifyDatasetV1(root: string = DEFAULT_ROOT) {
  root = resolve(root);
  const rootStat = await lstat(root);
  require(rootStat.isDirectory() && !rootStat.isSymbolicLink(), 'raíz del paquete inválida');
  const releaseBytes = await safeRead(root, `${RELEASE_DIRECTORY}/release.json`);
  require(digest(releaseBytes) === CCPC_DATASET_V1_RELEASE_SHA256, 'SHA-256 del manifiesto 1.0.0');
  const parsed = parse(releaseBytes);
  fields(parsed, ['schemaVersion', 'datasetVersion', 'status', 'releasedAt', 'freeze', 'dataset', 'extraction', 'provenance',
    'artifacts', 'schemaLock', 'frontendMetadata', 'validation', 'reproducibility']);
  const release = parsed as unknown as DatasetReleaseV1;
  require(release.schemaVersion === 'ccpc-dataset-release/v1' && release.datasetVersion === DATASET_VERSION &&
    release.status === 'frozen' && release.releasedAt === RELEASED_AT && JSON.stringify(release.freeze) === JSON.stringify(FREEZE), 'versión o congelación incompatibles');
  require(release.dataset.sha256 === CCPC_FULL_FILE_SHA256 && release.dataset.recordsSha256 === CCPC_FULL_RECORDS_SHA256,
    'el manifiesto describe otro agregado');
  require(Array.isArray(release.artifacts) && release.artifacts.length === RELEASE_ASSET_FILES.length &&
    new Set(release.artifacts.map(entry => entry.path)).size === RELEASE_ASSET_FILES.length &&
    RELEASE_ASSET_FILES.every(path => release.artifacts.some(entry => entry.path === path)), 'inventario de release incompleto');
  const snapshots = new Map<string, Buffer>();
  for (const entry of release.artifacts) snapshots.set(entry.path, await verifyFile(root, entry));
  const lockBytes = snapshots.get(`${RELEASE_DIRECTORY}/schema-lock.json`)!;
  require(release.schemaLock.path === `${RELEASE_DIRECTORY}/schema-lock.json` && digest(lockBytes) === release.schemaLock.sha256,
    'referencia de schema-lock');
  const lock = parse(lockBytes);
  fields(lock, ['schemaVersion', 'datasetVersion', 'freeze', 'contractVersions', 'files']);
  require(lock.schemaVersion === 'ccpc-schema-lock/v1' && lock.datasetVersion === DATASET_VERSION &&
    JSON.stringify(lock.freeze) === JSON.stringify(FREEZE) && JSON.stringify(lock.contractVersions) === JSON.stringify(CONTRACT_VERSIONS), 'contrato de esquema congelado');
  require(Array.isArray(lock.files) && lock.files.length === SCHEMA_FILES.length && new Set(lock.files.map(entry => entry.path)).size === SCHEMA_FILES.length &&
    SCHEMA_FILES.every(path => (lock.files as FrozenFile[]).some(entry => entry.path === path)), 'archivos de esquema congelado incompletos');
  for (const entry of lock.files as FrozenFile[]) await verifyFile(root, entry);
  const metadataBytes = snapshots.get(`${RELEASE_DIRECTORY}/frontend-metadata.json`)!;
  require(release.frontendMetadata.path === `${RELEASE_DIRECTORY}/frontend-metadata.json` &&
    release.frontendMetadata.schemaVersion === 'ccpc-frontend-metadata/v1' && digest(metadataBytes) === release.frontendMetadata.sha256, 'metadatos frontend');
  const metadata = parse(metadataBytes) as FrontendMetadataV1;
  require(metadata.schemaVersion === 'ccpc-frontend-metadata/v1' && metadata.datasetVersion === DATASET_VERSION && metadata.releasedAt === RELEASED_AT,
    'versión de metadatos frontend');
  const checksumNames = ['dictionary.json', 'frontend-metadata.json', 'schema-lock.json', 'release.json'];
  const checksums = checksumNames.map(name => `${digest(name === 'release.json' ? releaseBytes : snapshots.get(`${RELEASE_DIRECTORY}/${name}`)!)}  ${name}\n`).join('');
  require((await safeRead(root, `${RELEASE_DIRECTORY}/checksums.sha256`)).toString('utf8') === checksums, 'checksums del release');
  return freeze({ release, metadata, dictionary: parse(snapshots.get(`${RELEASE_DIRECTORY}/dictionary.json`)! ),
    identity: { datasetVersion: DATASET_VERSION, sha256: CCPC_DATASET_V1_RELEASE_SHA256, metadataSchemaVersion: 'ccpc-frontend-metadata/v1' } });
}

export async function createFrozenParticipationService(options: { root?: string } = {}) {
  const root = resolve(options.root ?? DEFAULT_ROOT);
  const verified = await verifyDatasetV1(root);
  const service = await createCoverageParticipationService({ catalogPath: resolve(root, 'data/ccpc/catalog/capabilities.json'),
    datasetPath: resolve(root, 'data/ccpc/full/participation.compact.json') });
  function execute(request: unknown) {
    return { schemaVersion: 'ccpc-query-response/v1' as const, ...service.execute(request), release: verified.identity };
  }
  return Object.freeze({
    getRelease: () => verified.release, getDatasetMetadata: () => verified.metadata, getDictionary: () => verified.dictionary,
    getCatalog: service.getCatalog, evaluate: service.evaluate, getOnboardingQuestions: service.getOnboardingQuestions, execute,
    getParticipationSummary: (filters: CoverageFilters = {}) => execute({ query: 'getParticipationSummary', filters }),
    getSupportingRecords: (filters: CoverageFilters = {}) => execute({ query: 'getSupportingRecords', filters }),
    getParticipationBreakdown: (filters: CoverageFilters, dimension: string) => execute({ query: 'getParticipationBreakdown', filters, dimension }),
    compareElections: (filters: CoverageFilters, years: number[]) => execute({ query: 'compareElections', filters, years }),
  });
}
