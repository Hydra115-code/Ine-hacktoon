import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import {
  AGE_GROUPS, ALLOWED_YEARS, CivicParticipationError, METRIC_DEFINITIONS, SECTION_TYPES, SEXES,
  calculateMetrics,
} from '../domain/civic/participation.ts';
import type { ParticipationDataset } from '../domain/civic/participation.ts';
import { parseParticipationDataset, parseParticipationSource } from '../schemas/civic/participation.schema.ts';
import { createParticipationRepository } from '../repositories/participation.repository.ts';
import { createParticipationService } from '../services/participation.service.ts';
import {
  CCPC_FULL_FILE_SHA256, CCPC_FULL_RECORD_COUNT, CCPC_FULL_RECORDS_SHA256, CCPC_FULL_SOURCE_COUNT,
} from './ccpc-release.ts';

const FIELDS = ['schemaVersion', 'kind', 'scope', 'years', 'metricDefinitions', 'dictionaries', 'sources',
  'sourceEntityNames', 'columns', 'records', 'recordsSha256'] as const;
const COLUMNS = ['sourceIndex', 'sexIndex', 'ageGroupIndex', 'sectionTypeIndex', 'nominalList',
  'voted', 'didNotVote', 'unspecified', 'sourceRows'] as const;
const DEFAULT_DATASET = new URL('../../data/ccpc/full/participation.compact.json', import.meta.url);

function fail(code: string, message: string, path?: string): never {
  throw new CivicParticipationError(code, message, path);
}
function strictObject(input: unknown, fields: readonly string[], path: string): Record<string, unknown> {
  if (input === null || typeof input !== 'object' || Array.isArray(input)) {
    fail('INVALID_COMPACT_SCHEMA', 'Se requiere un objeto.', path);
  }
  const keys = Object.keys(input);
  if (keys.length !== fields.length || keys.some(key => !fields.includes(key)) ||
      fields.some(key => !Object.hasOwn(input, key))) {
    fail('INVALID_COMPACT_SCHEMA', 'Campos ausentes o desconocidos en el paquete compacto.', path);
  }
  return input as Record<string, unknown>;
}
function array(input: unknown, path: string): unknown[] {
  if (!Array.isArray(input)) fail('INVALID_COMPACT_SCHEMA', 'Se requiere un arreglo.', path);
  for (let index = 0; index < input.length; index++) {
    if (!Object.hasOwn(input, index)) fail('INVALID_COMPACT_SCHEMA', 'No se permiten posiciones vacías.', `${path}[${index}]`);
  }
  return input;
}
function exactList(input: unknown, expected: readonly unknown[], path: string): void {
  const values = array(input, path);
  if (values.length !== expected.length || values.some((value, index) => value !== expected[index])) {
    fail('INVALID_COMPACT_SCHEMA', 'El orden y los valores deben coincidir con el contrato publicado.', path);
  }
}
function sha256(bytes: string | Buffer): string {
  return createHash('sha256').update(bytes).digest('hex');
}
function canonicalJson(input: unknown): string {
  const canonical = (value: unknown): unknown => {
    if (Array.isArray(value)) return value.map(canonical);
    if (value !== null && typeof value === 'object') {
      return Object.fromEntries(Object.entries(value)
        .sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)
        .map(([key, child]) => [key, canonical(child)]));
    }
    return value;
  };
  return JSON.stringify(canonical(input), null, 2) + '\n';
}
function index(value: number, length: number, path: string): number {
  if (!Number.isSafeInteger(value) || value < 0 || value >= length) {
    fail('INVALID_COMPACT_INDEX', 'Índice entero seguro fuera del diccionario.', path);
  }
  return value;
}

/**
 * Rehydrates and checks the complete historical DATA-02 records. File provenance is
 * verified by loadFullParticipationDataset against the separately shipped release pin.
 * No raw archives, CSV reference, ETL, network or sample fallback is used here.
 */
export function decodeCompactDataset(input: unknown): ParticipationDataset {
  const value = strictObject(input, FIELDS, 'compact');
  if (value.schemaVersion !== 'ccpc-compact/v1' || value.kind !== 'full' || value.scope !== 'entity') {
    fail('INVALID_COMPACT_SCHEMA', 'Se requiere ccpc-compact/v1 completo de nivel entidad.', 'compact');
  }
  exactList(value.years, ALLOWED_YEARS, 'compact.years');
  exactList(value.columns, COLUMNS, 'compact.columns');
  const definitions = strictObject(value.metricDefinitions, Object.keys(METRIC_DEFINITIONS), 'compact.metricDefinitions');
  for (const [key, expected] of Object.entries(METRIC_DEFINITIONS)) {
    if (definitions[key] !== expected) fail('INVALID_METRIC_DEFINITION', 'Unidad o denominador incompatible.', `compact.metricDefinitions.${key}`);
  }
  const dictionaries = strictObject(value.dictionaries, ['sex', 'ageGroup', 'sectionType'], 'compact.dictionaries');
  exactList(dictionaries.sex, SEXES, 'compact.dictionaries.sex');
  exactList(dictionaries.ageGroup, AGE_GROUPS, 'compact.dictionaries.ageGroup');
  exactList(dictionaries.sectionType, SECTION_TYPES, 'compact.dictionaries.sectionType');
  const sourceInputs = array(value.sources, 'compact.sources');
  if (sourceInputs.length !== CCPC_FULL_SOURCE_COUNT) {
    fail('FULL_DATASET_COVERAGE', 'La publicación completa requiere 192 fuentes.', 'compact.sources');
  }
  const sources = sourceInputs.map((source, i) => parseParticipationSource(source, `compact.sources[${i}]`));
  const names = array(value.sourceEntityNames, 'compact.sourceEntityNames');
  if (names.length !== sources.length || names.some(name => typeof name !== 'string' || name.length === 0)) {
    fail('INVALID_COMPACT_SCHEMA', 'Se requiere un nombre por fuente.', 'compact.sourceEntityNames');
  }
  const tuples = array(value.records, 'compact.records');
  if (tuples.length !== CCPC_FULL_RECORD_COUNT) {
    fail('FULL_DATASET_COVERAGE', 'La publicación completa requiere 20755 grupos.', 'compact.records');
  }
  const records = tuples.map((inputTuple, i) => {
    const path = `compact.records[${i}]`;
    const tuple = array(inputTuple, path);
    if (tuple.length !== COLUMNS.length) fail('INVALID_COMPACT_TUPLE', 'Cada registro requiere nueve enteros.', path);
    for (let column = 0; column < tuple.length; column++) {
      if (typeof tuple[column] !== 'number' || !Number.isSafeInteger(tuple[column]) || (tuple[column] as number) < 0) {
        fail(column < 4 ? 'INVALID_COMPACT_INDEX' : 'INVALID_COUNT', 'Se requiere un entero seguro no negativo.', `${path}[${column}]`);
      }
    }
    const numbers = tuple as number[];
    const sourceIndex = index(numbers[0], sources.length, `${path}[0]`);
    const source = sources[sourceIndex];
    const sex = SEXES[index(numbers[1], SEXES.length, `${path}[1]`)];
    const ageGroup = AGE_GROUPS[index(numbers[2], AGE_GROUPS.length, `${path}[2]`)];
    const sectionType = SECTION_TYPES[index(numbers[3], SECTION_TYPES.length, `${path}[3]`)];
    const counts = { nominalList: numbers[4], voted: numbers[5], didNotVote: numbers[6], unspecified: numbers[7] };
    return {
      entityCode: source.entityCode, entityName: names[sourceIndex] as string, year: source.year,
      sex, ageGroup, sectionType, ...counts, ...calculateMetrics(counts),
      sourceId: source.id, sourceRows: numbers[8],
    };
  });
  const dataset = parseParticipationDataset({
    schemaVersion: 'ccpc-participation/v1', scope: 'entity', kind: 'full', years: [...ALLOWED_YEARS],
    metricDefinitions: { ...METRIC_DEFINITIONS }, sources, records,
  });
  const recordsSha256 = sha256(canonicalJson(dataset.records));
  if (value.recordsSha256 !== CCPC_FULL_RECORDS_SHA256 || recordsSha256 !== CCPC_FULL_RECORDS_SHA256) {
    fail('FULL_RECORDS_HASH_MISMATCH', 'Los registros difieren de la publicación completa auditada.', 'compact.recordsSha256');
  }
  return dataset;
}

/** Reads one pinned portable artifact; checksum failure or a missing file is fatal. */
export async function loadFullParticipationDataset(path: string | URL = DEFAULT_DATASET): Promise<ParticipationDataset> {
  const bytes = await readFile(path).catch((error: NodeJS.ErrnoException) => {
    if (error.code === 'ENOENT') fail('FULL_DATASET_NOT_FOUND', 'No se encontró el agregado completo portátil.');
    throw error;
  });
  if (sha256(bytes) !== CCPC_FULL_FILE_SHA256) {
    fail('FULL_FILE_HASH_MISMATCH', 'Los bytes no coinciden con la publicación portátil fijada.');
  }
  let decoded: string;
  try { decoded = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
  catch { return fail('INVALID_ENCODING', 'El agregado portátil debe usar UTF-8 válido.'); }
  let input: unknown;
  try { input = JSON.parse(decoded); }
  catch { return fail('INVALID_JSON', 'JSON inválido en el agregado portátil.'); }
  return decodeCompactDataset(input);
}

/** Backend startup helper. Reuse the returned synchronous service for all requests. */
export async function createFullParticipationService(path?: string | URL) {
  return createParticipationService(createParticipationRepository(await loadFullParticipationDataset(path)));
}
