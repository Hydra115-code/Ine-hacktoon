/** Trusted release pins. The file pin is set when the audited portable artifact is published. */
export const CCPC_FULL_FILE_SHA256 = 'd7e546928465d25702fe1b625eafb91c8435f7c5ddedd1c30a5278f89c29489c';
/** Canonical DATA-02 records independently audited against all six official archives. */
export const CCPC_FULL_RECORDS_SHA256 = '8d06184746e12b21a5166117e37787537a6643a659493f12d9c6efef3fd44e38';
export const CCPC_FULL_RECORD_COUNT = 20_755;
export const CCPC_FULL_SOURCE_COUNT = 192;
