/** DATA-05 release pin: generated from the audited DATA-04 aggregate. */
export const CCPC_CAPABILITIES_FILE_SHA256 = '5dd6c03fdcad5466cf069a82d1bb86c1c7ebd0d14e56a8d9ba8777c0db995f9b';
