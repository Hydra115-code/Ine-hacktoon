/** DATA-05 entry point: catalog decisions precede every backend query. No ETL. */
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { createCatalogClient, validateCapabilitiesCatalog } from '../client/coverage-client.ts';
import type { CoverageFilters, CoverageRequest } from '../client/coverage-client.ts';
import { CCPC_CAPABILITIES_FILE_SHA256 } from './capabilities-release.ts';
import { CCPC_FULL_FILE_SHA256, CCPC_FULL_RECORDS_SHA256 } from './ccpc-release.ts';
import { loadFullParticipationDataset } from './full-participation.ts';
import { createParticipationRepository } from '../repositories/participation.repository.ts';
import { createParticipationService } from '../services/participation.service.ts';
import { parseParticipationFilters } from '../application/ports/participation-data.ts';
import type { BreakdownDimension, Year } from '../application/ports/participation-data.ts';

const DEFAULT_CATALOG = new URL('../../data/ccpc/catalog/capabilities.json', import.meta.url);

export async function loadCapabilitiesCatalog(path: string | URL = DEFAULT_CATALOG) {
  const bytes = await readFile(path);
  if (createHash('sha256').update(bytes).digest('hex') !== CCPC_CAPABILITIES_FILE_SHA256) {
    throw new Error('CAPABILITIES_HASH_MISMATCH: el catálogo difiere de la publicación fijada.');
  }
  const catalog = validateCapabilitiesCatalog(JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)));
  if (catalog.dataset.fileSha256 !== CCPC_FULL_FILE_SHA256 || catalog.dataset.recordsSha256 !== CCPC_FULL_RECORDS_SHA256) {
    throw new Error('CAPABILITIES_DATASET_MISMATCH: el catálogo describe otro conjunto de datos.');
  }
  return catalog;
}

export async function createCoverageParticipationService(options: { catalogPath?: string | URL; datasetPath?: string | URL } = {}) {
  const catalog = await loadCapabilitiesCatalog(options.catalogPath);
  const client = createCatalogClient(catalog);
  const dataset = await loadFullParticipationDataset(options.datasetPath);
  const service = createParticipationService(createParticipationRepository(dataset));
  if (catalog.dataset.recordCount !== dataset.records.length || catalog.dataset.sourceCount !== dataset.sources.length) {
    throw new Error('CAPABILITIES_DATASET_MISMATCH: conteos de publicación incompatibles.');
  }
  const identity = Object.freeze({ schemaVersion: catalog.schemaVersion, catalogVersion: catalog.catalogVersion,
    sha256: CCPC_CAPABILITIES_FILE_SHA256, datasetRecordsSha256: CCPC_FULL_RECORDS_SHA256 });
  function execute(input: unknown) {
    const coverage = client.evaluate(input);
    if (coverage.status === 'no_data') return { status: 'no_data' as const, coverage, result: null, catalog: identity };
    const request = coverage.request!;
    const filters = parseParticipationFilters(request.filters ?? {});
    const result = request.query === 'compareElections' ? service.compareElections(filters, request.years as Year[])
      : request.query === 'getParticipationBreakdown' ? service.getParticipationBreakdown(filters, request.dimension as BreakdownDimension)
      : request.query === 'getSupportingRecords' ? service.getSupportingRecords(filters)
      : service.getParticipationSummary(filters);
    // A disagreement is a broken publication, never a reason to fabricate or silently return data.
    if (result.status !== 'ok' || result.evidence.matchedRecords !== coverage.matchedCells) {
      throw new Error('CAPABILITIES_RUNTIME_MISMATCH: catálogo y datos no describen las mismas filas.');
    }
    return { status: 'ok' as const, coverage, result, catalog: identity };
  }
  return Object.freeze({
    getCatalog: client.getCatalog, evaluate: client.evaluate, getOnboardingQuestions: client.getOnboardingQuestions, execute,
    getParticipationSummary: (filters: CoverageFilters = {}) => execute({ query: 'getParticipationSummary', filters }),
    getSupportingRecords: (filters: CoverageFilters = {}) => execute({ query: 'getSupportingRecords', filters }),
    getParticipationBreakdown: (filters: CoverageFilters, dimension: string) => execute({ query: 'getParticipationBreakdown', filters, dimension }),
    compareElections: (filters: CoverageFilters, years: number[]) => execute({ query: 'compareElections', filters, years } satisfies CoverageRequest),
  });
}
