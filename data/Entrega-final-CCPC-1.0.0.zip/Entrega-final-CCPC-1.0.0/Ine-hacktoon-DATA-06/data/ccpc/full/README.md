# Agregado completo CCPC — DATA-04

Esta carpeta contiene **full**, no la muestra: 32 entidades × seis cortes electorales (2009, 2012, 2015, 2018, 2021, 2024), desagregados por sexo, 18 bandas de edad y tipo de sección. Las combinaciones no observadas no se rellenan artificialmente.

`participation.compact.json` almacena 20,755 grupos en tuplas de nueve enteros, diccionarios compartidos y 192 fuentes. `manifest.json` declara versión, fecha de release, tamaño, SHA-256, hash de los registros canónicos y adquisición/procedencia. `checksums.sha256` protege ambos archivos. No se incluyen los ZIP ni las 54,872,712 filas originales.

El backend debe cargarlo con `createFullParticipationService()` de `src/data/full-participation.ts` (ruta desde la raíz del módulo). La rehidratación conserva exactamente el contrato de las cuatro consultas. No necesita raw/processed, CSV de referencia, ETL o red.

**Campos para indicadores oficiales:** `ccpcParticipationPct = 100*SV/(SV+NV)` y `ccpcAbstentionPct = 100*NV/(SV+NV)`. NS se conserva por separado. Un denominador cero produce null. Los campos nominales anteriores siguen sobre LN y no deben usarse con la etiqueta de indicador oficial.

La muestra de desarrollo está exclusivamente en `../sample/` y declara `kind: sample`. El cargador completo la rechaza incluso si se etiqueta falsamente como full.

Desde la raíz: `npm run ccpc:full:verify` y `npm run ccpc:full:audit`. Más detalle en `docs/data04-backend.md`, `docs/data04-checklist.md` y `docs/data04-reproduction.md`.
