/** One-time publication and deterministic staging builder. Never refreshes an existing v1 pin. */
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile, stat, readdir } from 'node:fs/promises';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadFullParticipationDataset } from '../../src/data/full-participation.ts';
import { loadCapabilitiesCatalog } from '../../src/data/coverage-participation.ts';
import { CONTRACT_VERSIONS, DATASET_VERSION, FREEZE, RELEASED_AT, RELEASE_DIRECTORY, SCHEMA_FILES, RELEASE_ASSET_FILES } from '../../src/data/dataset-v1-definition.ts';
import type { DatasetReleaseV1, FrontendMetadataV1, FrozenFile, OfficialProvenance, ExtractionDate } from '../../src/data/dataset-v1-definition.ts';
import { CCPC_FULL_FILE_SHA256, CCPC_FULL_RECORDS_SHA256 } from '../../src/data/ccpc-release.ts';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const sha256 = (bytes: Buffer | string) => createHash('sha256').update(bytes).digest('hex');
const json = (input: unknown) => Buffer.from(JSON.stringify(input, null, 2) + '\n');
async function entry(path: string, generated: Map<string, Buffer>): Promise<FrozenFile> {
  const bytes = generated.get(path) ?? await readFile(join(ROOT, path));
  return { path, bytes: bytes.length, sha256: sha256(bytes) };
}

export async function buildDatasetV1(output: string) {
  const dataset = await loadFullParticipationDataset(), catalog = await loadCapabilitiesCatalog();
  const old = JSON.parse(await readFile(join(ROOT, 'data/ccpc/full/manifest.json'), 'utf8'));
  const provenance: OfficialProvenance = {
    publisher: 'Instituto Nacional Electoral',
    landingUrl: 'https://ine.mx/transparencia/datos-abiertos/visualizacion-datos/conteos-censales-participacion/',
    manualUrl: 'https://ine.mx/wp-content/uploads/2025/06/Manual-Conteos-Censales-2009-2024.pdf',
    archives: dataset.years.map(year => {
      const download = old.acquisition.downloads.find((row: { year: number }) => row.year === year);
      if (!download || !dataset.sources.filter(source => source.year === year).every(source => source.archiveSha256 === download.sha256 && source.url === download.url)) {
        throw new Error(`Procedencia de adquisición incompatible para ${year}.`);
      }
      return { year, url: download.url, sha256: download.sha256, acquiredAt: download.downloadedAt };
    }),
  };
  const extraction: ExtractionDate = {
    date: '2026-10-22', timeZone: 'UTC', precision: 'day', exactRowExtractionTimestamp: null, aggregatePackagedAt: old.generatedAt,
  };
  if (!old.generatedAt.startsWith(extraction.date) || provenance.archives.some(archive => !archive.acquiredAt.startsWith(extraction.date))) {
    throw new Error('La fecha documentada de extracción no coincide con las evidencias DATA-04.');
  }
  const metadata: FrontendMetadataV1 = {
    schemaVersion: 'ccpc-frontend-metadata/v1', datasetVersion: DATASET_VERSION, releasedAt: RELEASED_AT,
    source: { ...provenance, title: 'Conteos Censales de Participación Ciudadana (CCPC)' }, extraction,
    methodology: {
      unitOfAnalysis: 'Agregado de entidad × año × sexo × grupo de edad × tipo de sección; no personas individuales.',
      dimensions: ['entityCode', 'year', 'sex', 'ageGroup', 'sectionType'], aggregation: 'sum_counts_then_divide',
      participation: { field: 'ccpcParticipationPct', numerator: 'voted', denominator: 'voted+didNotVote', unit: 'percent' },
      abstention: { field: 'ccpcAbstentionPct', numerator: 'didNotVote', denominator: 'voted+didNotVote', unit: 'percent' },
      unspecified: { field: 'unspecifiedPct', numerator: 'unspecified', denominator: 'nominalList', unit: 'percent' },
      noData: 'Una selección ausente devuelve no_data y result:null. Los cruces vacíos no se imputan; un cero observado sigue siendo un dato.',
      samplePolicy: 'La entrega final utiliza full. La muestra histórica se conserva sólo como fixture y no se suma al conjunto completo.',
    },
    warnings: [
      { code: 'NS_EXCLUDED_FROM_CCPC', message: 'Participación y abstención oficiales usan SV+NV; NS permanece separado. Los campos heredados sobre LN tienen otro denominador.' },
      { code: 'NO_DATA_IS_NOT_ZERO', message: 'Una combinación sin registros no equivale a participación cero. Los denominadores nulos no producen porcentajes inventados.' },
      { code: 'NON_BINARY_ONLY_2024', message: 'no_binario sólo aparece en 2024 y no tiene registros en todos los cruces; no se reconstruye su historia anterior.' },
      { code: 'SPARSE_COVERAGE', message: 'Hay 10,349 combinaciones ausentes. Los agregados usan los registros observados y exponen su cobertura.' },
      { code: 'ELECTIONS_NOT_A_PANEL', message: 'Las comparaciones son descriptivas; no siguen a las mismas personas ni prueban causas o predicen conductas.' },
      { code: 'CARTOGRAPHIC_FRAMES_DIFFER', message: 'Los marcos DERFE 2021 y 2023 difieren. Igual tipo de sección no garantiza identidad territorial entre elecciones.' },
      { code: 'AGGREGATE_SCOPE_ONLY', message: 'Este paquete no responde por municipio, distrito, sección específica, persona, partido o candidato.' },
      { code: 'SMALL_CELLS', message: 'No se incluyen identificadores personales directos. Persisten celdas pequeñas; no se certifica anonimato absoluto ni ausencia de inferencias.' },
      { code: 'EXTRACTION_DATE_PRECISION', message: 'La extracción original se documenta a nivel de día con adquisición y empaquetado DATA-04. No se inventa una hora exacta de extracción de filas.' },
    ],
    coverage: { years: dataset.years, entityCount: 32, ageGroupCount: 18, sectionTypeCount: 3,
      observedCombinations: catalog.matrix.statistics.observed, missingCombinations: catalog.matrix.statistics.missing },
    privacy: { directIdentifiersIncluded: false, assessment: 'schema_allowlist_verified', smallCellsPresent: true, anonymityGuarantee: false },
    contracts: { dataset: 'ccpc-participation/v1', compact: 'ccpc-compact/v1', capabilities: 'ccpc-capabilities/v1', frontendMetadata: 'ccpc-frontend-metadata/v1' },
    reproducibility: { command: 'npm run ccpc:release:regenerate -- --output /ruta/de/staging', documentation: 'docs/data06-release.md' },
  };
  const lock = { schemaVersion: 'ccpc-schema-lock/v1', datasetVersion: DATASET_VERSION, freeze: FREEZE,
    contractVersions: [...CONTRACT_VERSIONS], files: await Promise.all(SCHEMA_FILES.map(path => entry(path, new Map()))) };
  const generated = new Map<string, Buffer>([
    [`${RELEASE_DIRECTORY}/frontend-metadata.json`, json(metadata)], [`${RELEASE_DIRECTORY}/schema-lock.json`, json(lock)],
    [`${RELEASE_DIRECTORY}/dictionary.json`, await readFile(join(ROOT, RELEASE_DIRECTORY, 'dictionary.json'))],
  ]);
  const artifacts = await Promise.all(RELEASE_ASSET_FILES.map(path => entry(path, generated)));
  const release: DatasetReleaseV1 = {
    schemaVersion: 'ccpc-dataset-release/v1', datasetVersion: DATASET_VERSION, status: 'frozen', releasedAt: RELEASED_AT, freeze: FREEZE,
    dataset: { kind: 'full', compactSchemaVersion: 'ccpc-compact/v1', normalizedSchemaVersion: dataset.schemaVersion, capabilitiesSchemaVersion: catalog.schemaVersion,
      file: 'data/ccpc/full/participation.compact.json', sha256: CCPC_FULL_FILE_SHA256, recordsSha256: CCPC_FULL_RECORDS_SHA256,
      recordCount: dataset.records.length, sourceCount: dataset.sources.length, sourceRows: dataset.sources.reduce((sum, source) => sum + source.rawRows, 0) },
    extraction, provenance, artifacts,
    schemaLock: { path: `${RELEASE_DIRECTORY}/schema-lock.json`, sha256: sha256(generated.get(`${RELEASE_DIRECTORY}/schema-lock.json`)!), contractVersions: [...CONTRACT_VERSIONS] },
    frontendMetadata: { path: `${RELEASE_DIRECTORY}/frontend-metadata.json`, sha256: sha256(generated.get(`${RELEASE_DIRECTORY}/frontend-metadata.json`)!), schemaVersion: metadata.schemaVersion },
    validation: { commands: ['npm run ccpc:check', 'npm run ccpc:release:audit', 'npm run ccpc:privacy:audit'], evidenceDirectory: 'docs/data06-evidence' },
    reproducibility: { regenerator: 'scripts/ccpc/regenerate-dataset-v1.ts', fixedMetadata: true, noRawRecordsInRelease: true },
  };
  const releaseBytes = json(release);
  const names = ['dictionary.json', 'frontend-metadata.json', 'schema-lock.json', 'release.json'];
  await mkdir(output, { recursive: true });
  for (const name of names) await writeFile(join(output, name), name === 'release.json' ? releaseBytes : generated.get(`${RELEASE_DIRECTORY}/${name}`)!);
  const checksums = names.map(name => `${sha256(name === 'release.json' ? releaseBytes : generated.get(`${RELEASE_DIRECTORY}/${name}`)!)}  ${name}\n`).join('');
  await writeFile(join(output, 'checksums.sha256'), checksums);
  return { datasetVersion: DATASET_VERSION, releaseSha256: sha256(releaseBytes), files: [...names, 'checksums.sha256'], artifacts: artifacts.length, schemaFiles: lock.files.length };
}

async function initialize() {
  const output = join(ROOT, RELEASE_DIRECTORY), pin = join(ROOT, 'src/data/dataset-v1-release.ts');
  if (await stat(join(output, 'release.json')).catch(() => null)) throw new Error('IMMUTABLE_RELEASE: 1.0.0 ya existe. Regenerar en staging; los cambios requieren otra versión.');
  if (await stat(pin).catch(() => null)) throw new Error('IMMUTABLE_RELEASE: ya existe un pin 1.0.0. No se actualiza automáticamente.');
  // The dictionary is a reviewed input. No other generated files may pre-exist on first publication.
  if ((await readdir(output)).some(name => name !== 'dictionary.json')) throw new Error('Directorio de publicación contiene archivos inesperados.');
  const result = await buildDatasetV1(output);
  await writeFile(pin, `/** Immutable published dataset 1.0.0; never refresh this pin for changed bytes. */\nexport const CCPC_DATASET_VERSION = '1.0.0';\nexport const CCPC_DATASET_V1_RELEASE_SHA256 = '${result.releaseSha256}';\n`, { flag: 'wx' });
  console.log(JSON.stringify(result, null, 2));
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (process.argv.slice(2).join(' ') !== '--initialize') throw new Error('Publicación inicial: build-dataset-v1.ts --initialize. Reproducción: ccpc:release:regenerate -- --output STAGING.');
  initialize().catch(error => { console.error(error); process.exitCode = 1; });
}
