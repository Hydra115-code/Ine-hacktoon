/** Aceptación DATA-04 ejecutada sobre el mismo adaptador portátil que usa backend. */
import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadFullParticipationDataset } from '../../src/data/full-participation.ts';
import { createParticipationRepository } from '../../src/repositories/participation.repository.ts';
import { createParticipationService } from '../../src/services/participation.service.ts';
import { ALLOWED_YEARS } from '../../src/domain/civic/participation.ts';
import type { Counts, ParticipationRecord } from '../../src/domain/civic/participation.ts';
import type { AgeGroup, EntityCode } from '../../src/application/ports/participation-data.ts';
import { canonicalJson, sha256 } from './etl-io.ts';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const fields = ['nominalList', 'voted', 'didNotVote', 'unspecified'] as const;
function sum(rows: readonly Counts[]): Counts {
  return Object.fromEntries(fields.map(field => [field, rows.reduce((total, row) => total + row[field], 0)])) as Counts;
}
function verifyOfficial(counts: Counts & { ccpcParticipationPct: number | null; ccpcAbstentionPct: number | null }): void {
  assert.equal(counts.nominalList, counts.voted + counts.didNotVote + counts.unspecified);
  const denominator = counts.voted + counts.didNotVote;
  assert.equal(counts.ccpcParticipationPct, denominator === 0 ? null : (counts.voted / denominator) * 100);
  assert.equal(counts.ccpcAbstentionPct, denominator === 0 ? null : (counts.didNotVote / denominator) * 100);
}
function countFields(totals: Counts): Counts { return sum([totals]); }

export async function verifyFullPackage() {
  const input = join(ROOT, 'data/ccpc/full/participation.compact.json');
  const bytes = await readFile(input), datasetSha256 = sha256(bytes);
  const dataset = await loadFullParticipationDataset(input);
  const manifestPath = join(dirname(input), 'manifest.json');
  const manifestBytes = await readFile(manifestPath);
  const manifest = JSON.parse(manifestBytes.toString('utf8'));
  assert.equal(manifest.schemaVersion, 'ccpc-full-package/v1');
  assert.equal(manifest.kind, 'full');
  assert.equal(manifest.scope, 'entity');
  assert.match(manifest.packageVersion, /^\d+\.\d+\.\d+$/);
  assert.ok(Number.isFinite(Date.parse(manifest.generatedAt)));
  assert.deepEqual(manifest.years, [...ALLOWED_YEARS]);
  assert.equal(manifest.dataset.sha256, datasetSha256);
  assert.equal(manifest.dataset.bytes, bytes.length);
  assert.equal(manifest.dataset.recordsSha256, sha256(canonicalJson(dataset.records)));
  assert.equal(manifest.dataset.recordCount, dataset.records.length);
  assert.equal(manifest.dataset.sourceCount, dataset.sources.length);
  assert.equal(manifest.dataset.rawRowCount, dataset.sources.reduce((total, source) => total + source.rawRows, 0));
  assert.equal(manifest.originalRecordsIncluded, false);
  assert.ok(bytes.length < 2 * 1024 * 1024, 'El JSON optimizado debe pesar menos de 2 MiB.');
  assert.equal(await readFile(join(dirname(input), 'checksums.sha256'), 'utf8'),
    `${datasetSha256}  participation.compact.json\n${sha256(manifestBytes)}  manifest.json\n`);
  const service = createParticipationService(createParticipationRepository(dataset));
  const entities = Array.from({ length: 32 }, (_, index) => String(index + 1).padStart(2, '0') as EntityCode);
  assert.deepEqual(manifest.entityCodes, entities);
  const entityYears = [];
  const national = [];
  for (const year of ALLOWED_YEARS) {
    for (const entityCode of entities) {
      const filters = { year, entityCodes: [entityCode] };
      const summary = service.getParticipationSummary(filters);
      const support = service.getSupportingRecords(filters);
      const expected = dataset.sources.find(source => source.year === year && source.entityCode === entityCode)!;
      assert.equal(summary.status, 'ok'); assert.equal(support.status, 'ok');
      assert.equal(summary.evidence.dataset.kind, 'full');
      assert.ok(!summary.warnings.some(warning => warning.code === 'SAMPLE_DATA'));
      assert.deepEqual(countFields(summary.totals!), expected.totals);
      assert.deepEqual(sum(support.records), expected.totals);
      assert.equal(support.evidence.matchedSourceRows, expected.rawRows);
      assert.ok(support.records.every(row => row.year === year && row.entityCode === entityCode));
      assert.equal(support.records.length, dataset.records.filter(row => row.year === year && row.entityCode === entityCode).length);
      verifyOfficial(summary.totals!);
      support.records.forEach(verifyOfficial);
      const breakdown = service.getParticipationBreakdown(filters, 'sex');
      assert.deepEqual(sum(breakdown.groups.map(group => group.summary.totals!)), expected.totals);
      breakdown.groups.forEach(group => verifyOfficial(group.summary.totals!));
      entityYears.push({ year, entityCode, recordCount: support.records.length, sourceRows: expected.rawRows, totals: summary.totals });
    }
    const summary = service.getParticipationSummary({ year });
    const allSources = dataset.sources.filter(source => source.year === year);
    assert.deepEqual(countFields(summary.totals!), sum(allSources.map(source => source.totals)));
    verifyOfficial(summary.totals!);
    for (const dimension of ['entity', 'sex', 'ageGroup', 'sectionType'] as const) {
      const result = service.getParticipationBreakdown({ year }, dimension);
      if (dimension === 'entity') assert.equal(result.groups.length, 32);
      assert.deepEqual(sum(result.groups.map(group => group.summary.totals!)), countFields(summary.totals!));
      result.groups.forEach(group => verifyOfficial(group.summary.totals!));
    }
    national.push({ year, recordCount: summary.evidence.matchedRecords, sourceRows: summary.evidence.matchedSourceRows, totals: summary.totals });
  }
  for (const entityCode of entities) {
    const comparison = service.compareElections({ entityCodes: [entityCode] }, ALLOWED_YEARS);
    assert.equal(comparison.elections.length, 6);
    const baseline = comparison.elections[0].summary.totals!;
    comparison.elections.forEach(election => verifyOfficial(election.summary.totals!));
    for (const change of comparison.changes) {
      const current = comparison.elections.find(election => election.year === change.year)!.summary.totals!;
      assert.equal(change.ccpcParticipationPercentagePoints, current.ccpcParticipationPct! - baseline.ccpcParticipationPct!);
      assert.equal(change.ccpcAbstentionPercentagePoints, current.ccpcAbstentionPct! - baseline.ccpcAbstentionPct!);
    }
  }
  for (const year of ALLOWED_YEARS.filter(year => year !== 2024)) {
    const result = service.getParticipationSummary({ year, sexes: ['no_binario'] });
    assert.equal(result.status, 'no_data'); assert.equal(result.totals, null);
  }
  assert.equal(service.getParticipationSummary().filters.year, 2024);
  const zeroGroups = dataset.records.filter(row => row.classified === 0);
  // Do not fabricate a zero-denominator group when the real release has none.
  // The domain's zero/null policy is separately exercised by the unit suite.
  for (const zero of zeroGroups) {
    const zeroResult = service.getParticipationSummary({ year: zero.year, entityCodes: [zero.entityCode as EntityCode], sexes: [zero.sex], ageGroups: [zero.ageGroup as AgeGroup], sectionTypes: [zero.sectionType] });
    assert.equal(zeroResult.totals!.ccpcParticipationPct, null);
    assert.equal(zeroResult.totals!.ccpcAbstentionPct, null);
  }

  const supportFilters = { year: 2024, entityCodes: ['01', '19'], sexes: ['hombre', 'mujer'], ageGroups: ['18-19', '20-24'], sectionTypes: ['urbana', 'rural'] } as const;
  const supportResult = service.getSupportingRecords(supportFilters);
  const expectedSupport = dataset.records.filter(row => row.year === 2024 && ['01', '19'].includes(row.entityCode) && ['hombre', 'mujer'].includes(row.sex) && ['18-19', '20-24'].includes(row.ageGroup) && ['urbana', 'rural'].includes(row.sectionType));
  assert.deepEqual(supportResult.records, expectedSupport as ParticipationRecord[]);
  const examples = {
    schemaVersion: 'ccpc-query-examples/v1', datasetKind: 'full', datasetSha256,
    calls: [
      { method: 'getParticipationSummary', input: { filters: { year: 2024 } }, result: service.getParticipationSummary({ year: 2024 }) },
      { method: 'compareElections', input: { filters: { entityCodes: ['19'] }, years: ALLOWED_YEARS }, result: service.compareElections({ entityCodes: ['19'] }, ALLOWED_YEARS) },
      { method: 'getParticipationBreakdown', input: { filters: { year: 2024, entityCodes: ['19'] }, dimension: 'sex' }, result: service.getParticipationBreakdown({ year: 2024, entityCodes: ['19'] }, 'sex') },
      { method: 'getSupportingRecords', input: { filters: supportFilters }, result: supportResult },
    ],
  };
  const coverage = {
    schemaVersion: 'ccpc-data04-coverage/v1', datasetSha256, recordsSha256: manifest.dataset.recordsSha256,
    checks: { entityYearSummaries: 192, entityYearSupports: 192, entityYearSexBreakdowns: 192,
      entityComparisons: 32, nationalSummaries: 6, nationalBreakdowns: 24, nonBinaryAbsentYears: 5,
      zeroOfficialDenominatorObservedGroups: zeroGroups.length, zeroDenominatorPolicy: 'covered_by_domain_unit_tests', filteredSupportingRecords: true },
    entityYears, national, status: 'pass',
  };
  const out = join(ROOT, 'docs/data04-evidence');
  await mkdir(out, { recursive: true });
  for (const [name, value] of [['queries.json', examples], ['coverage-report.json', coverage]] as const) {
    await writeFile(join(out, name), canonicalJson(value));
  }
  console.log(`DATA-04 VALIDADO: 6 años × 32 entidades; ${dataset.records.length} grupos; cuatro consultas; denominadores oficiales; ${bytes.length} bytes.`);
  return coverage;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  if (args.length === 1 && args[0] === '--help') {
    console.log('node scripts/ccpc/verify-full-package.ts\nVerifica el agregado portable full y ejecuta las cuatro consultas. Para ejemplos del JSON DATA-02 anterior: npm run ccpc:queries:sample -- --input PATH.');
  } else if (args.length) {
    console.error(`Argumentos no admitidos: ${args.join(' ')}. Use --help.`);
    process.exitCode = 1;
  } else {
    verifyFullPackage().catch(error => { console.error(error); process.exitCode = 1; });
  }
}
