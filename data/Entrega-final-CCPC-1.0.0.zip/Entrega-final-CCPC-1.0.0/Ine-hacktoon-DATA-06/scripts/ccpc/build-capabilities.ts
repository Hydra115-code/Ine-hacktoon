/** DATA-05: derive capabilities from the pinned DATA-04 aggregate, without ETL or raw files. */
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import ts from 'typescript';
import { loadFullParticipationDataset } from '../../src/data/full-participation.ts';
import { AGE_GROUPS, SECTION_TYPES, SEXES } from '../../src/domain/civic/participation.ts';
import { CCPC_FULL_FILE_SHA256, CCPC_FULL_RECORDS_SHA256 } from '../../src/data/ccpc-release.ts';
import { validateCapabilitiesCatalog } from '../../src/client/coverage-client.ts';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const OUTPUT = join(ROOT, 'data/ccpc/catalog');
const hash = (value: string | Buffer) => createHash('sha256').update(value).digest('hex');
const csv = (columns: string[], rows: unknown[][]) => columns.join(',') + '\n' + rows.map(row => row.map(value => {
  const text = String(value); return /[",\n\r]/.test(text) ? '"' + text.replaceAll('"', '""') + '"' : text;
}).join(',')).join('\n') + '\n';

export async function buildCapabilities() {
  const dataset = await loadFullParticipationDataset();
  const years = [...dataset.years];
  const entityCodes = [...new Set(dataset.sources.map(source => source.entityCode))].sort();
  const entities = entityCodes.map(code => {
    const namesByYear = Object.fromEntries(years.map(year => [String(year), dataset.records.find(row => row.entityCode === code && row.year === year)!.entityName]));
    return { code, name: namesByYear[String(years.at(-1)!)], namesByYear };
  });
  const sexesByYear = Object.fromEntries(years.map(year => [String(year), SEXES.filter(sex => dataset.records.some(row => row.year === year && row.sex === sex))]));
  const key = (year: number, code: string, sex: string, age: string, section: string) => [year, code, sex, age, section].join('|');
  const records = new Map(dataset.records.map(row => [key(row.year, row.entityCode, row.sex, row.ageGroup, row.sectionType), row]));
  const cells: string[] = [], missing: unknown[][] = [], byYear: unknown[][] = [];
  for (const year of years) {
    let observed = 0, missingAllowed = 0, zeroDenominator = 0;
    for (const code of entityCodes) for (const sex of SEXES) for (const age of AGE_GROUPS) for (const section of SECTION_TYPES) {
      const row = records.get(key(year, code, sex, age, section));
      const state = row === undefined ? '0' : row.voted + row.didNotVote === 0 ? '1' : '2';
      cells.push(state);
      if (row) { observed++; if (state === '1') zeroDenominator++; }
      else {
        const supportedSex = (sexesByYear[String(year)] as readonly string[]).includes(sex);
        if (supportedSex) missingAllowed++;
        missing.push([year, code, sex, age, section, supportedSex ? 'no_observed_records' : 'category_not_in_year']);
      }
    }
    const possibleGlobal = entityCodes.length * SEXES.length * AGE_GROUPS.length * SECTION_TYPES.length;
    const possibleWithYearSexes = entityCodes.length * sexesByYear[String(year)].length * AGE_GROUPS.length * SECTION_TYPES.length;
    byYear.push([year, entityCodes.length, observed, possibleGlobal, possibleGlobal - observed, possibleWithYearSexes, missingAllowed, zeroDenominator]);
  }
  const comparisons: unknown[][] = [];
  for (const [i, yearA] of years.entries()) for (const yearB of years.slice(i + 1)) {
    let bothPresent = 0, missingOne = 0, missingBoth = 0;
    for (const code of entityCodes) for (const sex of SEXES) for (const age of AGE_GROUPS) for (const section of SECTION_TYPES) {
      const a = records.has(key(yearA, code, sex, age, section));
      const b = records.has(key(yearB, code, sex, age, section));
      if (a && b) bothPresent++; else if (a || b) missingOne++; else missingBoth++;
    }
    comparisons.push([yearA, yearB, bothPresent, missingOne, missingBoth, entityCodes.length * SEXES.length * AGE_GROUPS.length * SECTION_TYPES.length]);
  }
  // Publication timestamp fixed for catalog version 1.0.0 (2026-10-22 in America/Monterrey).
  // Rebuilding this release preserves its metadata and bytes.
  const catalog = {
    schemaVersion: 'ccpc-capabilities/v1', catalogVersion: '1.0.0', generatedAt: '2026-10-23T01:27:34Z',
    dataset: { kind: dataset.kind, schemaVersion: dataset.schemaVersion, fileSha256: CCPC_FULL_FILE_SHA256,
      recordsSha256: CCPC_FULL_RECORDS_SHA256, recordCount: dataset.records.length, sourceCount: dataset.sources.length },
    dimensions: { years, entities, sexes: [...SEXES], sexesByYear, ageGroups: [...AGE_GROUPS], sectionTypes: [...SECTION_TYPES] },
    matrix: { axes: ['year', 'entityCode', 'sex', 'ageGroup', 'sectionType'],
      shape: [years.length, entities.length, SEXES.length, AGE_GROUPS.length, SECTION_TYPES.length],
      encoding: { '0': 'no_records', '1': 'records_without_official_denominator', '2': 'records_with_official_denominator' },
      cells: cells.join(''), statistics: { possible: cells.length, observed: dataset.records.length, missing: missing.length,
        zeroDenominator: cells.filter(cell => cell === '1').length } },
    queries: ['getParticipationSummary', 'compareElections', 'getParticipationBreakdown', 'getSupportingRecords'],
    breakdownDimensions: ['entity', 'year', 'sex', 'ageGroup', 'sectionType'], defaultYear: years.at(-1)!,
    metricDefinitions: {
      participation: { field: 'ccpcParticipationPct', denominator: 'voted+didNotVote', unit: 'percent' },
      abstention: { field: 'ccpcAbstentionPct', denominator: 'voted+didNotVote', unit: 'percent' }, zeroDenominator: 'null',
    },
    comparisonPolicy: { minimumYears: 2, maximumYears: years.length, requireDataInEveryYear: true,
      requireExplicitCategoriesInEveryYear: true, missingCells: 'never_impute',
      warnings: ['ELECTIONS_NOT_A_PANEL', 'CARTOGRAPHIC_FRAMES_MAY_DIFFER', 'SEX_CATEGORIES_MAY_DIFFER'] },
    outOfScope: [
      { id: 'party_candidate_results', question: '¿Qué partido o candidato ganó y cuántos votos recibió?', reason: 'CCPC registra asistencia a votar, no la opción elegida ni resultados por candidatura.' },
      { id: 'fine_geography', question: '¿Cuál fue la participación en un municipio, distrito, casilla o sección específica?', reason: 'El agregado entregado conserva entidad y tipo de sección, no identificadores geográficos más finos.' },
      { id: 'individuals', question: '¿Votó una persona determinada?', reason: 'Sólo hay conteos agregados; no identidades ni trayectorias individuales.' },
      { id: 'exact_age', question: '¿Cuántas personas de exactamente 23 años votaron?', reason: 'Las edades están agrupadas; no se puede desagregar ni imputar una edad exacta.' },
      { id: 'other_years', question: '¿Qué pasó en 2006, 2022, 2023 o 2027?', reason: 'Sólo están disponibles 2009, 2012, 2015, 2018, 2021 y 2024.' },
      { id: 'other_characteristics', question: '¿Cómo participaron menores de 18 años o personas por ingreso, escolaridad o etnia?', reason: 'Esas poblaciones o dimensiones no están presentes en el agregado.' },
      { id: 'causality_prediction', question: '¿Por qué cambió la participación y quién votará en la próxima elección?', reason: 'Los cortes describen participación observada; no permiten atribuir causas ni predecir conductas.' },
      { id: 'panel_equivalence', question: '¿Las mismas personas o secciones cambiaron su conducta entre elecciones?', reason: 'Los cortes y marcos cartográficos difieren; no son un panel longitudinal.' },
      { id: 'nonbinary_history', question: '¿Cómo participó la categoría no_binario antes de 2024?', reason: 'Esa categoría sólo aparece en 2024. Su ausencia anterior no equivale a cero.' },
    ],
    questionTemplates: [
      { id: 'participation', title: '¿Cuál fue la participación y la abstención oficiales?', query: 'getParticipationSummary' },
      { id: 'by_sex', title: '¿Cómo se distribuyó la participación por sexo?', query: 'getParticipationBreakdown', dimension: 'sex' },
      { id: 'by_age', title: '¿Cómo se distribuyó la participación por grupo de edad?', query: 'getParticipationBreakdown', dimension: 'ageGroup' },
      { id: 'by_entity', title: '¿Cómo se distribuyó la participación por entidad?', query: 'getParticipationBreakdown', dimension: 'entity' },
      { id: 'by_section', title: '¿Cómo se distribuyó la participación por tipo de sección?', query: 'getParticipationBreakdown', dimension: 'sectionType' },
      { id: 'comparison', title: '¿Cuántos puntos porcentuales cambió la participación entre elecciones?', query: 'compareElections' },
      { id: 'support', title: '¿Qué registros agregados respaldan la respuesta?', query: 'getSupportingRecords' },
    ],
  };
  validateCapabilitiesCatalog(catalog);
  await mkdir(OUTPUT, { recursive: true });
  const bytes = JSON.stringify(catalog, null, 2) + '\n';
  await writeFile(join(OUTPUT, 'capabilities.json'), bytes);
  await writeFile(join(OUTPUT, 'missing-combinations.csv'), csv(['year', 'entityCode', 'sex', 'ageGroup', 'sectionType', 'reason'], missing));
  await writeFile(join(OUTPUT, 'matrix-by-year.csv'), csv(['year', 'entities', 'observed', 'possibleGlobal', 'missingGlobal', 'possibleWithYearSexes', 'missingWithYearSexes', 'zeroDenominator'], byYear));
  await writeFile(join(OUTPUT, 'comparison-coverage.csv'), csv(['yearA', 'yearB', 'bothPresent', 'missingOne', 'missingBoth', 'totalAtomicSelections'], comparisons));
  const pin = `/** DATA-05 release pin: generated from the audited DATA-04 aggregate. */\nexport const CCPC_CAPABILITIES_FILE_SHA256 = '${hash(bytes)}';\n`;
  await writeFile(join(ROOT, 'src/data/capabilities-release.ts'), pin);
  const source = await readFile(join(ROOT, 'src/client/coverage-client.ts'), 'utf8');
  const browser = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.ES2022, removeComments: false } });
  if (browser.diagnostics?.length) throw new Error('No se pudo generar el módulo de navegador.');
  await mkdir(join(ROOT, 'examples/data05'), { recursive: true });
  await writeFile(join(ROOT, 'examples/data05/coverage-client.js'), '// Generated from src/client/coverage-client.ts by npm run ccpc:catalog:build\n' + browser.outputText);
  const names = ['capabilities.json', 'missing-combinations.csv', 'matrix-by-year.csv', 'comparison-coverage.csv'];
  const checksums = await Promise.all(names.map(async name => `${hash(await readFile(join(OUTPUT, name)))}  ${name}\n`));
  await writeFile(join(OUTPUT, 'checksums.sha256'), checksums.join(''));
  return { catalogSha256: hash(bytes), catalogBytes: Buffer.byteLength(bytes), statistics: catalog.matrix.statistics, byYear, comparisons };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  buildCapabilities().then(result => console.log(JSON.stringify(result, null, 2)))
    .catch(error => { console.error(error); process.exitCode = 1; });
}
