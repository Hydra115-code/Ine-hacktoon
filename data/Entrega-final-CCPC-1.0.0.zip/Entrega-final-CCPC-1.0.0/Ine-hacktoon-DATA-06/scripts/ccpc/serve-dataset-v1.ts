/** Local reference integration, using the same catalog and evaluator in frontend/backend. */
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { createFrozenParticipationService } from '../../src/data/dataset-v1.ts';

const service = await createFrozenParticipationService();
const port = Number(process.env.CCPC_RELEASE_PORT ?? 4186);
if (!Number.isSafeInteger(port) || port < 0 || port > 65535) throw new Error('CCPC_RELEASE_PORT inválido.');
const catalogBytes = Buffer.from(JSON.stringify(service.getCatalog(), null, 2) + '\n');
const metadataBytes = Buffer.from(JSON.stringify(service.getDatasetMetadata(), null, 2) + '\n');
const releaseBytes = Buffer.from(JSON.stringify(service.getRelease(), null, 2) + '\n');
const html = await readFile(new URL('../../examples/data06/index.html', import.meta.url));
const javascript = await readFile(new URL('../../examples/data05/coverage-client.js', import.meta.url));
const server = createServer(async (request, response) => {
  const send = (status: number, type: string, bytes: string | Buffer) => {
    response.writeHead(status, { 'content-type': type, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
    response.end(bytes);
  };
  try {
    if (request.method === 'GET' && request.url === '/') return send(200, 'text/html; charset=utf-8', html);
    if (request.method === 'GET' && request.url === '/coverage-client.js') return send(200, 'text/javascript; charset=utf-8', javascript);
    if (request.method === 'GET' && request.url === '/api/capabilities') return send(200, 'application/json; charset=utf-8', catalogBytes);
    if (request.method === 'GET' && request.url === '/api/dataset') return send(200, 'application/json; charset=utf-8', metadataBytes);
    if (request.method === 'GET' && request.url === '/api/release') return send(200, 'application/json; charset=utf-8', releaseBytes);
    if (request.method === 'POST' && request.url === '/api/query') {
      const chunks: Buffer[] = []; let size = 0;
      for await (const chunk of request) {
        size += Buffer.byteLength(chunk);
        if (size > 65536) { send(413, 'application/json', '{"error":"request_too_large"}'); return; }
        chunks.push(Buffer.from(chunk));
      }
      let input: unknown;
      try { input = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
      catch { return send(400, 'application/json', '{"error":"invalid_json"}'); }
      return send(200, 'application/json; charset=utf-8', JSON.stringify(service.execute(input)));
    }
    send(404, 'application/json', '{"error":"not_found"}');
  } catch (error) {
    console.error(error);
    send(500, 'application/json', '{"error":"query_failed"}');
  }
});
server.listen(port, '127.0.0.1', () => {
  const address = server.address();
  console.log(`CCPC dataset 1.0.0: http://127.0.0.1:${typeof address === 'object' && address ? address.port : port}`);
});
