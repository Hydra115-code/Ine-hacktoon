/** Local reference integration, using the same catalog and evaluator in frontend/backend. */
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { createCoverageParticipationService } from '../../src/data/coverage-participation.ts';

const service = await createCoverageParticipationService();
const port = Number(process.env.CCPC_DEMO_PORT ?? 4175);
if (!Number.isSafeInteger(port) || port < 0 || port > 65535) throw new Error('CCPC_DEMO_PORT inválido.');
const catalogBytes = await readFile(new URL('../../data/ccpc/catalog/capabilities.json', import.meta.url));
const html = await readFile(new URL('../../examples/data05/index.html', import.meta.url));
const javascript = await readFile(new URL('../../examples/data05/coverage-client.js', import.meta.url));
const server = createServer(async (request, response) => {
  const send = (status: number, type: string, bytes: string | Buffer) => {
    response.writeHead(status, { 'content-type': type, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
    response.end(bytes);
  };
  try {
    if (request.method === 'GET' && request.url === '/') return send(200, 'text/html; charset=utf-8', html);
    if (request.method === 'GET' && request.url === '/coverage-client.js') return send(200, 'text/javascript; charset=utf-8', javascript);
    if (request.method === 'GET' && request.url === '/api/capabilities') return send(200, 'application/json; charset=utf-8', catalogBytes);
    if (request.method === 'POST' && request.url === '/api/query') {
      const chunks: Buffer[] = []; let size = 0;
      for await (const chunk of request) {
        size += Buffer.byteLength(chunk);
        if (size > 65536) { send(413, 'application/json', '{"error":"request_too_large"}'); return; }
        chunks.push(Buffer.from(chunk));
      }
      let input: unknown;
      try { input = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
      catch { return send(400, 'application/json', '{"error":"invalid_json"}'); }
      return send(200, 'application/json; charset=utf-8', JSON.stringify(service.execute(input)));
    }
    send(404, 'application/json', '{"error":"not_found"}');
  } catch (error) {
    console.error(error);
    send(500, 'application/json', '{"error":"query_failed"}');
  }
});
server.listen(port, '127.0.0.1', () => {
  const address = server.address();
  console.log(`CCPC DATA-05: http://127.0.0.1:${typeof address === 'object' && address ? address.port : port}`);
});
