/** DATA-06 acceptance over the frozen backend entry point. */
import assert from 'node:assert/strict';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createFrozenParticipationService, verifyDatasetV1 } from '../../src/data/dataset-v1.ts';
import { CCPC_DATASET_V1_RELEASE_SHA256 } from '../../src/data/dataset-v1-release.ts';
import { RELEASE_DIRECTORY, SCHEMA_FILES } from '../../src/data/dataset-v1-definition.ts';

export async function verifyFrozenDataset() {
  const verified = await verifyDatasetV1(), service = await createFrozenParticipationService();
  const metadata = service.getDatasetMetadata();
  assert.equal(verified.release.datasetVersion, '1.0.0'); assert.equal(verified.release.status, 'frozen');
  assert.equal(metadata.source.archives.length, 6); assert.equal(metadata.source.publisher, 'Instituto Nacional Electoral');
  assert.equal(metadata.extraction.date, '2026-10-22'); assert.equal(metadata.extraction.exactRowExtractionTimestamp, null);
  assert.equal(metadata.methodology.participation.denominator, 'voted+didNotVote');
  assert.equal(metadata.methodology.abstention.denominator, 'voted+didNotVote');
  assert.equal(metadata.privacy.directIdentifiersIncluded, false); assert.equal(metadata.privacy.anonymityGuarantee, false);
  assert.equal(service.getCatalog().dataset.fileSha256, verified.release.dataset.sha256);
  const queries = [
    service.getParticipationSummary({ year: 2024, entityCodes: ['19'] }),
    service.getParticipationBreakdown({ year: 2024, entityCodes: ['19'] }, 'sex'),
    service.getSupportingRecords({ year: 2024, entityCodes: ['19'] }),
    service.compareElections({ entityCodes: ['19'] }, [2021, 2024]),
  ];
  for (const query of queries) {
    assert.equal(query.status, 'ok'); assert.equal(query.schemaVersion, 'ccpc-query-response/v1');
    assert.equal(query.release.sha256, CCPC_DATASET_V1_RELEASE_SHA256);
  }
  const noData = service.getParticipationSummary({ year: 2024, entityCodes: ['03'], sexes: ['no_binario'] });
  assert.equal(noData.status, 'no_data'); assert.equal(noData.result, null);
  const zero = service.getParticipationSummary({ year: 2024, entityCodes: ['02'], sexes: ['no_binario'], ageGroups: ['20-24'], sectionTypes: ['urbana'] });
  assert.equal(zero.status, 'ok'); assert.ok(zero.result && 'totals' in zero.result);
  assert.equal(zero.result.totals!.ccpcParticipationPct, 0);
  return { schemaVersion: 'ccpc-data06-validation/v1', status: 'pass', runtime: { node: process.version }, datasetVersion: '1.0.0',
    releaseSha256: CCPC_DATASET_V1_RELEASE_SHA256, datasetSha256: verified.release.dataset.sha256,
    frozenArtifacts: verified.release.artifacts.length, lockedSchemaFiles: SCHEMA_FILES.length,
    sourceArchives: metadata.source.archives.length, frontendWarnings: metadata.warnings.length,
    freeze: verified.release.freeze, extraction: metadata.extraction,
    queryStatuses: queries.map(query => ({ query: query.result!.query, status: query.status, datasetVersion: query.release.datasetVersion })),
    noData: { status: noData.status, result: noData.result }, observedZero: { status: zero.status, ccpcParticipationPct: zero.result.totals!.ccpcParticipationPct },
    privacy: metadata.privacy,
    scope: 'Frozen package, backend module and supplied frontend; integration in external team repositories is not asserted.' };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  if (args.length && (args.length !== 2 || args[0] !== '--output')) throw new Error('Uso: verify-dataset-v1.ts [--output REPORTE.json]');
  verifyFrozenDataset().then(async report => {
    if (args.length) { const output = resolve(args[1]); await mkdir(dirname(output), { recursive: true }); await writeFile(output, JSON.stringify(report, null, 2) + '\n'); }
    console.log(JSON.stringify(report, null, 2));
  }).catch(error => { console.error(error); process.exitCode = 1; });
}
