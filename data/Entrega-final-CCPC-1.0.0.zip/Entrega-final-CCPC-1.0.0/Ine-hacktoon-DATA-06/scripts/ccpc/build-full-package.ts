/** DATA-04: empaquetado posterior al ETL original, sin modificar sus transformaciones. */
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { AGE_GROUPS, ALLOWED_YEARS, CivicParticipationError, SECTION_TYPES, SEXES } from '../../src/domain/civic/participation.ts';
import type { ParticipationDataset } from '../../src/domain/civic/participation.ts';
import { decodeCompactDataset } from '../../src/data/full-participation.ts';
import { canonicalJson, sha256 } from './etl-io.ts';
import { validateFile } from './validate-data.ts';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
export const COMPACT_COLUMNS = ['sourceIndex', 'sexIndex', 'ageGroupIndex', 'sectionTypeIndex', 'nominalList', 'voted', 'didNotVote', 'unspecified', 'sourceRows'] as const;

export function encodeCompactDataset(dataset: ParticipationDataset) {
  if (dataset.kind !== 'full' || dataset.years.join(',') !== ALLOWED_YEARS.join(',') || dataset.sources.length !== 192) {
    throw new CivicParticipationError('FULL_REQUIRED', 'DATA-04 requiere los seis años y las 32 entidades completas.');
  }
  const sourceIndex = new Map(dataset.sources.map((source, index) => [source.id, index]));
  const names = new Map(dataset.records.map(row => [row.sourceId, row.entityName]));
  const compact = {
    schemaVersion: 'ccpc-compact/v1', kind: 'full', scope: dataset.scope,
    years: dataset.years, metricDefinitions: dataset.metricDefinitions,
    dictionaries: { sex: SEXES, ageGroup: AGE_GROUPS, sectionType: SECTION_TYPES },
    sources: dataset.sources, sourceEntityNames: dataset.sources.map(source => names.get(source.id)),
    columns: COMPACT_COLUMNS,
    records: dataset.records.map(row => [
      sourceIndex.get(row.sourceId), SEXES.indexOf(row.sex), AGE_GROUPS.indexOf(row.ageGroup as typeof AGE_GROUPS[number]),
      SECTION_TYPES.indexOf(row.sectionType), row.nominalList, row.voted, row.didNotVote, row.unspecified, row.sourceRows,
    ]),
    recordsSha256: sha256(canonicalJson(dataset.records)),
  };
  // Verifica reconstrucción exacta, incluidas tasas oficiales, categorías y procedencia.
  const restored = decodeCompactDataset(compact);
  if (canonicalJson(restored) !== canonicalJson(dataset)) {
    throw new CivicParticipationError('LOSSY_PACKAGE', 'El paquete compacto no reconstruye exactamente el dataset validado.');
  }
  return compact;
}

export async function main(args = process.argv.slice(2)): Promise<void> {
  if (args.includes('--help')) {
    console.log('node scripts/ccpc/build-full-package.ts --released-at ISO [--input PATH] [--reference PATH] [--output DIR] [--acquisition PATH] [--update-release-pin]\nRequiere ETL y referencia DATA-01 completos. Conserva este released-at para reproducir también el manifiesto.');
    return;
  }
  const options: Record<string, string> = {};
  let updatePin = false;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--update-release-pin' && !updatePin) { updatePin = true; continue; }
    const flag = args[i];
    if (!['--released-at', '--input', '--reference', '--output', '--acquisition'].includes(flag) || !args[i + 1] || args[i + 1].startsWith('--') || flag in options) {
      throw new Error(`Argumento inválido o repetido: ${flag}`);
    }
    options[flag] = args[++i];
  }
  const releasedAt = options['--released-at'];
  if (!releasedAt || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(releasedAt) || Number.isNaN(Date.parse(releasedAt))) {
    throw new Error('Se requiere --released-at con fecha ISO UTC explícita.');
  }
  const input = resolve(options['--input'] ?? join(ROOT, 'data/ccpc/processed/data02/participation.json'));
  const reference = resolve(options['--reference'] ?? join(dirname(input), '../entidad.csv'));
  const out = resolve(options['--output'] ?? join(ROOT, 'data/ccpc/full'));
  if (out.split(/[\\/]/).includes('sample')) throw new Error('Un paquete full no puede escribirse en sample.');
  if (out === dirname(input)) throw new Error('El paquete portátil necesita un directorio distinto del resultado DATA-02.');
  const dataset = await validateFile(input, undefined, reference);
  const compact = encodeCompactDataset(dataset);
  // Orden de claves Unicode estable, sin espacios repetidos ni métricas derivables por fila.
  const bytes = JSON.stringify(JSON.parse(canonicalJson(compact))) + '\n';
  const hash = sha256(bytes);
  const acquisition: unknown = options['--acquisition'] ? JSON.parse(await readFile(resolve(options['--acquisition']), 'utf8')) : null;
  const pkg = JSON.parse(await readFile(join(ROOT, 'package.json'), 'utf8')) as { version: string };
  const manifest = {
    schemaVersion: 'ccpc-full-package/v1', packageVersion: pkg.version, generatedAt: releasedAt,
    kind: 'full', scope: 'entity', years: dataset.years,
    entityCodes: Array.from({ length: 32 }, (_, index) => String(index + 1).padStart(2, '0')),
    dataset: { file: 'participation.compact.json', bytes: Buffer.byteLength(bytes), sha256: hash,
      recordsSha256: compact.recordsSha256, recordCount: dataset.records.length, sourceCount: dataset.sources.length,
      rawRowCount: dataset.sources.reduce((sum, source) => sum + source.rawRows, 0) },
    upstream: { schemaVersion: dataset.schemaVersion, datasetSha256: sha256(await readFile(input)),
      aggregateCsvSha256: sha256(await readFile(reference)),
      sourceAnchorsSha256: sha256(await readFile(join(ROOT, 'data/ccpc/source-anchors.json'))),
      validatedWith: 'DATA-02 validateFile: esquema, checksums, catálogo, anclas, CSV y sourceRows' },
    officialMetrics: {
      participation: { numerator: 'voted', denominator: 'voted+didNotVote', field: 'ccpcParticipationPct', unit: 'percent' },
      abstention: { numerator: 'didNotVote', denominator: 'voted+didNotVote', field: 'ccpcAbstentionPct', unit: 'percent' },
      unspecified: { numerator: 'unspecified', denominator: 'nominalList', field: 'unspecifiedPct', unit: 'percent' },
      zeroDenominator: null, aggregation: 'sum_counts_then_divide',
      reference: 'https://ine.mx/wp-content/uploads/2025/06/Manual-Conteos-Censales-2009-2024.pdf#page=17',
    },
    acquisition,
    originalRecordsIncluded: false,
  };
  await mkdir(out, { recursive: true });
  const manifestBytes = canonicalJson(manifest);
  await writeFile(join(out, 'participation.compact.json'), bytes);
  await writeFile(join(out, 'manifest.json'), manifestBytes);
  await writeFile(join(out, 'checksums.sha256'), `${hash}  participation.compact.json\n${sha256(manifestBytes)}  manifest.json\n`);
  if (updatePin) {
    const path = join(ROOT, 'src/data/ccpc-release.ts');
    const original = await readFile(path, 'utf8');
    const updated = original.replace(/(CCPC_FULL_FILE_SHA256\s*=\s*['"])[a-f0-9]{64}(['"])/, `$1${hash}$2`);
    if (updated === original && !original.includes(hash)) throw new Error('No se encontró el pin de publicación.');
    await writeFile(path, updated);
  }
  console.log(`DATA-04: ${dataset.records.length} grupos, 192 fuentes, ${Buffer.byteLength(bytes)} bytes, SHA-256 ${hash}`);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error(error); process.exitCode = 1; });
}
