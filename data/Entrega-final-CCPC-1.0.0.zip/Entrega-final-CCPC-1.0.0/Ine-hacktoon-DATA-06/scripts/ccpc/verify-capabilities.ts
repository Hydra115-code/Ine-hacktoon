/** Exhaustive DATA-05 acceptance: direct aggregate oracle, browser parity and backend execution. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadFullParticipationDataset } from '../../src/data/full-participation.ts';
import { createCoverageParticipationService, loadCapabilitiesCatalog } from '../../src/data/coverage-participation.ts';
import { createCatalogClient } from '../../src/client/coverage-client.ts';
import type { CoverageFilters, CoverageRequest } from '../../src/client/coverage-client.ts';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
export async function verifyCapabilities() {
  const catalog = await loadCapabilitiesCatalog(), dataset = await loadFullParticipationDataset();
  const client = createCatalogClient(catalog), backend = await createCoverageParticipationService();
  const browserModule = await import(new URL('../../examples/data05/coverage-client.js', import.meta.url).href);
  const browser = browserModule.createCatalogClient(catalog);
  assert.deepEqual(browser.getCatalog(), backend.getCatalog());
  const { years, entities, sexes, ageGroups, sectionTypes } = catalog.dimensions;
  const recordKey = (year: number, code: string, sex: string, age: string, section: string) => [year, code, sex, age, section].join('|');
  const observed = new Set(dataset.records.map(row => recordKey(row.year, row.entityCode, row.sex, row.ageGroup, row.sectionType)));
  let atomicSelections = 0, observedSelections = 0, absentSelections = 0, onboardingSuggestions = 0;
  let comparisonSelections = 0, validComparisons = 0, invalidComparisons = 0;
  for (const year of years) for (const entity of entities) for (const sex of sexes) for (const age of ageGroups) for (const section of sectionTypes) {
    const filters = { year, entityCodes: [entity.code], sexes: [sex], ageGroups: [age], sectionTypes: [section] };
    const request: CoverageRequest = { query: 'getParticipationSummary', filters };
    const present = observed.has(recordKey(year, entity.code, sex, age, section));
    const result = client.evaluate(request);
    assert.equal(result.status, present ? 'ok' : 'no_data');
    assert.deepEqual(browser.evaluate(request), result);
    const questions = client.getOnboardingQuestions(filters, 20);
    if (!present) assert.equal(questions.length, 0);
    for (const question of questions) {
      assert.equal(client.evaluate(question.request).status, 'ok');
      assert.equal(browser.evaluate(question.request).status, 'ok');
      for (const selectedYear of question.request.years ?? [year]) {
        assert.ok(observed.has(recordKey(selectedYear, entity.code, sex, age, section)));
      }
    }
    onboardingSuggestions += questions.length; atomicSelections++;
    if (present) observedSelections++; else absentSelections++;
  }
  for (const [index, yearA] of years.entries()) for (const yearB of years.slice(index + 1)) {
    for (const entity of entities) for (const sex of sexes) for (const age of ageGroups) for (const section of sectionTypes) {
      const present = observed.has(recordKey(yearA, entity.code, sex, age, section)) && observed.has(recordKey(yearB, entity.code, sex, age, section));
      const request: CoverageRequest = { query: 'compareElections', filters: { entityCodes: [entity.code], sexes: [sex], ageGroups: [age], sectionTypes: [section] }, years: [yearA, yearB] };
      const result = client.evaluate(request);
      assert.equal(result.status, present ? 'ok' : 'no_data');
      assert.deepEqual(browser.evaluate(request), result);
      comparisonSelections++; if (present) validComparisons++; else invalidComparisons++;
    }
  }
  const backendQueries: Record<string, number> = {};
  const recordExecution = (request: CoverageRequest) => {
    const result = backend.execute(request);
    assert.equal(result.status, 'ok');
    assert.equal(result.result?.evidence.matchedRecords, result.coverage.matchedCells);
    backendQueries[request.query] = (backendQueries[request.query] ?? 0) + 1;
  };
  // Every year/entity onboarding context is exercised against the real backend, not a mock.
  for (const year of years) for (const entity of entities) {
    const filters: CoverageFilters = { year, entityCodes: [entity.code] };
    const questions = browser.getOnboardingQuestions(filters, 20);
    assert.ok(questions.length > 0);
    for (const question of questions) recordExecution(question.request);
  }
  const missingEndpoint = backend.compareElections({ entityCodes: ['02'], sexes: ['mujer'], ageGroups: ['100+'], sectionTypes: ['mixta'] }, [2009, 2012]);
  assert.equal(missingEndpoint.status, 'no_data'); assert.equal(missingEndpoint.result, null);
  const outsideScope = backend.execute({ query: 'getParticipationSummary', filters: { municipality: '001', year: 2024 } });
  assert.equal(outsideScope.status, 'no_data'); assert.equal(outsideScope.result, null);
  const measuredZero = backend.getParticipationSummary({ year: 2024, entityCodes: ['02'], sexes: ['no_binario'], ageGroups: ['20-24'], sectionTypes: ['urbana'] });
  assert.equal(measuredZero.status, 'ok');
  assert.ok(measuredZero.result && 'totals' in measuredZero.result && measuredZero.result.totals);
  assert.equal(measuredZero.result.totals.ccpcParticipationPct, 0);
  const report = { schemaVersion: 'ccpc-capabilities-verification/v1', status: 'pass',
    runtime: { node: process.version }, catalogSha256: createHash('sha256').update(await readFile(join(ROOT, 'data/ccpc/catalog/capabilities.json'))).digest('hex'),
    statistics: catalog.matrix.statistics,
    exhaustiveAtomic: { checked: atomicSelections, observed: observedSelections, absent: absentSelections, browserAndBackendDecisionParity: true },
    exhaustiveComparisons: { checked: comparisonSelections, valid: validComparisons, invalid: invalidComparisons, browserAndBackendDecisionParity: true },
    onboarding: { checkedAtomicContexts: atomicSelections, validatedSuggestions: onboardingSuggestions,
      absentContextsWithSuggestions: 0, realBackendContexts: years.length * entities.length, realBackendExecutions: Object.values(backendQueries).reduce((a, b) => a + b, 0), queries: backendQueries },
    examples: { missingEndpoint, outsideScope, measuredZero },
    limitations: ['Reference frontend and backend module verified; integration into Bryan’s separate application is not included.'] };
  return report;
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  if (args.length && (args.length !== 2 || args[0] !== '--output')) throw new Error('Uso: verify-capabilities.ts [--output reporte.json]');
  verifyCapabilities().then(async report => {
    if (args.length) { const output = resolve(args[1]); await mkdir(dirname(output), { recursive: true }); await writeFile(output, JSON.stringify(report, null, 2) + '\n'); }
    console.log(JSON.stringify(report, null, 2));
  }).catch(error => { console.error(error); process.exitCode = 1; });
}
