import { createHash, randomUUID } from 'node:crypto';
import { mkdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { inspectArchive } from './inspect-data.ts';
import { sortRows, toCsv } from './model.ts';
import { compareEntityNames } from './quality.ts';
import { validateCatalog } from './validation.ts';
import { assertFullOutputDirectory, normalizeInspectedArchives } from './normalize-data.ts';
import { publishDataset } from './etl-io.ts';
import { validateFile } from './validate-data.ts';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
// Same independent DATA-01 anchor required by validateFile. Never regenerate it.
const SOURCE_ANCHORS_SHA256 = '24b8f676d2a8ed7a05d32c1abdfcfc277f38edfc47c42e86220efc711b4fcdec';
const sha256 = (bytes: string | Buffer) => createHash('sha256').update(bytes).digest('hex');

type Options = { rawDir: string; outputDir: string; checkpointsDir?: string; help: boolean };

export function parseFullRebuildArguments(args: string[]): Options {
  const options: Options = { rawDir: join(ROOT, 'data/ccpc/raw'), outputDir: join(ROOT, 'data/ccpc/processed'), help: false };
  const seen = new Set<string>();
  for (let i = 0; i < args.length; i++) {
    const flag = args[i] === '-h' ? '--help' : args[i];
    if (seen.has(flag)) throw new Error(`Argumento repetido: ${flag}`);
    seen.add(flag);
    if (flag === '--help') { options.help = true; continue; }
    if (!['--raw-dir', '--output', '--checkpoints'].includes(flag) || !args[i + 1] || args[i + 1].startsWith('-')) {
      throw new Error(`Argumento inválido o sin valor: ${flag}`);
    }
    const value = resolve(args[++i]);
    if (flag === '--raw-dir') options.rawDir = value;
    else if (flag === '--output') options.outputDir = value;
    else options.checkpointsDir = value;
  }
  return options;
}

async function atomicWrite(path: string, data: string | Buffer): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  const temp = `${path}.${randomUUID()}.part`;
  try { await writeFile(temp, data); await rename(temp, path); }
  finally { await rm(temp, { force: true }); }
}

/** Orchestrates the original ETL exports in one raw-data pass; never edits sample. */
export async function rebuildFullData(options: Omit<Options, 'help'>): Promise<void> {
  assertFullOutputDirectory(options.outputDir);
  const sources = validateCatalog(JSON.parse(await readFile(join(ROOT, 'data/ccpc/sources.json'), 'utf8')), 'all');
  const anchorBytes = await readFile(join(ROOT, 'data/ccpc/source-anchors.json'));
  if (sha256(anchorBytes) !== SOURCE_ANCHORS_SHA256) throw new Error('Las anclas publicadas DATA-01 fueron alteradas.');
  const anchors = JSON.parse(anchorBytes.toString('utf8')) as { aggregateCsvSha256: string };
  const inspected: Awaited<ReturnType<typeof inspectArchive>>[] = [];
  const acquisitions: Array<Record<string, unknown>> = [];
  console.log('DATA-04: inspectArchive → normalizeInspectedArchives → publishDataset → validateFile; ETL original, un recorrido, seis años.');
  const began = performance.now();
  for (const source of sources) {
    const startedAt = new Date().toISOString();
    const sourceBegan = performance.now();
    const result = await inspectArchive(source, join(options.rawDir, source.filename));
    inspected.push(result);
    // inspectArchive has already validated any adjacent downloads.json record.
    // A missing record remains unknown: filesystem timestamps are not acquisition.
    acquisitions.push({ year: source.year, filename: source.filename, url: source.url,
      finalUrl: result.report.download_record?.final_url ?? null, landingUrl: source.landing_url,
      sha256: result.report.archive_sha256, bytes: (await stat(join(options.rawDir, source.filename))).size,
      downloadedAt: result.report.downloaded_at, verifiedAt: new Date().toISOString(),
      originalDownloadRecord: result.report.download_record,
      verification: 'inspectArchive verified ZIP SHA-256 against pinned sources.json and validated original acquisition metadata when present' });
    if (options.checkpointsDir) {
      await atomicWrite(join(options.checkpointsDir, `inspected-${source.year}.json`), JSON.stringify({
        rows: result.rows, groupSourceRows: [...result.groupSourceRows], report: result.report,
        dictionary: { ...result.dictionary, bytes: result.dictionary.bytes.toString('base64') },
      }) + '\n');
    }
    console.log(JSON.stringify({ stage: 'inspectArchive', year: source.year, startedAt,
      completedAt: new Date().toISOString(), elapsedSeconds: (performance.now() - sourceBegan) / 1000,
      rawRows: result.report.raw_rows, aggregateRows: result.rows.length, entities: result.report.entities.length }));
  }

  // Same publication wrapper as inspect-data.ts main, using its original helpers.
  const rows = sortRows(inspected.flatMap(result => result.rows));
  const csv = toCsv(rows);
  const nameComparison = compareEntityNames(inspected.map(result => ({ year: result.report.year, names: result.report.names })));
  if (nameComparison.within_year_conflicts.length) throw new Error('Nombres originales contradictorios dentro del mismo año.');
  const report = { schema_version: 1, inspected_at: new Date().toISOString(), scope: 'entidad',
    group_key: ['anio','entidad_clave','sexo_codigo','grupo_edad','tipo_seccion'],
    age_groups: '18-19,20-24,...,95-99,100+', denominator: 'SV+NV', percentages_unit: 'percent',
    zero_denominator: null, aggregate_csv_sha256: sha256(csv),
    sources: inspected.map(result => result.report), entity_name_comparison: nameComparison };
  if (report.aggregate_csv_sha256 !== anchors.aggregateCsvSha256) throw new Error('CSV completo distinto del SHA-256 independiente DATA-01.');
  // Legacy DATA-02 validation permits only historical release acquisition dates
  // or null. Keep that metadata compatible with the fixed DATA-02 publication;
  // known NEW acquisition dates remain intact in inspection.json and the external
  // acquisition.json. No original ETL function or count is changed, and no dates
  // are invented or attributed to a different download.
  const legacyInput = inspected.map(result => ({ ...result,
    report: { ...result.report, downloaded_at: null, download_record: null },
  }));
  const { full } = normalizeInspectedArchives(legacyInput);
  await atomicWrite(join(options.outputDir, 'entidad.csv'), csv);
  await atomicWrite(join(options.outputDir, 'inspection.json'), JSON.stringify(report, null, 2) + '\n');
  await atomicWrite(join(options.outputDir, 'acquisition.json'), JSON.stringify({
    schemaVersion: 'ccpc-data04-acquisition/v1',
    acquisitionMethod: 'Original adjacent downloads.json records validated by unchanged inspectArchive',
    verifiedAt: new Date().toISOString(), downloads: acquisitions,
    etlAcquisitionNote: 'Known acquisition dates and original download records are retained here and in inspection.json. Legacy normalized DATA-02 downloadedAt is null for compatibility with its fixed historical publication; unknown acquisition remains unknown.',
  }, null, 2) + '\n');
  console.log(`DATA-01 verificado: ${rows.length} agregados; SHA-256 ${report.aggregate_csv_sha256}`);
  await publishDataset(join(options.outputDir, 'data02'), full);
  console.log(`DATA-02: ${full.records.length} grupos, ${full.sources.length} fuentes, ${full.sources.reduce((sum, source) => sum + source.rawRows, 0)} filas crudas. Salida: ${join(options.outputDir, 'data02')}`);
  const validated = await validateFile(join(options.outputDir, 'data02/participation.json'), undefined, join(options.outputDir, 'entidad.csv'));
  console.log(`VALIDADO: ${validated.kind}, ${validated.records.length} grupos, años ${validated.years.join(',')}; fórmulas, conteos, procedencia y referencias de origen correctos.`);
  console.log(JSON.stringify({ stage: 'full-complete', elapsedSeconds: (performance.now() - began) / 1000,
    rawRows: full.sources.reduce((sum, source) => sum + source.rawRows, 0), aggregateRows: full.records.length,
    sourceCount: full.sources.length, years: full.years, output: options.outputDir }));
}

export async function main(args = process.argv.slice(2)): Promise<void> {
  const options = parseFullRebuildArguments(args);
  if (options.help) {
    console.log('Uso: node scripts/ccpc/rebuild-full-data.ts [--raw-dir DIR] [--output DIR] [--checkpoints DIR]\n'
      + 'Procesa los seis ZIP oficiales con las funciones ETL originales en un recorrido.\n'
      + 'Default: --raw-dir data/ccpc/raw; --output data/ccpc/processed (desde la raíz del módulo).\n'
      + 'Publica entidad.csv, inspection.json, acquisition.json y data02/; valida contra las anclas independientes DATA-01.\n'
      + '--checkpoints guarda inspecciones por año solo cuando se solicita; no reutiliza inspecciones previas.\n'
      + 'La muestra y sus anclas se conservan intactas. Primero adquiera los ZIP mediante ccpc:download.');
    return;
  }
  await rebuildFullData(options);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error(`ERROR: ${(error as Error).message}`); process.exitCode = 1; });
}
