/** Regenerate to a fresh staging directory, compare all bytes and never mutate release 1.0.0. */
import { readdir, readFile, stat } from 'node:fs/promises';
import { resolve, dirname, join, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { verifyDatasetV1 } from '../../src/data/dataset-v1.ts';
import { RELEASE_DIRECTORY } from '../../src/data/dataset-v1-definition.ts';
import { CCPC_DATASET_V1_RELEASE_SHA256 } from '../../src/data/dataset-v1-release.ts';
import { buildDatasetV1 } from './build-dataset-v1.ts';
const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const args = process.argv.slice(2);
if (args.length !== 2 || args[0] !== '--output') throw new Error('Uso: regenerate-dataset-v1.ts --output DIRECTORIO_STAGING_VACIO');
const output = resolve(args[1]);
if (output === ROOT || output.startsWith(ROOT + sep)) throw new Error('IMMUTABLE_RELEASE: el staging debe estar fuera del paquete publicado.');
const existing = await stat(output).catch(() => null);
if (existing && (!existing.isDirectory() || (await readdir(output)).length > 0)) throw new Error('El directorio staging debe estar vacío.');
await verifyDatasetV1(ROOT);
const result = await buildDatasetV1(output);
if (result.releaseSha256 !== CCPC_DATASET_V1_RELEASE_SHA256) throw new Error('REPRODUCTION_MISMATCH: cambió el manifiesto de la versión congelada.');
for (const name of result.files) {
  if (!(await readFile(join(output, name))).equals(await readFile(join(ROOT, RELEASE_DIRECTORY, name)))) throw new Error(`REPRODUCTION_MISMATCH: ${name}`);
}
console.log(JSON.stringify({ status: 'pass', byteIdentical: true, ...result }, null, 2));
