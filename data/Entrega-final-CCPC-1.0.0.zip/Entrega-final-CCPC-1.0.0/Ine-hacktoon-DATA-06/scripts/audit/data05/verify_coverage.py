#!/usr/bin/env python3
"""Independently verify DATA-05 coverage with Python >= 3.10, stdlib only.

Reads the pinned DATA-04 compact aggregate directly. Does not import production
modules, execute TypeScript, download source data, or trust generated statistics.
The release pin authenticates the source aggregate; the matrix and every CSV row
are then rebuilt here using a separate implementation.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import re
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
YEARS = (2009, 2012, 2015, 2018, 2021, 2024)
ENTITIES = tuple(f"{number:02d}" for number in range(1, 33))
SEXES = ("hombre", "mujer", "no_binario")
AGES = ("18-19", *(f"{start}-{start + 4}" for start in range(20, 100, 5)), "100+")
SECTIONS = ("urbana", "mixta", "rural")
AXES = ("year", "entityCode", "sex", "ageGroup", "sectionType")
AUDITED_FILE_SHA = "d7e546928465d25702fe1b625eafb91c8435f7c5ddedd1c30a5278f89c29489c"
AUDITED_RECORDS_SHA = "8d06184746e12b21a5166117e37787537a6643a659493f12d9c6efef3fd44e38"
COMPACT_KEYS = {
    "columns", "dictionaries", "kind", "metricDefinitions", "records",
    "recordsSha256", "schemaVersion", "scope", "sourceEntityNames", "sources", "years",
}
CSV_HEADERS = {
    "missing-combinations.csv": (*AXES, "reason"),
    "matrix-by-year.csv": (
        "year", "entities", "observed", "possibleGlobal", "missingGlobal",
        "possibleWithYearSexes", "missingWithYearSexes", "zeroDenominator",
    ),
    "comparison-coverage.csv": (
        "yearA", "yearB", "bothPresent", "missingOne", "missingBoth", "totalAtomicSelections",
    ),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_json(path):
    def unique_object(pairs):
        output = {}
        for key, value in pairs:
            require(key not in output, f"Duplicate JSON key {key!r} in {path}")
            output[key] = value
        return output

    def reject_constant(token):
        raise ValueError(f"Invalid JSON number {token!r} in {path}")

    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique_object,
                      parse_constant=reject_constant)


def file_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def integer(value, minimum=0):
    return type(value) is int and minimum <= value <= 9_007_199_254_740_991


def read_release_pins(root):
    text = (root / "src/data/ccpc-release.ts").read_text(encoding="utf-8")
    output = {}
    for name in ("CCPC_FULL_FILE_SHA256", "CCPC_FULL_RECORDS_SHA256"):
        matches = re.findall(rf"^export const {name} = '([a-f0-9]{{64}})';$", text, re.MULTILINE)
        require(len(matches) == 1, f"Missing or ambiguous release pin {name}")
        output[name] = matches[0]
    for name in ("CCPC_FULL_RECORD_COUNT", "CCPC_FULL_SOURCE_COUNT"):
        matches = re.findall(rf"^export const {name} = ([0-9_]+);$", text, re.MULTILINE)
        require(len(matches) == 1, f"Missing or ambiguous release pin {name}")
        output[name] = int(matches[0].replace("_", ""))
    require(output["CCPC_FULL_FILE_SHA256"] == AUDITED_FILE_SHA,
            "Source release file pin differs from independently audited DATA-04 release")
    require(output["CCPC_FULL_RECORDS_SHA256"] == AUDITED_RECORDS_SHA,
            "Source records pin differs from independently audited DATA-04 release")
    require(output["CCPC_FULL_RECORD_COUNT"] == 20_755, "Unexpected source record-count release pin")
    require(output["CCPC_FULL_SOURCE_COUNT"] == 192, "Unexpected source-count release pin")
    return output


def expand_source(root, pins):
    path = root / "data/ccpc/full/participation.compact.json"
    digest = file_sha(path)
    require(digest == pins["CCPC_FULL_FILE_SHA256"], "DATA-04 compact file SHA-256 does not match release pin")
    data = load_json(path)
    require(set(data) == COMPACT_KEYS, "Unexpected compact source top-level fields")
    require(data["kind"] == "full" and data["scope"] == "entity", "Unexpected source kind or scope")
    require(data["schemaVersion"] == "ccpc-compact/v1", "Unexpected compact source schema")
    require(data["recordsSha256"] == pins["CCPC_FULL_RECORDS_SHA256"], "Source records SHA differs from release pin")
    require(data["years"] == list(YEARS), "Unexpected compact source years")
    require(data["columns"] == [
        "sourceIndex", "sexIndex", "ageGroupIndex", "sectionTypeIndex", "nominalList",
        "voted", "didNotVote", "unspecified", "sourceRows",
    ], "Unexpected compact source column layout")
    require(data["dictionaries"] == {
        "sex": list(SEXES), "ageGroup": list(AGES), "sectionType": list(SECTIONS),
    }, "Unexpected compact source dictionaries")
    sources = data["sources"]
    names = data["sourceEntityNames"]
    require(len(sources) == pins["CCPC_FULL_SOURCE_COUNT"], "Wrong compact source count")
    require(len(names) == len(sources), "Source name/source count mismatch")
    source_keys = set()
    names_by_entity = {entity: {} for entity in ENTITIES}
    for index, source in enumerate(sources):
        year, entity = source["year"], source["entityCode"]
        require(type(year) is int and year in YEARS and entity in ENTITIES, f"Invalid source dimensions at {index}")
        require((year, entity) not in source_keys, f"Duplicate year/entity source at {index}")
        source_keys.add((year, entity))
        require(isinstance(names[index], str) and names[index], f"Empty source name at {index}")
        names_by_entity[entity][str(year)] = names[index]
    require(source_keys == set(itertools.product(YEARS, ENTITIES)), "Source year/entity coverage is incomplete")
    require(len(data["records"]) == pins["CCPC_FULL_RECORD_COUNT"], "Wrong compact source record count")
    observed = {}
    for index, row in enumerate(data["records"]):
        require(type(row) is list and len(row) == 9, f"Malformed compact tuple {index}")
        require(all(integer(item) for item in row), f"Invalid compact integer at tuple {index}")
        require(row[0] < len(sources) and row[1] < len(SEXES) and row[2] < len(AGES) and row[3] < len(SECTIONS),
                f"Dictionary index outside source range at tuple {index}")
        source = sources[row[0]]
        key = (source["year"], source["entityCode"], SEXES[row[1]], AGES[row[2]], SECTIONS[row[3]])
        require(key not in observed, f"Duplicate compact dimensions: {key}")
        require(row[4] == row[5] + row[6] + row[7], f"Count partition mismatch: {key}")
        require(row[8] > 0, f"Observed tuple has no source rows: {key}")
        observed[key] = row[5] + row[6]
    return data, digest, names_by_entity, observed


def compare_csv(path, headers, expected):
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.reader(stream, strict=True)
        actual_headers = next(reader, None)
        require(actual_headers == list(headers), f"Wrong CSV columns: {path.name}")
        actual = []
        for line_number, row in enumerate(reader, start=2):
            require(len(row) == len(headers), f"Wrong CSV field count: {path.name}:{line_number}")
            actual.append(tuple(row))
    expected_strings = [tuple(str(value) for value in row) for row in expected]
    require(len(set(actual)) == len(actual), f"Duplicate CSV rows: {path.name}")
    actual_set, expected_set = set(actual), set(expected_strings)
    if actual_set != expected_set:
        absent = sorted(expected_set - actual_set)[:3]
        extra = sorted(actual_set - expected_set)[:3]
        raise ValueError(f"CSV content mismatch: {path.name}; missing={absent}; unexpected={extra}")
    require(len(actual) == len(expected_strings), f"CSV row count mismatch: {path.name}")
    return {"rows": len(actual), "sha256": file_sha(path)}


def audit(root):
    pins = read_release_pins(root)
    source, source_sha, entity_names, observed = expand_source(root, pins)
    catalog_dir = root / "data/ccpc/catalog"
    catalog_path = catalog_dir / "capabilities.json"
    catalog_pin_source = (root / "src/data/capabilities-release.ts").read_text(encoding="utf-8")
    catalog_pins = re.findall(
        r"^export const CCPC_CAPABILITIES_FILE_SHA256 = '([a-f0-9]{64})';$",
        catalog_pin_source, re.MULTILINE,
    )
    require(len(catalog_pins) == 1, "Missing or ambiguous capabilities release pin")
    require(file_sha(catalog_path) == catalog_pins[0], "Capabilities JSON SHA-256 does not match release pin")
    catalog = load_json(catalog_path)
    dimensions = catalog["dimensions"]
    require(dimensions["years"] == list(YEARS), "Catalog years differ from source")
    require(dimensions["sexes"] == list(SEXES), "Catalog sexes differ from source")
    require(dimensions["ageGroups"] == list(AGES), "Catalog ages differ from source")
    require(dimensions["sectionTypes"] == list(SECTIONS), "Catalog section types differ from source")
    sexes_by_year = {
        str(year): [sex for sex in SEXES if any(key[0] == year and key[2] == sex for key in observed)]
        for year in YEARS
    }
    require(dimensions["sexesByYear"] == sexes_by_year, "Catalog sex categories per year differ from observed data")
    entities = dimensions["entities"]
    require(type(entities) is list and len(entities) == len(ENTITIES), "Wrong catalog entity count")
    require([entity["code"] for entity in entities] == list(ENTITIES), "Wrong catalog entity codes or ordering")
    for entity in entities:
        code = entity["code"]
        require(entity["name"] == entity_names[code][str(YEARS[-1])], f"Catalog entity name is not latest source label: {code}")
        require(entity["namesByYear"] == entity_names[code], f"Historical source names mismatch: {code}")
    dataset = catalog["dataset"]
    expected_dataset = {
        "kind": "full", "schemaVersion": "ccpc-participation/v1", "fileSha256": source_sha,
        "recordsSha256": source["recordsSha256"], "recordCount": len(observed), "sourceCount": len(source["sources"]),
    }
    require(dataset == expected_dataset, "Catalog source dataset identity or counts mismatch")
    matrix = catalog["matrix"]
    require(matrix["axes"] == list(AXES), "Unexpected matrix axis order")
    require(matrix["shape"] == [len(YEARS), len(ENTITIES), len(SEXES), len(AGES), len(SECTIONS)], "Wrong matrix shape")
    require(matrix["encoding"] == {
        "0": "no_records", "1": "records_without_official_denominator", "2": "records_with_official_denominator",
    }, "Wrong matrix cell-status encoding")
    universe = list(itertools.product(YEARS, ENTITIES, SEXES, AGES, SECTIONS))
    cells = "".join("0" if key not in observed else "2" if observed[key] > 0 else "1" for key in universe)
    require(matrix["cells"] == cells, "Catalog matrix differs from independently reconstructed source coverage")
    expected_statistics = {
        "possible": len(universe), "observed": len(observed), "missing": cells.count("0"), "zeroDenominator": cells.count("1"),
    }
    require(all(integer(value) for value in matrix["statistics"].values()), "Invalid catalog statistics integer")
    require(matrix["statistics"] == expected_statistics, "Catalog statistics differ from source coverage")
    expected_missing = [
        (*key, "category_not_in_year" if key[2] not in sexes_by_year[str(key[0])] else "no_observed_records")
        for key in universe if key not in observed
    ]
    expected_years = []
    for year in YEARS:
        keys = [key for key in observed if key[0] == year]
        possible_global = len(ENTITIES) * len(SEXES) * len(AGES) * len(SECTIONS)
        possible_year_sexes = len(ENTITIES) * len(sexes_by_year[str(year)]) * len(AGES) * len(SECTIONS)
        expected_years.append((
            year, len({key[1] for key in keys}), len(keys), possible_global, possible_global - len(keys),
            possible_year_sexes, possible_year_sexes - len(keys), sum(observed[key] == 0 for key in keys),
        ))
    atomic_dimensions = list(itertools.product(ENTITIES, SEXES, AGES, SECTIONS))
    expected_comparisons = []
    for year_a, year_b in itertools.combinations(YEARS, 2):
        states = Counter(
            int((year_a, *key) in observed) + int((year_b, *key) in observed)
            for key in atomic_dimensions
        )
        expected_comparisons.append((year_a, year_b, states[2], states[1], states[0], len(atomic_dimensions)))
    csv_results = {}
    for filename, expected in (
        ("missing-combinations.csv", expected_missing), ("matrix-by-year.csv", expected_years),
        ("comparison-coverage.csv", expected_comparisons),
    ):
        csv_results[filename] = compare_csv(catalog_dir / filename, CSV_HEADERS[filename], expected)
    checksums = {}
    for line in (catalog_dir / "checksums.sha256").read_text(encoding="utf-8").splitlines():
        match = re.fullmatch(r"([a-f0-9]{64})  ([A-Za-z0-9_.-]+)", line)
        require(match is not None, "Malformed catalog checksum line")
        digest, filename = match.groups()
        require(filename not in checksums, f"Duplicate catalog checksum: {filename}")
        checksums[filename] = digest
    require(set(checksums) == {"capabilities.json", *CSV_HEADERS}, "Catalog checksum file inventory mismatch")
    for filename, digest in checksums.items():
        require(file_sha(catalog_dir / filename) == digest, f"Catalog checksum mismatch: {filename}")
    return {
        "schemaVersion": "ccpc-coverage-independent-audit/v1", "status": "pass",
        "method": "python_stdlib_direct_compact_reconstruction",
        "dataset": expected_dataset,
        "catalogSha256": file_sha(catalog_path),
        "catalogReleasePinVerified": True,
        "statistics": expected_statistics,
        "missingByReason": dict(Counter(row[-1] for row in expected_missing)),
        "sexesByYear": sexes_by_year,
        "coverageByYear": [dict(zip(CSV_HEADERS["matrix-by-year.csv"], row)) for row in expected_years],
        "comparisons": {
            "yearPairs": len(expected_comparisons),
            "atomicSelections": sum(row[-1] for row in expected_comparisons),
            "bothPresent": sum(row[2] for row in expected_comparisons),
            "missingOne": sum(row[3] for row in expected_comparisons),
            "missingBoth": sum(row[4] for row in expected_comparisons),
        },
        "csv": csv_results,
        "limits": [
            "Validates coverage and source identity, not frontend deployment or UI wiring.",
            "Original DATA-04 source acquisition and 54-million-row ETL are covered by the prior source audit.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT, help="Extracted DATA-05 project root")
    parser.add_argument("--output", type=Path, help="Also save the JSON audit report at this path")
    args = parser.parse_args()
    try:
        report = audit(args.root.resolve())
        exit_code = 0
    except (ValueError, OSError, KeyError, TypeError, IndexError, csv.Error) as error:
        report = {"schemaVersion": "ccpc-coverage-independent-audit/v1", "status": "fail", "error": str(error)}
        exit_code = 1
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    sys.stdout.write(rendered)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
