# Auditoría independiente de cobertura DATA-05

Requiere **Python 3.10 o posterior**, sin dependencias externas. Desde la raíz
del proyecto:

```sh
python3 scripts/audit/data05/verify_coverage.py \
  --output docs/data05-evidence/independent-coverage-audit.json
```

También admite `--root /ruta/al/proyecto` para auditar otra extracción. Imprime
un informe JSON y termina con código `0` si todo coincide, o `1` si encuentra
un fallo. `--output` guarda el mismo informe.

El programa autentica el agregado DATA-04 con su hash auditado y los pines de
`src/data/ccpc-release.ts`. Comprueba también el pin del catálogo y los cuatro
hashes de `checksums.sha256`. Después reconstruye directamente desde las tuplas
compactas:

- Las dimensiones, nombres históricos y categorías de sexo por año.
- Las 31,104 celdas de la matriz, distinguiendo ausencia de registros y ausencia
  de denominador oficial.
- Las 10,349 combinaciones ausentes y su motivo.
- Los seis resúmenes anuales y los 15 pares de años, con 5,184 selecciones
  atómicas por par.

Compara cada celda y cada fila de los tres CSV. Rechaza claves JSON duplicadas,
números no finitos, filas CSV duplicadas y cambios de estructura en la fuente.
El orden de las filas CSV no afecta la comparación.

Esta implementación utiliza sólo la biblioteca estándar de Python: no importa
el cliente compartido, el generador TypeScript ni el auditor de DATA-04, y no
vuelve a ejecutar el ETL ni descarga originales. La autenticidad del agregado
procede de la auditoría DATA-04 previa. La prueba de consumo del frontend y
backend pertenece a las pruebas de integración y la demostración del proyecto;
este auditor verifica el catálogo exportado y su correspondencia con los datos.
