#!/usr/bin/env python3
"""Independent DATA-04 release audit; Python standard library only.

This program never downloads data, runs the ETL, or imports production helpers.
It checks the released aggregate against the immutable DATA-01 source anchors,
then recomputes the results saved by the four real backend query methods.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import re
import sys
from collections import defaultdict
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from urllib.parse import urlparse


ROOT = Path(__file__).resolve().parents[3]
YEARS = (2009, 2012, 2015, 2018, 2021, 2024)
ENTITIES = tuple(f"{value:02d}" for value in range(1, 33))
SEXES = ("hombre", "mujer", "no_binario")
AGES = ("18-19", *(f"{start}-{start + 4}" for start in range(20, 100, 5)), "100+")
SECTIONS = ("urbana", "mixta", "rural")
COUNTS = ("nominalList", "voted", "didNotVote", "unspecified")
KEY_FIELDS = ("year", "entityCode", "sex", "ageGroup", "sectionType")
ANCHOR_SHA = "24b8f676d2a8ed7a05d32c1abdfcfc277f38edfc47c42e86220efc711b4fcdec"
FULL_RECORDS_SHA = "8d06184746e12b21a5166117e37787537a6643a659493f12d9c6efef3fd44e38"
ROW_SHAS = {
    2009: "ed774e35b5f947c38fe760c56a2cf5b4a4d6f0b0f09d98c09f220fbb63438c75",
    2012: "a911fb2b09bd897f9c121fd02fbea27cd1d288f026b9efc6fd1c0ffa434b9813",
    2015: "5806eec491bcaec9e76f7b49a7b57ad0fb52d02936183583e96cccfded9e4f76",
    2018: "09973686a3563098d07addd0bb34f1cba09dee9ce79239b7bf651cba0544b058",
    2021: "1c61dee7ff2e4e34dd89c7435e910dc77c8872e10a01e07d52b3b17c70852bf6",
    2024: "c7e8d08f1bed99dad323960dc0c8199ee8e22bc3cdbe16f0dabb522fae3e0858",
}
METRIC_DEFINITIONS = {
    "rateUnit": "ratio", "percentageUnit": "percent", "comparisonUnit": "percentage_point",
    "nominalDenominator": "nominalList", "ccpcDenominator": "voted+didNotVote",
}
METHODS = {"getParticipationSummary", "compareElections", "getParticipationBreakdown", "getSupportingRecords"}
SHA_RE = re.compile(r"^[a-f0-9]{64}$")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    def unique(pairs):
        output = {}
        for key, value in pairs:
            require(key not in output, f"Duplicate JSON key {key!r}: {path}")
            output[key] = value
        return output
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique,
                      parse_constant=lambda token: (_ for _ in ()).throw(ValueError(f"Nonfinite JSON number: {token}")))


def canonical(value):
    # Used here only for the immutable integer/string source-row anchors.
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def canonical_js_records_hash(records):
    """Recompute canonical JSON using JavaScript's exponent spelling/ranges.

    Counts are safe integers; percentages/rates are finite doubles below 101.
    Python's shortest double representation needs fixed notation at 1e-6 and
    exponent zero removal to agree with JSON.stringify for these values.
    """
    def render(item, level=0):
        if type(item) is float:
            require(math.isfinite(item), "Nonfinite reconstructed metric")
            if item == 0:
                return "0"
            if item.is_integer() and abs(item) < 1e21:
                return str(int(item))
            token = repr(item)
            if "e" in token:
                mantissa, exponent = token.split("e")
                if 1e-6 <= abs(item) < 1e21:
                    return format(Decimal(token), "f")
                return mantissa + "e" + ("+" if int(exponent) >= 0 else "-") + str(abs(int(exponent)))
            return token
        if isinstance(item, list):
            return "[]" if not item else "[\n" + ",\n".join("  " * (level + 1) + render(child, level + 1) for child in item) + "\n" + "  " * level + "]"
        if isinstance(item, dict):
            return "{}" if not item else "{\n" + ",\n".join("  " * (level + 1) + json.dumps(name, ensure_ascii=False) + ": " + render(item[name], level + 1) for name in sorted(item)) + "\n" + "  " * level + "}"
        return json.dumps(item, ensure_ascii=False)
    return hashlib.sha256((render(records) + "\n").encode("utf-8")).hexdigest()


def expand_compact(compact):
    require(compact["schemaVersion"] == "ccpc-compact/v1", "Unsupported compact schema version")
    require(compact["recordsSha256"] == FULL_RECORDS_SHA, "Released full record fingerprint changed")
    require(compact["columns"] == ["sourceIndex", "sexIndex", "ageGroupIndex", "sectionTypeIndex", "nominalList", "voted", "didNotVote", "unspecified", "sourceRows"], "Compact tuple columns changed")
    dictionaries = compact["dictionaries"]
    require(dictionaries == {"sex": list(SEXES), "ageGroup": list(AGES), "sectionType": list(SECTIONS)}, "Compact dictionaries changed")
    require(len(compact["sourceEntityNames"]) == len(compact["sources"]), "Compact source names incomplete")
    records = []
    for index, values in enumerate(compact["records"]):
        require(type(values) is list and len(values) == 9 and all(type(value) is int for value in values), f"Malformed tuple {index}")
        source_index, sex_index, age_index, section_index, *counts = values
        require(0 <= source_index < len(compact["sources"]) and 0 <= sex_index < len(SEXES) and 0 <= age_index < len(AGES) and 0 <= section_index < len(SECTIONS), f"Invalid dictionary index at tuple {index}")
        source = compact["sources"][source_index]
        row = {"year": source["year"], "entityCode": source["entityCode"], "entityName": compact["sourceEntityNames"][source_index],
               "sex": SEXES[sex_index], "ageGroup": AGES[age_index], "sectionType": SECTIONS[section_index],
               **dict(zip((*COUNTS, "sourceRows"), counts)), "sourceId": source["id"]}
        row.update(metrics(row))
        records.append(row)
    return {"schemaVersion": "ccpc-participation/v1", "kind": compact["kind"], "scope": compact["scope"], "years": compact["years"],
            "metricDefinitions": compact["metricDefinitions"], "sources": compact["sources"], "records": records}


def key(row):
    return "|".join(str(row[field]) for field in KEY_FIELDS)


def metrics(counts):
    nominal = counts["nominalList"]
    classified = counts["voted"] + counts["didNotVote"]
    result = {"classified": classified}
    for prefix, numerator in (("participation", "voted"), ("abstention", "didNotVote"), ("unspecified", "unspecified")):
        ratio = counts[numerator] / nominal if nominal else None
        result[prefix + "Rate"] = ratio
        result[prefix + "Pct"] = ratio * 100 if ratio is not None else None
    result["ccpcParticipationPct"] = counts["voted"] / classified * 100 if classified else None
    result["ccpcAbstentionPct"] = counts["didNotVote"] / classified * 100 if classified else None
    return result


def number(actual, expected, label):
    if expected is None:
        require(actual is None, f"{label}: zero denominator must be null")
    elif type(expected) is int:
        require(type(actual) is int and actual == expected, f"{label}: {actual!r} != {expected!r}")
    else:
        require(type(actual) in (int, float) and math.isfinite(actual) and math.isclose(actual, expected, rel_tol=2e-14, abs_tol=2e-12),
                f"{label}: {actual!r} != {expected!r}")


def count_invariants(row, label):
    for field in COUNTS:
        require(type(row[field]) is int and 0 <= row[field] <= 2**53 - 1, f"{label}.{field}: invalid safe nonnegative integer")
    require(row["nominalList"] == row["voted"] + row["didNotVote"] + row["unspecified"], f"{label}: LN != SV + NV + NS")


def checksum_listing(folder, dataset_name):
    entries = {}
    for line in (folder / "checksums.sha256").read_text(encoding="utf-8").splitlines():
        match = re.fullmatch(r"([a-f0-9]{64})  ([A-Za-z0-9_.-]+)", line)
        require(match is not None, f"Malformed checksum: {line!r}")
        digest, name = match.groups()
        require(name not in entries, f"Duplicate checksum filename: {name}")
        require((folder / name).is_file(), f"Missing checksum target: {name}")
        require(sha(folder / name) == digest, f"Wrong checksum: {name}")
        entries[name] = digest
    require(dataset_name in entries, "Missing compact dataset checksum")
    return entries


def selected(records, filters, default_year=True):
    effective = dict(filters)
    if default_year:
        effective.setdefault("year", max(YEARS))
    plural = {"entityCodes": "entityCode", "sexes": "sex", "ageGroups": "ageGroup", "sectionTypes": "sectionType"}
    return [row for row in records if ("year" not in effective or row["year"] == effective["year"]) and
            all(name not in effective or row[field] in effective[name] for name, field in plural.items())]


def totals(records):
    counts = {field: sum(row[field] for row in records) for field in COUNTS}
    return {**counts, **metrics(counts)}


def check_evidence(result, records, sources, dataset_hash):
    evidence = result["evidence"]
    require(evidence["dataset"]["kind"] == "full", "Query did not consume full dataset")
    require(evidence["dataset"]["years"] == list(YEARS), "Query has incomplete years")
    require(evidence["dataset"]["recordsSha256"] == dataset_hash, "Query consumed different full records")
    require(evidence["recordsSha256"] == canonical_js_records_hash(records), "Query evidence selected-record hash mismatch")
    require(evidence["matchedRecords"] == len(records), "Query evidence record count mismatch")
    require(evidence["matchedSourceRows"] == sum(row["sourceRows"] for row in records), "Query evidence source-row count mismatch")
    expected = defaultdict(lambda: {"records": 0, "sourceRows": 0})
    for row in records:
        expected[row["sourceId"]]["records"] += 1
        expected[row["sourceId"]]["sourceRows"] += row["sourceRows"]
    require(len(evidence["contributions"]) == len(expected), "Query contribution count mismatch")
    for contribution in evidence["contributions"]:
        require(contribution["sourceId"] in expected, "Unknown query contribution")
        require({field: contribution[field] for field in ("records", "sourceRows")} == expected.pop(contribution["sourceId"]), "Query contribution mismatch")
    require(not expected, "Missing query contribution")
    seen = set()
    for source in evidence["sources"]:
        require(source["id"] not in seen and source == sources.get(source["id"]), "Query source provenance mismatch")
        seen.add(source["id"])
    require({row["sourceId"] for row in records} <= seen, "Query record without provenance")
    require(result["units"] == METRIC_DEFINITIONS, "Query denominator/unit definitions mismatch")
    require((result["status"] == "ok") == bool(records), "Query status disagrees with observed groups")


def check_summary(result, records, sources, dataset_hash):
    check_evidence(result, records, sources, dataset_hash)
    if not records:
        require(result["totals"] is None, "Absent groups must not be fabricated zeros")
        return
    for field, expected in totals(records).items():
        number(result["totals"][field], expected, f"summary.{field}")


def check_queries(path, dataset, dataset_path, records_hash):
    queries = load(path)
    require(queries["datasetKind"] == "full", "Examples are sample, not full")
    require(queries["datasetSha256"] == sha(dataset_path), "Examples consumed a different dataset")
    sources = {source["id"]: source for source in dataset["sources"]}
    methods = set()
    facts = []
    for call in queries["calls"]:
        method, request, result = call["method"], call["input"], call["result"]
        require(method in METHODS and result["query"] == method, "Unexpected query method or result")
        methods.add(method)
        filters = request.get("filters", {})
        records = selected(dataset["records"], filters)
        if method == "getParticipationSummary":
            check_summary(result, records, sources, records_hash)
        elif method == "getSupportingRecords":
            check_evidence(result, records, sources, records_hash)
            require(result["records"] == records, "Supporting records changed ordering, dimensions, counts or provenance")
        elif method == "getParticipationBreakdown":
            check_evidence(result, records, sources, records_hash)
            fields = {"entity": "entityCode", "year": "year", "sex": "sex", "ageGroup": "ageGroup", "sectionType": "sectionType"}
            field = fields[request["dimension"]]
            require(result["dimension"] == request["dimension"], "Breakdown dimension changed")
            groups = {str(row[field]) for row in records}
            require(len(result["groups"]) == len(groups) and {group["value"] for group in result["groups"]} == groups, "Breakdown lost or fabricated categories")
            for group in result["groups"]:
                subset = [row for row in records if str(row[field]) == group["value"]]
                check_summary(group["summary"], subset, sources, records_hash)
        else:
            years = sorted(request["years"])
            require(result["years"] == years and result["baselineYear"] == years[0], "Comparison years/baseline changed")
            comparison_records = [row for row in selected(dataset["records"], filters, default_year=False) if row["year"] in years]
            check_evidence(result, comparison_records, sources, records_hash)
            require([item["year"] for item in result["elections"]] == years, "Missing comparison election")
            annual = {}
            for election in result["elections"]:
                subset = [row for row in comparison_records if row["year"] == election["year"]]
                check_summary(election["summary"], subset, sources, records_hash)
                annual[election["year"]] = totals(subset) if subset else None
            require(len(result["changes"]) == len(years) - 1, "Missing comparison change")
            baseline = annual[years[0]]
            for index, change in enumerate(result["changes"]):
                current = annual[years[index + 1]]
                require(change["year"] == years[index + 1] and change["baselineYear"] == years[0], "Comparison change labels mismatch")
                for output, field in (("participationPercentagePoints", "participationPct"), ("abstentionPercentagePoints", "abstentionPct"),
                                      ("ccpcParticipationPercentagePoints", "ccpcParticipationPct"), ("ccpcAbstentionPercentagePoints", "ccpcAbstentionPct")):
                    expected = current[field] - baseline[field] if current and baseline and current[field] is not None and baseline[field] is not None else None
                    number(change[output], expected, output)
                relative = (current["participationPct"] - baseline["participationPct"]) / baseline["participationPct"] * 100 if current and baseline and current["participationPct"] is not None and baseline["participationPct"] else None
                number(change["participationRelativePercent"], relative, "relative comparison percent")
        facts.append({"method": method, "input": request, "matchedRecords": result["evidence"]["matchedRecords"], "status": result["status"]})
    require(methods == METHODS, "All four backend queries must execute")
    return {"fileSha256": sha(path), "methods": sorted(methods), "executedCalls": len(facts), "calls": facts}


def data01_csv_bytes(records):
    """Independently recreate the byte-pinned DATA-01 aggregate from counts.

    Decimal.from_float preserves the IEEE value and HALF_UP reproduces JS
    Number.toFixed(6), including halfway cases where Python format differs.
    """
    columns = ["entidad_clave", "entidad", "anio", "sexo_codigo", "sexo", "grupo_edad", "tipo_seccion", "LN", "SV", "NV", "NS",
               "participacion_pct", "abstencion_pct", "no_especificado_pct", "denominador_participacion"]
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(columns)

    def percent(numerator, denominator):
        if denominator == 0:
            return ""
        value = 100 * numerator / denominator
        return str(int(value)) if value.is_integer() else str(Decimal.from_float(value).quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP))

    ordered = sorted(records, key=lambda row: (row["year"], int(row["entityCode"]), SEXES.index(row["sex"]), int(row["ageGroup"].split("-")[0].rstrip("+")), SECTIONS.index(row["sectionType"])))
    for row in ordered:
        classified = row["voted"] + row["didNotVote"]
        writer.writerow([row["entityCode"], row["entityName"], row["year"], SEXES.index(row["sex"]), row["sex"], row["ageGroup"], row["sectionType"],
                         *(row[field] for field in COUNTS), percent(row["voted"], classified), percent(row["didNotVote"], classified),
                         percent(row["unspecified"], row["nominalList"]), classified])
    return output.getvalue().encode("utf-8")


def check_reference(path, dataset, anchors):
    reconstructed = data01_csv_bytes(dataset["records"])
    digest = hashlib.sha256(reconstructed).hexdigest()
    require(digest == anchors["aggregateCsvSha256"], "Reconstructed aggregate CSV differs from immutable DATA-01 anchor")
    if path is not None:
        require(sha(path) == digest and path.read_bytes() == reconstructed, "Explicit full reference differs from reconstructed/pinned CSV")
    reference = list(csv.DictReader(io.StringIO(reconstructed.decode("utf-8"))))
    keyed = {}
    for row in reference:
        identity = "|".join((row["anio"], row["entidad_clave"], row["sexo"], row["grupo_edad"], row["tipo_seccion"]))
        require(identity not in keyed, "Duplicate full reference CSV combination")
        keyed[identity] = row
    require(len(keyed) == len(dataset["records"]), "Full reference CSV record count mismatch")
    for row in dataset["records"]:
        original = keyed.get(key(row))
        require(original is not None and row["entityName"] == original["entidad"], f"Reference identity/name mismatch: {key(row)}")
        for field, csv_field in zip(COUNTS, ("LN", "SV", "NV", "NS")):
            require(row[field] == int(original[csv_field]), f"Reference count mismatch: {key(row)}.{field}")
    return {"sha256": digest, "recordCount": len(reference), "method": "Reconstructed CSV byte-for-byte from compact counts and original formatting; compared to immutable DATA-01 hash"}


def check_coverage(path, dataset, dataset_path, records_hash):
    report = load(path)
    require(report["schemaVersion"] == "ccpc-data04-coverage/v1" and report["status"] == "pass", "Backend coverage was not completed")
    require(report["datasetSha256"] == sha(dataset_path) and report["recordsSha256"] == records_hash, "Backend coverage consumed a different dataset")
    require(len(report["entityYears"]) == 192, "Backend must query all 192 entity/year combinations")
    expected = {(year, entity) for year in YEARS for entity in ENTITIES}
    for item in report["entityYears"]:
        identity = item["year"], item["entityCode"]
        require(identity in expected, "Duplicate or unknown backend entity/year result")
        expected.remove(identity)
        subset = [row for row in dataset["records"] if row["year"] == identity[0] and row["entityCode"] == identity[1]]
        require(item["recordCount"] == len(subset) and item["sourceRows"] == sum(row["sourceRows"] for row in subset), "Backend coverage record/source counts differ")
        for field, value in totals(subset).items():
            number(item["totals"][field], value, f"backend {identity}.{field}")
    require(not expected, "Backend coverage omitted entity/year combinations")
    require(len(report["national"]) == 6 and {item["year"] for item in report["national"]} == set(YEARS), "Backend must query all six national elections")
    for item in report["national"]:
        subset = [row for row in dataset["records"] if row["year"] == item["year"]]
        require(item["recordCount"] == len(subset) and item["sourceRows"] == sum(row["sourceRows"] for row in subset), "Backend national record/source counts differ")
        for field, value in totals(subset).items():
            number(item["totals"][field], value, f"backend national {item['year']}.{field}")
    return {"sha256": sha(path), "entityYears": 192, "nationalYears": 6, "checks": report["checks"]}


def utc_date(value, label):
    require(type(value) is str and bool(re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z", value)), f"{label}: expected ISO UTC date")
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def check_acquisition(acquisition, anchors, generated_at):
    require(type(acquisition) is dict and acquisition["schemaVersion"] == "ccpc-data04-acquisition/v1", "Missing versioned acquisition metadata")
    verified_at = utc_date(acquisition["verifiedAt"], "acquisition.verifiedAt")
    require(utc_date(generated_at, "manifest.generatedAt") >= verified_at, "Release predates acquisition verification")
    require(type(acquisition.get("acquisitionMethod")) is str and acquisition["acquisitionMethod"].strip(), "Missing acquisition method")
    downloads = acquisition["downloads"]
    require(type(downloads) is list and len(downloads) == 6, "Acquisition needs six downloads")
    catalog = {row["year"]: row for row in load(ROOT / "data/ccpc/sources.json")["sources"]}
    annual_anchors = {source["year"]: source for source in anchors["sources"]}
    expected_years = set(YEARS)
    known_dates = 0
    for download in downloads:
        year = download["year"]
        require(type(year) is int and year in expected_years, "Duplicate or unexpected acquisition year")
        expected_years.remove(year)
        source = catalog[year]
        pinned = annual_anchors[year]
        require(download["url"] == source["url"] == pinned["url"] and download["sha256"] == source["sha256"] == pinned["archiveSha256"], f"Acquisition source/hash differs for {year}")
        require(download["filename"] == source["filename"], f"Acquisition filename differs for {year}")
        require(type(download["bytes"]) is int and download["bytes"] > 0, f"Invalid acquisition bytes for {year}")
        if download.get("finalUrl") is not None:
            final = urlparse(download["finalUrl"])
            require(final.scheme == "https" and final.hostname in {"ine.mx", "www.ine.mx", "portal.ine.mx"} and not final.username and not final.password and not final.port and not final.fragment and final.path.endswith("/" + source["filename"]), f"Acquisition final URL is not the expected official ZIP for {year}")
        if download["downloadedAt"] is not None:
            downloaded_at = utc_date(download["downloadedAt"], f"download {year}.downloadedAt")
            require(downloaded_at <= verified_at, f"Acquisition {year} occurs after verification")
            known_dates += 1
        if download.get("httpResponseDate") is not None:
            utc_date(download["httpResponseDate"], f"download {year}.httpResponseDate")
    require(not expected_years, "Missing acquisition years")
    return {"schemaVersion": acquisition["schemaVersion"], "acquisitionMethod": acquisition["acquisitionMethod"],
            "verifiedAt": acquisition["verifiedAt"], "downloadCount": len(downloads), "knownAcquisitionDates": known_dates,
            "downloadedBytes": sum(row["bytes"] for row in downloads), "downloads": downloads}


def audit(args):
    package = args.package.resolve()
    dataset_path = package / "participation.compact.json"
    compact = load(dataset_path)
    dataset = expand_compact(compact)
    manifest = load(package / "manifest.json")
    checksums = checksum_listing(package, dataset_path.name)
    require(dataset["schemaVersion"] == "ccpc-participation/v1" and dataset["scope"] == "entity" and dataset["kind"] == "full", "Wrong dataset schema, scope or kind")
    require(dataset["years"] == list(YEARS) == manifest["years"] and manifest["entityCodes"] == list(ENTITIES), "Six exact election years and 32 entity codes are required")
    require(dataset["metricDefinitions"] == METRIC_DEFINITIONS, "Official and nominal denominator definitions must be explicit")
    require(manifest["kind"] == "full" and manifest["scope"] == "entity" and manifest["schemaVersion"] == "ccpc-full-package/v1", "Manifest kind, scope or version mismatch")
    require(bool(re.fullmatch(r"\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?", manifest["packageVersion"])), "Missing semantic package version")
    utc_date(manifest["generatedAt"], "manifest.generatedAt")
    require(manifest["originalRecordsIncluded"] is False, "Original records must not be included")
    expected_official = {
        "participation": {"numerator": "voted", "denominator": "voted+didNotVote", "field": "ccpcParticipationPct", "unit": "percent"},
        "abstention": {"numerator": "didNotVote", "denominator": "voted+didNotVote", "field": "ccpcAbstentionPct", "unit": "percent"},
        "unspecified": {"numerator": "unspecified", "denominator": "nominalList", "field": "unspecifiedPct", "unit": "percent"},
    }
    require(all(manifest["officialMetrics"].get(field) == expected for field, expected in expected_official.items()), "Official metric formula or field mismatch")
    require(manifest["officialMetrics"]["zeroDenominator"] is None and manifest["officialMetrics"]["aggregation"] == "sum_counts_then_divide", "Official zero/aggregation semantics changed")
    metadata = manifest["dataset"]
    require(metadata["file"] == dataset_path.name and metadata["sha256"] == sha(dataset_path) and metadata["bytes"] == dataset_path.stat().st_size, "Dataset bytes disagree with manifest")
    records_hash = FULL_RECORDS_SHA
    require(metadata["recordsSha256"] == records_hash, "Canonical records fingerprint mismatch")
    anchors_path = ROOT / "data/ccpc/source-anchors.json"
    require(sha(anchors_path) == ANCHOR_SHA, "Immutable source anchors changed")
    anchors = load(anchors_path)
    acquisition = check_acquisition(manifest["acquisition"], anchors, manifest["generatedAt"])
    pinned = {source["id"]: source for source in anchors["sources"]}
    require(manifest["upstream"]["sourceAnchorsSha256"] == ANCHOR_SHA and manifest["upstream"]["aggregateCsvSha256"] == anchors["aggregateCsvSha256"], "Manifest upstream anchors changed")
    require(manifest["upstream"]["schemaVersion"] == "ccpc-participation/v1" and bool(SHA_RE.fullmatch(manifest["upstream"]["datasetSha256"])), "Missing versioned upstream dataset fingerprint")
    require(len(dataset["sources"]) == metadata["sourceCount"] == len(pinned) == 192, "192 year/entity sources are required")
    sources = {}
    for source in dataset["sources"]:
        require(source["id"] not in sources, "Duplicate source id")
        sources[source["id"]] = source
        require({name: value for name, value in source.items() if name != "downloadedAt"} == pinned.get(source["id"]), f"Official source mismatch: {source['id']}")
        if source["downloadedAt"] is not None:
            require(source["downloadedAt"].endswith("Z"), "Source acquisition date must be ISO UTC")
            datetime.fromisoformat(source["downloadedAt"].replace("Z", "+00:00"))
    require(set(sources) == {f"{year}:{entity}" for year in YEARS for entity in ENTITIES}, "Missing year/entity source")
    records = dataset["records"]
    require(len(records) == metadata["recordCount"] and 0 < len(records) <= 6 * 32 * 3 * 18 * 3, "Expected a lightweight aggregate, not original records")
    require(canonical_js_records_hash(records) == records_hash, "Independently reconstructed canonical full record hash differs from immutable fingerprint")
    seen = set()
    by_source = defaultdict(list)
    coverage = defaultdict(set)
    for row in records:
        identity = key(row)
        require(identity not in seen, f"Duplicate aggregate combination: {identity}")
        seen.add(identity)
        require(row["year"] in YEARS and row["entityCode"] in ENTITIES, f"Unexpected year/entity: {identity}")
        require(row["sex"] in SEXES and row["ageGroup"] in AGES and row["sectionType"] in SECTIONS, f"Invalid retained dimension: {identity}")
        require(row["year"] == 2024 or row["sex"] != "no_binario", "Historical non-binary category must not be fabricated")
        require(row["sourceId"] == f"{row['year']}:{row['entityCode']}", "Record/source identity mismatch")
        require(type(row["sourceRows"]) is int and row["sourceRows"] > 0, "Invalid original row count")
        count_invariants(row, identity)
        for field, expected in metrics(row).items():
            number(row[field], expected, identity + "." + field)
        by_source[row["sourceId"]].append(row)
        coverage[row["year"]].add(row["entityCode"])
    require(all(coverage[year] == set(ENTITIES) for year in YEARS), "Every year must include all 32 entities")
    for source_id, source in sources.items():
        subset = by_source[source_id]
        require(subset and sum(row["sourceRows"] for row in subset) == source["rawRows"], f"Source row conservation failed: {source_id}")
        require({field: sum(row[field] for row in subset) for field in COUNTS} == source["totals"], f"Source count conservation failed: {source_id}")
    for year in YEARS:
        row_facts = sorted(({"key": key(row), "sourceRows": row["sourceRows"]} for row in records if row["year"] == year), key=lambda row: row["key"])
        require(hashlib.sha256(canonical(row_facts)).hexdigest() == ROW_SHAS[year], f"Original rows redistributed between groups for {year}")
    raw_count = sum(source["rawRows"] for source in sources.values())
    require(raw_count == metadata["rawRowCount"], "Raw row coverage disagrees with manifest")
    sample = load(ROOT / "data/ccpc/sample/data02/participation.json")
    require(sample["kind"] == "sample" and len(sample["records"]) < len(records), "Sample/full distinction is missing")
    forbidden = []
    package_bytes = 0
    for path in package.rglob("*"):
        if path.is_file():
            package_bytes += path.stat().st_size
            if path.suffix.lower() in {".zip", ".part"} or path.name.lower().startswith("datosabiertos_deceyec_conteoscensales"):
                forbidden.append(path.relative_to(package).as_posix())
    require(not forbidden, f"Raw source archives/CSVs must not ship: {forbidden}")
    require(dataset_path.stat().st_size < 2 * 1024**2 and package_bytes < 2 * 1024**2, "Full package must stay below 2 MiB")
    reference = args.reference
    queries = args.queries or ROOT / "docs/data04-evidence/queries.json"
    return {
        "status": "PASS", "auditVersion": "data04-independent/v1", "implementation": "Python standard library; no ETL or production imports",
        "dataset": {"kind": "full", "schemaVersion": dataset["schemaVersion"], "sha256": sha(dataset_path), "recordsSha256": records_hash,
                    "bytes": dataset_path.stat().st_size, "packageBytes": package_bytes, "recordCount": len(records), "sourceCount": len(sources), "rawRowCount": raw_count},
        "checksums": checksums, "sourceAnchorsSha256": ANCHOR_SHA,
        "reference": check_reference(reference, dataset, anchors),
        "coverage": [{"year": year, "entityCount": len(coverage[year]), "recordCount": sum(row["year"] == year for row in records),
                      "rawRowCount": sum(source["rawRows"] for source in sources.values() if source["year"] == year),
                      "nationalTotals": totals([row for row in records if row["year"] == year])} for year in YEARS],
        "dimensions": {"sex": sorted({row["sex"] for row in records}), "ageGroup": list(AGES), "sectionType": sorted({row["sectionType"] for row in records})},
        "release": {"packageVersion": manifest["packageVersion"], "generatedAt": manifest["generatedAt"], "manifestSha256": sha(package / "manifest.json")},
        "acquisition": acquisition,
        "sample": {"kind": sample["kind"], "recordCount": len(sample["records"])},
        "queries": check_queries(queries, dataset, dataset_path, records_hash),
        "backendCoverage": check_coverage(args.coverage or ROOT / "docs/data04-evidence/coverage-report.json", dataset, dataset_path, records_hash),
        "quality": {"uniqueCombinations": True, "officialSourceConservation": True, "officialDenominator": "voted+didNotVote",
                    "rawSourcesIncluded": False, "sourceRowsMatchImmutablePerGroupDigests": True,
                    "lowFrequencyLn1ByYear": {str(year): sum(row["year"] == year and row["nominalList"] == 1 for row in records) for year in YEARS}},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, default=ROOT / "data/ccpc/full")
    parser.add_argument("--queries", type=Path)
    parser.add_argument("--reference", type=Path)
    parser.add_argument("--coverage", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "docs/data04-evidence/independent-package-audit.json")
    args = parser.parse_args()
    try:
        report = audit(args)
    except (ValueError, KeyError, TypeError, OSError) as error:
        print(f"DATA-04 INDEPENDENT AUDIT FAIL: {error}", file=sys.stderr)
        return 1
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"status": report["status"], "recordCount": report["dataset"]["recordCount"],
                      "sourceCount": report["dataset"]["sourceCount"], "rawRowCount": report["dataset"]["rawRowCount"],
                      "executedQueryMethods": report["queries"]["methods"], "report": str(args.output)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
