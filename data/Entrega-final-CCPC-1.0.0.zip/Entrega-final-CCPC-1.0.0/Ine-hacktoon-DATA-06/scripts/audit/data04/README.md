# Auditoría independiente DATA-04

Desde la raíz del proyecto, después de generar el paquete y ejecutar las consultas:

```sh
python scripts/audit/data04/verify_package.py
```

Sólo necesita Python 3 y su biblioteca estándar. No descarga los ZIP, no ejecuta el ETL y no importa sus funciones. Escribe `docs/data04-evidence/independent-package-audit.json`; termina con código distinto de cero si un control falla.

La auditoría reconstruye independientemente los registros del JSON compacto. Comprueba los seis años, las 192 combinaciones entidad/año, categorías, unicidad, enteros, conteos, denominadores y conservación de filas. Recalcula el hash canónico completo de los registros y los seis hashes de filas por grupo. Reconstruye el CSV agregado DATA-01 byte a byte para contrastarlo con su huella inmutable, sin necesitar conservar otro CSV en la entrega.

También contrasta el manifiesto, versión, fecha, hashes, fórmulas y 192 fuentes con las anclas de DATA-01; verifica la distinción `sample`/`full` y la ausencia de archivos fuente dentro del paquete. Finalmente recalcula los resultados guardados de las cuatro funciones del backend y los 192 resúmenes entidad/año del informe de cobertura. Los informes deben proceder de una ejecución actual del servicio sobre el paquete entregado.

Rutas opcionales: `--package`, `--queries`, `--coverage`, `--output` y `--reference`. La última permite comparar adicionalmente con un CSV completo existente; normalmente no se necesita.

Las anclas y sus huellas documentan la publicación original fijada por DATA-01. La auditoría comprueba correspondencia con esa publicación; una revisión de los datos de origen requiere volver a adquirir y procesar los archivos oficiales por separado.
