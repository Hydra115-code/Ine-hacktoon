# Auditoría independiente DATA-06

`verify_release.py` usa Python **3.10 o posterior**, exclusivamente biblioteca estándar. Lee el pin externo TypeScript como texto y no importa código de producción, ejecuta el ETL, consulta red ni modifica la publicación.

```sh
python3 scripts/audit/data06/verify_release.py
python3 scripts/audit/data06/verify_release.py --root /ruta/al/paquete
python3 scripts/audit/data06/verify_release.py --output docs/data06-evidence/independent-release-audit.json
```

La salida predeterminada es JSON en stdout. Un fallo devuelve código 1. `--output` es opcional; dentro del paquete sólo puede escribir en `docs/data06-evidence/` para evitar sobrescribir datos, pins o manifiestos durante una verificación.

Comprueba el SHA-256 externo del manifiesto 1.0.0 antes de interpretarlo; fechas de calendario y política de congelamiento; campos exactos del manifiesto y del schema lock; rutas relativas seguras y ausencia de enlaces; tamaños y hashes de todos los artefactos y archivos de contrato; cuatro checksums de publicación; identidad DATA-04/05 conservada; dimensiones, claves y conteos del compacto; fuentes oficiales y fechas de adquisición históricas; cobertura de campos en el diccionario y denominador oficial. Rechaza claves JSON duplicadas, campos inesperados en los contratos auditados y valores numéricos no finitos.

El auditor no vuelve a leer los 54 millones de registros originales. Las comprobaciones independientes de fórmulas, consultas y cobertura permanecen en los auditores DATA-04 y DATA-05 y sus evidencias; DATA-06 comprueba que esos datos y contratos no han cambiado. Los comandos declarados en `release.validation` son instrucciones reproducibles, no afirmaciones de que este proceso los haya ejecutado.

Los hashes detectan cambios frente al pin distribuido. No son una firma digital del INE ni autentican a un tercero que pueda sustituir simultáneamente todo el código y sus pins. La política hace inmutable esta versión desde la publicación y requiere otra versión para cualquier cambio; el auditor verifica el estado presente, sin afirmar que pueda observar modificaciones futuras.
