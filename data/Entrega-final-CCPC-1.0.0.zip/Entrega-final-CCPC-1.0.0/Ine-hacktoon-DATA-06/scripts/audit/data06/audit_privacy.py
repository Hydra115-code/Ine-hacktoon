#!/usr/bin/env python3
"""Read-only, independent schema/domain audit of aggregate data (stdlib only)."""
import argparse
import csv
import hashlib
import json
import math
import re
import sys
from pathlib import Path
from urllib.parse import urlsplit

YEARS = [2009, 2012, 2015, 2018, 2021, 2024]
SEXES = ["hombre", "mujer", "no_binario"]
AGES = ["18-19"] + [f"{n}-{n+4}" for n in range(20, 100, 5)] + ["100+"]
SECTIONS = ["urbana", "mixta", "rural"]
ENTITY_NAMES = [
    "AGUASCALIENTES", "BAJA CALIFORNIA", "BAJA CALIFORNIA SUR", "CAMPECHE",
    "COAHUILA", "COLIMA", "CHIAPAS", "CHIHUAHUA", "CIUDAD DE MEXICO", "DURANGO",
    "GUANAJUATO", "GUERRERO", "HIDALGO", "JALISCO", "MEXICO", "MICHOACAN",
    "MORELOS", "NAYARIT", "NUEVO LEON", "OAXACA", "PUEBLA", "QUERETARO",
    "QUINTANA ROO", "SAN LUIS POTOSI", "SINALOA", "SONORA", "TABASCO",
    "TAMAULIPAS", "TLAXCALA", "VERACRUZ", "YUCATAN", "ZACATECAS",
]
CODES = [f"{n:02d}" for n in range(1, 33)]
METRICS = {"ccpcDenominator": "voted+didNotVote", "comparisonUnit": "percentage_point",
           "nominalDenominator": "nominalList", "percentageUnit": "percent", "rateUnit": "ratio"}
SOURCE_KEYS = {"archiveSha256", "dictionarySha256", "downloadedAt", "entityCode", "id",
               "member", "memberSha256", "rawRows", "totals", "url", "year"}
COUNTS = {"nominalList", "voted", "didNotVote", "unspecified"}
RECORD_KEYS = COUNTS | {"abstentionPct", "abstentionRate", "ageGroup", "ccpcAbstentionPct",
    "ccpcParticipationPct", "classified", "entityCode", "entityName", "participationPct",
    "participationRate", "sectionType", "sex", "sourceId", "sourceRows", "unspecifiedPct",
    "unspecifiedRate", "year"}
CSV_HEADERS = ["entidad_clave", "entidad", "anio", "sexo_codigo", "sexo", "grupo_edad",
    "tipo_seccion", "LN", "SV", "NV", "NS", "participacion_pct", "abstencion_pct",
    "no_especificado_pct", "denominador_participacion"]
QUERIES = ["getParticipationSummary", "compareElections", "getParticipationBreakdown", "getSupportingRecords"]
DIRECT_KEYS = {"nombre", "nombres", "apellidos", "nombrecompleto", "fullname", "firstname",
    "lastname", "curp", "rfc", "claveelector", "clavedelector", "electorid", "personid",
    "idpersona", "persona", "correo", "correoelectronico", "email", "telefono", "phone",
    "mobile", "domicilio", "address", "direccion", "fechanacimiento", "birthdate", "dob"}
EMAIL_RE = re.compile(r"[A-Za-z0-9.!#$%&'*+/=?^_~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+")
CURP_RE = re.compile(r"\b[A-Z][AEIOUX][A-Z]{2}\d{6}[HM][A-Z]{5}[A-Z0-9]\d\b")
PHONE_RE = re.compile(r"(?<![\w.])(?:\+52[ -]?)?(?:\(?\d{3}\)?[ -])\d{3}[ -]\d{4}(?!\d)")


def require(condition, location, message):
    if not condition:
        raise ValueError(f"{location}: {message}")


def exact(value, fields, location):
    require(isinstance(value, dict), location, "expected object")
    require(set(value) == set(fields), location,
            "unexpected/missing fields; expected " + ",".join(sorted(fields)))


def integer(value, location, minimum=0):
    require(type(value) is int and minimum <= value <= 9007199254740991, location, "invalid count/index")


def digest(value, location):
    require(isinstance(value, str) and re.fullmatch(r"[a-f0-9]{64}", value), location, "invalid SHA-256")


def entity_name(code, year):
    return "DISTRITO FEDERAL" if code == "09" and year <= 2018 else ENTITY_NAMES[int(code)-1]


def domain(year, code, sex, age, section, location):
    require(type(year) is int and year in YEARS, location, "unknown year")
    require(code in CODES and isinstance(code, str), location, "unknown INE entity code")
    require(sex in SEXES and (sex != "no_binario" or year == 2024), location, "unknown sex/year")
    require(age in AGES, location, "unknown age group")
    require(section in SECTIONS, location, "unknown section type")


def official_url(value, location):
    require(isinstance(value, str), location, "URL must be string")
    u = urlsplit(value)
    require(u.scheme == "https" and u.hostname == "ine.mx" and u.username is None and
            u.password is None and not u.query and (u.port is None or u.port == 443), location,
            "source URL must be public INE HTTPS without credentials/query")


def direct_identifiers(value, location):
    """Fail without echoing an identifier's value into the audit report."""
    if isinstance(value, dict):
        for key, child in value.items():
            normalized = re.sub(r"[^a-z0-9]", "", key.lower())
            require(normalized not in DIRECT_KEYS, location, "forbidden direct-identifier field")
            direct_identifiers(child, location + "." + key)
    elif isinstance(value, list):
        for i, child in enumerate(value):
            direct_identifiers(child, f"{location}[{i}]")
    elif isinstance(value, str):
        require(not EMAIL_RE.search(value), location, "email-like value found")
        require(not CURP_RE.search(value), location, "CURP-like value found")
        require(not PHONE_RE.search(value), location, "phone-like value found")


def sources(rows, location, anchors=False):
    require(isinstance(rows, list) and rows, location, "sources must be nonempty")
    seen = set()
    for i, row in enumerate(rows):
        at = f"{location}[{i}]"
        exact(row, SOURCE_KEYS - ({"downloadedAt"} if anchors else set()), at)
        require(row["year"] in YEARS and row["entityCode"] in CODES, at, "unknown source geography/year")
        require(row["id"] == f'{row["year"]}:{row["entityCode"]}', at, "source id must identify year/entity")
        require(row["id"] not in seen, at, "duplicate source id")
        seen.add(row["id"])
        for key in ["archiveSha256", "dictionarySha256", "memberSha256"]:
            digest(row[key], at + "." + key)
        integer(row["rawRows"], at + ".rawRows", 1)
        exact(row["totals"], COUNTS, at + ".totals")
        for key in COUNTS:
            integer(row["totals"][key], at + ".totals." + key)
        require(row["totals"]["nominalList"] == sum(row["totals"][key] for key in ["voted", "didNotVote", "unspecified"]), at, "source counts do not conserve")
        official_url(row["url"], at + ".url")
        require(isinstance(row["member"], str) and re.fullmatch(r"[A-Za-z0-9_./-]+\.csv", row["member"])
                and ".." not in row["member"] and not row["member"].startswith("/"), at, "invalid public archive member path")
        if not anchors:
            require(row["downloadedAt"] is None or isinstance(row["downloadedAt"], str) and
                    re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z", row["downloadedAt"]), at, "invalid acquisition timestamp")
    return {row["id"]: row for row in rows}


def statistics(counts):
    return {"records": len(counts), "minimumNominalList": min(counts),
            "cellsNominalListEqualsOne": sum(n == 1 for n in counts),
            "cellsNominalListOneToFour": sum(1 <= n <= 4 for n in counts)}


def audit_compact(d):
    at = "full.compact"
    exact(d, {"columns", "dictionaries", "kind", "metricDefinitions", "records", "recordsSha256",
              "schemaVersion", "scope", "sourceEntityNames", "sources", "years"}, at)
    require(d["kind"] == "full" and d["scope"] == "entity" and d["schemaVersion"] == "ccpc-compact/v1", at, "unexpected aggregate format")
    require(d["years"] == YEARS and d["metricDefinitions"] == METRICS, at, "unexpected domains/metric definitions")
    require(d["columns"] == ["sourceIndex", "sexIndex", "ageGroupIndex", "sectionTypeIndex", "nominalList", "voted", "didNotVote", "unspecified", "sourceRows"], at, "unknown tuple columns")
    require(d["dictionaries"] == {"ageGroup": AGES, "sectionType": SECTIONS, "sex": SEXES}, at, "unknown category dictionary")
    digest(d["recordsSha256"], at + ".recordsSha256")
    source_map = sources(d["sources"], at + ".sources")
    require(len(source_map) == 192, at, "expected six years by 32 entities")
    require(d["sourceEntityNames"] == [entity_name(s["entityCode"], s["year"]) for s in d["sources"]], at, "entity names must be known public geography")
    require(isinstance(d["records"], list) and d["records"], at, "records missing")
    counts, keys = [], set()
    for i, row in enumerate(d["records"]):
        loc = f"{at}.records[{i}]"
        require(isinstance(row, list) and len(row) == 9, loc, "aggregate tuple must contain exactly nine values")
        for j, value in enumerate(row):
            integer(value, loc + f"[{j}]")
        require(row[0] < len(d["sources"]) and row[1] < 3 and row[2] < 18 and row[3] < 3, loc, "index outside category/source domain")
        source = d["sources"][row[0]]
        domain(source["year"], source["entityCode"], SEXES[row[1]], AGES[row[2]], SECTIONS[row[3]], loc)
        require(row[4] == sum(row[5:8]) and row[8] > 0, loc, "invalid aggregate counts")
        key = tuple(row[:4])
        require(key not in keys, loc, "duplicate aggregate cell")
        keys.add(key)
        counts.append(row[4])
    return statistics(counts)


def audit_sample(d):
    at = "sample.normalized"
    exact(d, {"kind", "metricDefinitions", "records", "schemaVersion", "scope", "sources", "years"}, at)
    require(d["kind"] == "sample" and d["scope"] == "entity" and d["schemaVersion"] == "ccpc-participation/v1", at, "unexpected sample format")
    require(d["metricDefinitions"] == METRICS and d["years"] == YEARS, at, "unexpected sample domains")
    source_map = sources(d["sources"], at + ".sources")
    counts = []
    for i, row in enumerate(d["records"]):
        loc = f"{at}.records[{i}]"
        exact(row, RECORD_KEYS, loc)
        domain(row["year"], row["entityCode"], row["sex"], row["ageGroup"], row["sectionType"], loc)
        require(row["entityName"] == entity_name(row["entityCode"], row["year"]), loc, "unknown geographic name")
        require(row["sourceId"] in source_map and row["sourceId"] == f'{row["year"]}:{row["entityCode"]}', loc, "unknown source id")
        for field in COUNTS | {"classified", "sourceRows"}:
            integer(row[field], loc + "." + field)
        require(row["nominalList"] == row["voted"] + row["didNotVote"] + row["unspecified"] and
                row["classified"] == row["voted"] + row["didNotVote"] and row["sourceRows"] > 0, loc, "invalid aggregate counts")
        for field in RECORD_KEYS - COUNTS - {"year", "sex", "entityCode", "entityName", "ageGroup", "sectionType", "sourceId", "classified", "sourceRows"}:
            value = row[field]
            require(value is None or type(value) in [int, float] and math.isfinite(value) and
                    0 <= value <= (1 if field.endswith("Rate") else 100), loc, "invalid aggregate rate")
        counts.append(row["nominalList"])
    require(bool(counts), at, "sample records missing")
    return statistics(counts)


def audit_csv(path):
    counts = []
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == CSV_HEADERS, "sample.csv", "unknown/missing CSV columns")
        for i, row in enumerate(reader):
            at = f"sample.csv[{i}]"
            require(None not in row and None not in row.values(), at, "CSV row width differs from header")
            year = int(row["anio"])
            domain(year, row["entidad_clave"], row["sexo"], row["grupo_edad"], row["tipo_seccion"], at)
            require(row["entidad"] == entity_name(row["entidad_clave"], year), at, "unknown geographic name")
            require(row["sexo_codigo"] == str(SEXES.index(row["sexo"])), at, "invalid public sex category code")
            numbers = {}
            for field in ["LN", "SV", "NV", "NS", "denominador_participacion"]:
                require(re.fullmatch(r"\d+", row[field]), at, "non-numeric aggregate count")
                numbers[field] = int(row[field])
                integer(numbers[field], at + "." + field)
            require(numbers["LN"] == numbers["SV"] + numbers["NV"] + numbers["NS"] and
                    numbers["denominador_participacion"] == numbers["SV"] + numbers["NV"], at, "invalid aggregate counts")
            for field in ["participacion_pct", "abstencion_pct", "no_especificado_pct"]:
                require(row[field] in ["", "null"] or re.fullmatch(r"\d+(?:\.\d+)?", row[field]) and 0 <= float(row[field]) <= 100, at, "non-numeric rate")
            counts.append(numbers["LN"])
    return statistics(counts)


def audit_catalog(d):
    at = "catalog"
    exact(d, {"schemaVersion", "catalogVersion", "generatedAt", "dataset", "dimensions", "matrix", "queries", "breakdownDimensions", "defaultYear", "metricDefinitions", "comparisonPolicy", "outOfScope", "questionTemplates"}, at)
    exact(d["dataset"], {"kind", "schemaVersion", "fileSha256", "recordsSha256", "recordCount", "sourceCount"}, at + ".dataset")
    require(d["dataset"]["kind"] == "full", at, "catalog must describe full aggregate")
    for field in ["fileSha256", "recordsSha256"]:
        digest(d["dataset"][field], at + ".dataset." + field)
    dims = d["dimensions"]
    exact(dims, {"years", "entities", "sexes", "sexesByYear", "ageGroups", "sectionTypes"}, at + ".dimensions")
    require(dims["years"] == YEARS and dims["sexes"] == SEXES and dims["ageGroups"] == AGES and dims["sectionTypes"] == SECTIONS, at, "unknown category domains")
    require(dims["sexesByYear"] == {str(y): SEXES if y == 2024 else SEXES[:2] for y in YEARS}, at, "unknown category/year map")
    require(len(dims["entities"]) == 32, at, "entity catalog must have 32 entries")
    for code, item in zip(CODES, dims["entities"]):
        exact(item, {"code", "name", "namesByYear"}, at + ".entity")
        require(item == {"code": code, "name": ENTITY_NAMES[int(code)-1], "namesByYear": {str(y): entity_name(code, y) for y in YEARS}}, at, "entity name must be known public geography")
    matrix = d["matrix"]
    exact(matrix, {"axes", "shape", "encoding", "cells", "statistics"}, at + ".matrix")
    require(matrix["axes"] == ["year", "entityCode", "sex", "ageGroup", "sectionType"] and
            matrix["shape"] == [6, 32, 3, 18, 3] and matrix["encoding"] ==
            {"0": "no_records", "1": "records_without_official_denominator", "2": "records_with_official_denominator"}, at, "unknown matrix encoding")
    require(isinstance(matrix["cells"], str) and len(matrix["cells"]) == 31104 and set(matrix["cells"]) <= set("012"), at, "matrix contains unknown cell values")
    exact(matrix["statistics"], {"possible", "observed", "missing", "zeroDenominator"}, at + ".matrix.statistics")
    for field, value in matrix["statistics"].items():
        integer(value, at + ".matrix.statistics." + field)
    require(d["queries"] == QUERIES and d["breakdownDimensions"] == ["entity", "year", "sex", "ageGroup", "sectionType"] and d["defaultYear"] in YEARS, at, "unknown query domains")
    exact(d["metricDefinitions"], {"participation", "abstention", "zeroDenominator"}, at + ".metricDefinitions")
    for key in ["participation", "abstention"]:
        exact(d["metricDefinitions"][key], {"field", "denominator", "unit"}, at + ".metricDefinitions." + key)
    exact(d["comparisonPolicy"], {"minimumYears", "maximumYears", "requireDataInEveryYear", "requireExplicitCategoriesInEveryYear", "missingCells", "warnings"}, at + ".comparisonPolicy")
    for item in d["outOfScope"]:
        exact(item, {"id", "question", "reason"}, at + ".outOfScope")
    for item in d["questionTemplates"]:
        fields = {"id", "title", "query"} | ({"dimension"} if "dimension" in item else set())
        exact(item, fields, at + ".questionTemplate")
        require(item["query"] in QUERIES and ("dimension" not in item or item["dimension"] in d["breakdownDimensions"]), at, "unknown onboarding query/domain")
    return {"entities": len(dims["entities"]), "atomicSelections": len(matrix["cells"]), "questionTemplates": len(d["questionTemplates"])}


def audit_catalog_csv(path):
    headers = {
        "missing-combinations.csv": ["year", "entityCode", "sex", "ageGroup", "sectionType", "reason"],
        "matrix-by-year.csv": ["year", "entities", "observed", "possibleGlobal", "missingGlobal", "possibleWithYearSexes", "missingWithYearSexes", "zeroDenominator"],
        "comparison-coverage.csv": ["yearA", "yearB", "bothPresent", "missingOne", "missingBoth", "totalAtomicSelections"],
    }
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == headers[path.name], path.name, "unknown/missing catalog CSV columns")
        count = 0
        for row in reader:
            require(None not in row and None not in row.values(), path.name, "CSV row width differs from header")
            if path.name == "missing-combinations.csv":
                require(int(row["year"]) in YEARS and row["entityCode"] in CODES and row["sex"] in SEXES and
                        row["ageGroup"] in AGES and row["sectionType"] in SECTIONS, path.name, "unknown missing-cell domain")
                require(row["reason"] in ["category_not_in_year", "no_observed_records"], path.name, "unknown missing-cell reason")
            else:
                for field, text in row.items():
                    require(re.fullmatch(r"\d+", text), path.name, "non-numeric coverage count")
                    integer(int(text), path.name + "." + field)
                    if field.startswith("year"):
                        require(int(text) in YEARS, path.name, "unknown coverage year")
            count += 1
    return {"rows": count, "columns": headers[path.name]}


def audit_dictionary(d):
    at = "release.dictionary"
    exact(d, {"schemaVersion", "datasetVersion", "contracts", "compactColumns", "normalizedFields",
              "dimensions", "metrics", "coverage", "excludedDirectIdentifiers", "sourceReferences", "notes"}, at)
    require(d["schemaVersion"] == "ccpc-data-dictionary/v1" and d["datasetVersion"] == "1.0.0", at, "unknown dictionary contract")
    for item in d["contracts"]:
        exact(item, {"schemaVersion", "description"}, at + ".contract")
    compact_names = ["sourceIndex", "sexIndex", "ageGroupIndex", "sectionTypeIndex", "nominalList", "voted", "didNotVote", "unspecified", "sourceRows"]
    require([item["name"] for item in d["compactColumns"]] == compact_names, at, "unknown dictionary compact field")
    for item in d["compactColumns"]:
        exact(item, {"name", "type", "description"}, at + ".compactColumn")
    require(set(item["name"] for item in d["normalizedFields"]) == RECORD_KEYS and len(d["normalizedFields"]) == len(RECORD_KEYS), at, "unknown dictionary normalized field")
    for item in d["normalizedFields"]:
        exact(item, {"name", "type", "unit", "description", "nullable"}, at + ".normalizedField")
        require(item["type"] in ["integer", "number", "string"] and type(item["nullable"]) is bool, at, "unknown dictionary type")
    require(d["dimensions"] == {"years": YEARS, "entityCodes": CODES,
        "sexesByYear": {str(y): SEXES if y == 2024 else SEXES[:2] for y in YEARS},
        "ageGroups": AGES, "sectionTypes": SECTIONS}, at, "unknown dictionary domain")
    exact(d["coverage"], {"possible", "observed", "missing"}, at + ".coverage")
    for item in d["sourceReferences"]:
        exact(item, {"url", "title"}, at + ".sourceReference")
        official_url(item["url"], at + ".sourceReference.url")


def audit_frontend_metadata(d):
    at = "release.frontendMetadata"
    exact(d, {"schemaVersion", "datasetVersion", "releasedAt", "source", "extraction", "methodology",
              "warnings", "coverage", "privacy", "contracts", "reproducibility"}, at)
    require(d["schemaVersion"] == "ccpc-frontend-metadata/v1" and d["datasetVersion"] == "1.0.0", at, "unknown frontend metadata contract")
    exact(d["source"], {"publisher", "title", "landingUrl", "manualUrl", "archives"}, at + ".source")
    for field in ["landingUrl", "manualUrl"]:
        official_url(d["source"][field], at + ".source." + field)
    require(len(d["source"]["archives"]) == 6, at, "expected six public sources")
    for item in d["source"]["archives"]:
        exact(item, {"year", "url", "sha256", "acquiredAt"}, at + ".archive")
        require(item["year"] in YEARS, at, "unknown archive year")
        official_url(item["url"], at + ".archive.url")
        digest(item["sha256"], at + ".archive.sha256")
    exact(d["extraction"], {"date", "timeZone", "precision", "exactRowExtractionTimestamp", "aggregatePackagedAt"}, at + ".extraction")
    exact(d["methodology"], {"unitOfAnalysis", "dimensions", "aggregation", "participation", "abstention", "unspecified", "noData", "samplePolicy"}, at + ".methodology")
    for field in ["participation", "abstention", "unspecified"]:
        exact(d["methodology"][field], {"field", "numerator", "denominator", "unit"}, at + ".methodology." + field)
    for item in d["warnings"]:
        exact(item, {"code", "message"}, at + ".warning")
    exact(d["coverage"], {"years", "entityCount", "ageGroupCount", "sectionTypeCount", "observedCombinations", "missingCombinations"}, at + ".coverage")
    require(d["privacy"] == {"directIdentifiersIncluded": False, "assessment": "schema_allowlist_verified",
        "smallCellsPresent": True, "anonymityGuarantee": False}, at, "privacy claim must preserve small-cell limitation")
    exact(d["contracts"], {"dataset", "compact", "capabilities", "frontendMetadata"}, at + ".contracts")
    exact(d["reproducibility"], {"command", "documentation"}, at + ".reproducibility")


def audit_release_metadata(d, is_lock=False):
    at = "release.schemaLock" if is_lock else "release.manifest"
    if is_lock:
        exact(d, {"schemaVersion", "datasetVersion", "freeze", "contractVersions", "files"}, at)
        require(d["schemaVersion"] == "ccpc-schema-lock/v1", at, "unknown schema lock")
        entries = d["files"]
    else:
        exact(d, {"schemaVersion", "datasetVersion", "status", "releasedAt", "freeze", "dataset",
            "extraction", "provenance", "artifacts", "schemaLock", "frontendMetadata", "validation", "reproducibility"}, at)
        require(d["schemaVersion"] == "ccpc-dataset-release/v1" and d["status"] == "frozen", at, "unknown release contract")
        exact(d["dataset"], {"kind", "compactSchemaVersion", "normalizedSchemaVersion", "capabilitiesSchemaVersion",
            "file", "sha256", "recordsSha256", "recordCount", "sourceCount", "sourceRows"}, at + ".dataset")
        require(d["dataset"]["kind"] == "full", at, "final release must be aggregate full")
        for field in ["sha256", "recordsSha256"]:
            digest(d["dataset"][field], at + ".dataset." + field)
        for field in ["recordCount", "sourceCount", "sourceRows"]:
            integer(d["dataset"][field], at + ".dataset." + field, 1)
        exact(d["extraction"], {"date", "timeZone", "precision", "exactRowExtractionTimestamp", "aggregatePackagedAt"}, at + ".extraction")
        exact(d["provenance"], {"publisher", "landingUrl", "manualUrl", "archives"}, at + ".provenance")
        for field in ["landingUrl", "manualUrl"]:
            official_url(d["provenance"][field], at + ".provenance." + field)
        for archive in d["provenance"]["archives"]:
            exact(archive, {"year", "url", "sha256", "acquiredAt"}, at + ".provenance.archive")
            official_url(archive["url"], at + ".provenance.archive.url")
            digest(archive["sha256"], at + ".provenance.archive.sha256")
        exact(d["schemaLock"], {"path", "sha256", "contractVersions"}, at + ".schemaLock")
        exact(d["frontendMetadata"], {"path", "sha256", "schemaVersion"}, at + ".frontendMetadata")
        exact(d["validation"], {"commands", "evidenceDirectory"}, at + ".validation")
        exact(d["reproducibility"], {"regenerator", "fixedMetadata", "noRawRecordsInRelease"}, at + ".reproducibility")
        entries = d["artifacts"]
    require(d["datasetVersion"] == "1.0.0", at, "unknown dataset version")
    exact(d["freeze"], {"effectiveAt", "deadlineLocalDate", "timeZone", "immutable", "changesRequireNewVersion"}, at + ".freeze")
    for entry in entries:
        exact(entry, {"path", "bytes", "sha256"}, at + ".file")
        require(isinstance(entry["path"], str) and re.fullmatch(r"[A-Za-z0-9_./-]+", entry["path"]) and
                not entry["path"].startswith("/") and ".." not in entry["path"], at, "invalid public release path")
        integer(entry["bytes"], at + ".file.bytes", 1)
        digest(entry["sha256"], at + ".file.sha256")


def read_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, path.name, "duplicate JSON property")
            result[key] = value
        return result
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique)


def run(root):
    data = root / "data/ccpc"
    allowed = {"README.md", "sources.json", "source-anchors.json", "full/README.md", "full/manifest.json",
        "full/participation.compact.json", "full/checksums.sha256", "sample/provenance.json", "sample/entidad.csv",
        "sample/checksums.sha256", "sample/data02/participation.json", "sample/data02/manifest.json",
        "sample/data02/checksums.sha256", "catalog/capabilities.json", "catalog/missing-combinations.csv",
        "catalog/matrix-by-year.csv", "catalog/comparison-coverage.csv", "catalog/checksums.sha256"}
    allowed.update(f"sample/dictionary-{year}.txt" for year in YEARS)
    allowed.update("releases/1.0.0/" + name for name in ["dictionary.json", "frontend-metadata.json",
        "release.json", "schema-lock.json", "checksums.sha256"])
    for path in data.rglob("*"):
        require(not path.is_symlink(), str(path.relative_to(data)), "symlink outside reviewed data scope")
        if path.is_file():
            require(path.relative_to(data).as_posix() in allowed, str(path.relative_to(data)), "unreviewed additional data artifact")
    report = {"schemaVersion": "ccpc-privacy-audit/v1", "status": "pass",
        "claim": "No direct personal identifiers detected in audited released aggregate payloads; anonymity is not established.",
        "directIdentifierFieldsAllowed": [], "checks": [], "files": [],
        "limitations": ["Schema/domain audit is not a formal anonymization or legal certification.",
            "Small published cells remain: an entity/sex/age-group/section-type aggregate can have nominalList=1.",
            "No suppression was applied; do not infer that an individual cannot be reidentified using external information.",
            "Documentation and source code are excluded from value scanning; they can discuss identifiers without containing person records."]}
    required = {"full/participation.compact.json": audit_compact,
                "sample/data02/participation.json": audit_sample,
                "catalog/capabilities.json": audit_catalog}
    for name, validate in required.items():
        path = data / name
        value = read_json(path)
        direct_identifiers(value, name)
        report[name] = validate(value)
        report["files"].append({"path": str(path.relative_to(root)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    csv_path = data / "sample/entidad.csv"
    report["sample/entidad.csv"] = audit_csv(csv_path)
    report["files"].append({"path": str(csv_path.relative_to(root)), "sha256": hashlib.sha256(csv_path.read_bytes()).hexdigest()})
    for filename in ["missing-combinations.csv", "matrix-by-year.csv", "comparison-coverage.csv"]:
        path = data / "catalog" / filename
        report["catalog/" + filename] = audit_catalog_csv(path)
        report["files"].append({"path": str(path.relative_to(root)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    # Other JSONs are provenance/release metadata; scan actual values, not documents.
    for path in sorted(data.rglob("*.json")):
        name = path.relative_to(data).as_posix()
        if name in required:
            continue
        require(name in {"source-anchors.json", "sources.json", "full/manifest.json", "sample/provenance.json",
            "sample/data02/manifest.json", "releases/1.0.0/dictionary.json", "releases/1.0.0/frontend-metadata.json",
            "releases/1.0.0/release.json", "releases/1.0.0/schema-lock.json"}, name, "unreviewed additional JSON data artifact")
        value = read_json(path)
        direct_identifiers(value, name)
        if name == "source-anchors.json":
            exact(value, {"aggregateCsvSha256", "fixtureCsvSha256", "schemaVersion", "sources"}, name)
            sources(value["sources"], name + ".sources", anchors=True)
        elif name == "sources.json":
            exact(value, {"schema_version", "sources"}, name)
            for source in value["sources"]:
                exact(source, {"year", "filename", "url", "landing_url", "sha256"}, name + ".source")
                require(source["year"] in YEARS, name, "unknown source year")
                official_url(source["url"], name + ".source.url")
                official_url(source["landing_url"], name + ".source.landing_url")
                digest(source["sha256"], name + ".source.sha256")
        elif name == "releases/1.0.0/dictionary.json":
            audit_dictionary(value)
        elif path.name == "frontend-metadata.json":
            audit_frontend_metadata(value)
        elif name == "releases/1.0.0/release.json":
            audit_release_metadata(value)
        elif name == "releases/1.0.0/schema-lock.json":
            audit_release_metadata(value, is_lock=True)
        report["files"].append({"path": str(path.relative_to(root)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    report["checks"] = ["exact aggregate and normalized record field allowlists", "fixed nine-number compact tuples",
        "known category and year/entity domains", "public geographic names only in entity-name fields",
        "year/entity source IDs and public INE source URLs", "exact sample CSV columns and numeric counts/rates",
        "exact catalog structure, category dictionaries and derived CSV columns", "direct-identifier keys and email/CURP/phone patterns in delivered JSON metadata",
        "closed data-file inventory without unreviewed payloads or symlinks", "small-cell counts reported without claiming anonymity"]
    report["auditedFileCount"] = len(report["files"])
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[3], help="Project root; defaults to root containing script")
    parser.add_argument("--output", type=Path, help="Optional report path; omitted means read-only stdout")
    args = parser.parse_args()
    try:
        report = run(args.root.resolve())
    except (OSError, ValueError, TypeError, KeyError, IndexError) as exc:
        report = {"schemaVersion": "ccpc-privacy-audit/v1", "status": "fail", "error": str(exc)}
    payload = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    sys.stdout.write(payload)
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
