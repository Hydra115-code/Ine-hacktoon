#!/usr/bin/env python3
"""Independent DATA-06 frozen-release audit; Python >= 3.10, standard library only.

No production module, release generator, ETL, network or npm dependency is used.
The external TypeScript pin is read as text, never evaluated or rewritten.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import date, datetime, timezone
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[3]
RELEASE_DIRECTORY = "data/ccpc/releases/1.0.0"
RELEASE_PATH = f"{RELEASE_DIRECTORY}/release.json"
PIN_PATH = "src/data/dataset-v1-release.ts"
YEARS = [2009, 2012, 2015, 2018, 2021, 2024]
SEXES = ["hombre", "mujer", "no_binario"]
AGES = ["18-19", *(f"{start}-{start + 4}" for start in range(20, 100, 5)), "100+"]
SECTIONS = ["urbana", "mixta", "rural"]
ENTITIES = [f"{value:02d}" for value in range(1, 33)]
COMPACT_PATH = "data/ccpc/full/participation.compact.json"
CATALOG_PATH = "data/ccpc/catalog/capabilities.json"
COMPACT_SHA = "d7e546928465d25702fe1b625eafb91c8435f7c5ddedd1c30a5278f89c29489c"
RECORDS_SHA = "8d06184746e12b21a5166117e37787537a6643a659493f12d9c6efef3fd44e38"
CATALOG_SHA = "5dd6c03fdcad5466cf069a82d1bb86c1c7ebd0d14e56a8d9ba8777c0db995f9b"
COLUMNS = ["sourceIndex", "sexIndex", "ageGroupIndex", "sectionTypeIndex", "nominalList",
           "voted", "didNotVote", "unspecified", "sourceRows"]
NORMALIZED_FIELDS = ["entityCode", "entityName", "year", "sex", "ageGroup", "sectionType", "nominalList",
                     "voted", "didNotVote", "unspecified", "classified", "participationRate", "abstentionRate",
                     "unspecifiedRate", "participationPct", "abstentionPct", "unspecifiedPct",
                     "ccpcParticipationPct", "ccpcAbstentionPct", "sourceId", "sourceRows"]
MANDATORY_ARTIFACTS = {
    COMPACT_PATH, "data/ccpc/full/manifest.json", "data/ccpc/full/checksums.sha256",
    CATALOG_PATH, "data/ccpc/catalog/matrix-by-year.csv", "data/ccpc/catalog/missing-combinations.csv",
    "data/ccpc/catalog/comparison-coverage.csv", "data/ccpc/catalog/checksums.sha256",
    "data/ccpc/sources.json", "data/ccpc/source-anchors.json",
    f"{RELEASE_DIRECTORY}/dictionary.json", f"{RELEASE_DIRECTORY}/frontend-metadata.json",
    f"{RELEASE_DIRECTORY}/schema-lock.json",
}
REQUIRED_CONTRACTS = {
    "ccpc-compact/v1", "ccpc-participation/v1", "ccpc-capabilities/v1",
    "ccpc-dataset-release/v1", "ccpc-frontend-metadata/v1", "ccpc-data-dictionary/v1",
}
LOCKED_CONTRACTS = REQUIRED_CONTRACTS | {"ccpc-schema-lock/v1", "ccpc-query-response/v1"}
LOCKED_FILES = {
    "src/application/ports/participation-data.ts", "src/client/coverage-client.ts",
    "src/data/capabilities-release.ts", "src/data/ccpc-release.ts", "src/data/coverage-participation.ts",
    "src/data/dataset-v1-definition.ts", "src/data/dataset-v1.ts", "src/data/full-participation.ts",
    "src/domain/civic/participation.ts", "src/repositories/participation.repository.ts",
    "src/schemas/civic/participation.schema.ts", "src/services/participation.service.ts",
    "scripts/ccpc/build-dataset-v1.ts", "scripts/ccpc/regenerate-dataset-v1.ts",
}
SHA_RE = re.compile(r"[a-f0-9]{64}\Z")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def keys(value, expected, context):
    require(type(value) is dict and set(value) == set(expected), f"{context}: unknown or missing fields")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def integer(value):
    return type(value) is int and 0 <= value <= 9007199254740991


def nonempty(value):
    return type(value) is str and bool(value.strip())


def utc(value, context):
    require(type(value) is str and re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z", value),
            f"{context}: expected explicit UTC timestamp")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    require(parsed.utcoffset().total_seconds() == 0, f"{context}: expected UTC")
    return parsed


def load_bytes(data, context):
    def unique(pairs):
        output = {}
        for key, value in pairs:
            require(key not in output, f"{context}: duplicate JSON key {key!r}")
            output[key] = value
        return output
    return json.loads(data.decode("utf-8", errors="strict"), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"{context}: nonfinite {value}")))


def safe_path(root, relative):
    require(type(relative) is str and re.fullmatch(r"[A-Za-z0-9._/-]+", relative), "Invalid artifact path")
    path = PurePosixPath(relative)
    require(not path.is_absolute() and path.as_posix() == relative and all(part not in {".", ".."} for part in path.parts),
            f"Unsafe artifact path: {relative}")
    current = root
    for part in path.parts:
        current /= part
        require(not current.is_symlink(), f"Symlink rejected: {relative}")
    require(current.is_file(), f"Missing artifact: {relative}")
    return current


def read(root, relative):
    return safe_path(root, relative).read_bytes()


def load(root, relative):
    return load_bytes(read(root, relative), relative)


def inventory(root, entries, context):
    require(type(entries) is list and entries, f"{context}: empty inventory")
    result = {}
    for entry in entries:
        keys(entry, ["path", "bytes", "sha256"], context)
        path = entry["path"]
        require(type(path) is str and path not in result, f"{context}: duplicate path")
        require(integer(entry["bytes"]) and type(entry["sha256"]) is str and SHA_RE.fullmatch(entry["sha256"]),
                f"{context}: invalid size/hash for {path}")
        data = read(root, path)
        require(len(data) == entry["bytes"], f"{context}: size mismatch: {path}")
        require(digest(data) == entry["sha256"], f"{context}: SHA-256 mismatch: {path}")
        result[path] = entry
    return result


def pin_constant(text, name):
    matches = re.findall(r"export\s+const\s+" + re.escape(name) + r"\s*=\s*(['\"])([^'\"]+)\1", text)
    require(len(matches) == 1, f"External pin {name}: missing or ambiguous")
    return matches[0][1]


def audit(root):
    pin = read(root, PIN_PATH).decode("utf-8", errors="strict")
    require(pin_constant(pin, "CCPC_DATASET_VERSION") == "1.0.0", "External dataset version mismatch")
    expected_sha = pin_constant(pin, "CCPC_DATASET_V1_RELEASE_SHA256")
    require(SHA_RE.fullmatch(expected_sha), "Invalid external release hash")
    release_bytes = read(root, RELEASE_PATH)
    require(digest(release_bytes) == expected_sha, "External release pin mismatch")
    release = load_bytes(release_bytes, RELEASE_PATH)
    keys(release, ["schemaVersion", "datasetVersion", "status", "releasedAt", "freeze", "dataset", "extraction",
                   "provenance", "artifacts", "schemaLock", "frontendMetadata", "validation", "reproducibility"], "release")
    require(release["schemaVersion"] == "ccpc-dataset-release/v1" and release["datasetVersion"] == "1.0.0"
            and release["status"] == "frozen", "Incorrect frozen release identity")
    released_at = utc(release["releasedAt"], "releasedAt")
    freeze = release["freeze"]
    keys(freeze, ["effectiveAt", "deadlineLocalDate", "timeZone", "immutable", "changesRequireNewVersion"], "freeze")
    effective_at = utc(freeze["effectiveAt"], "freeze.effectiveAt")
    require(freeze["deadlineLocalDate"] == "2026-10-26" and freeze["timeZone"] == "America/Monterrey"
            and freeze["immutable"] is True and freeze["changesRequireNewVersion"] is True, "Invalid freeze policy")
    require(effective_at == released_at and effective_at < datetime(2026, 10, 27, 6, tzinfo=timezone.utc),
            "Freeze must be effective at publication and before the end of October 26 in Monterrey")
    extraction = release["extraction"]
    keys(extraction, ["date", "timeZone", "precision", "exactRowExtractionTimestamp", "aggregatePackagedAt"], "extraction")
    require(extraction["date"] == "2026-10-22" and date.fromisoformat(extraction["date"])
            and extraction["timeZone"] == "UTC" and extraction["precision"] == "day"
            and extraction["exactRowExtractionTimestamp"] is None, "Extraction must preserve known day precision")
    require(extraction["aggregatePackagedAt"] == "2026-10-22T00:59:19Z", "Original aggregate publication changed")
    utc(extraction["aggregatePackagedAt"], "extraction.aggregatePackagedAt")
    dataset = release["dataset"]
    keys(dataset, ["kind", "compactSchemaVersion", "normalizedSchemaVersion", "capabilitiesSchemaVersion", "file", "sha256",
                   "recordsSha256", "recordCount", "sourceCount", "sourceRows"], "dataset")
    require(dataset == {"kind": "full", "compactSchemaVersion": "ccpc-compact/v1", "normalizedSchemaVersion": "ccpc-participation/v1",
                        "capabilitiesSchemaVersion": "ccpc-capabilities/v1", "file": COMPACT_PATH, "sha256": COMPACT_SHA,
                        "recordsSha256": RECORDS_SHA, "recordCount": 20755, "sourceCount": 192, "sourceRows": 54872712},
            "The frozen dataset must match the independently audited DATA-04 full release")
    artifacts = inventory(root, release["artifacts"], "artifacts")
    require(MANDATORY_ARTIFACTS == set(artifacts), "Mandatory frozen artifact inventory differs")
    require(RELEASE_PATH not in artifacts and f"{RELEASE_DIRECTORY}/checksums.sha256" not in artifacts,
            "Circular release/checksum inventory")
    require(artifacts[COMPACT_PATH]["sha256"] == COMPACT_SHA and artifacts[CATALOG_PATH]["sha256"] == CATALOG_SHA,
            "DATA-04/05 artifact identity mismatch")
    lock_reference = release["schemaLock"]
    keys(lock_reference, ["path", "sha256", "contractVersions"], "schemaLock reference")
    require(lock_reference["path"] == f"{RELEASE_DIRECTORY}/schema-lock.json", "Wrong schema-lock path")
    require(lock_reference["sha256"] == artifacts[lock_reference["path"]]["sha256"], "Schema-lock reference hash mismatch")
    lock = load(root, lock_reference["path"])
    keys(lock, ["schemaVersion", "datasetVersion", "freeze", "contractVersions", "files"], "schema-lock")
    require(lock["schemaVersion"] == "ccpc-schema-lock/v1" and lock["datasetVersion"] == "1.0.0"
            and lock["freeze"] == freeze and lock["contractVersions"] == lock_reference["contractVersions"], "Schema-lock identity/policy mismatch")
    contracts = lock["contractVersions"]
    require(type(contracts) is list and all(nonempty(item) for item in contracts) and len(set(contracts)) == len(contracts)
            and LOCKED_CONTRACTS == set(contracts), "Frozen contract version inventory differs")
    locked_files = inventory(root, lock["files"], "schema-lock.files")
    require(set(locked_files) == LOCKED_FILES, "Frozen source contract file inventory differs")
    require(PIN_PATH not in locked_files and RELEASE_PATH not in locked_files, "Circular external pin/schema lock")
    for path in set(locked_files) & set(artifacts):
        require(locked_files[path] == artifacts[path], f"Conflicting lock/artifact entry: {path}")
    metadata_reference = release["frontendMetadata"]
    keys(metadata_reference, ["path", "sha256", "schemaVersion"], "frontendMetadata reference")
    require(metadata_reference["path"] == f"{RELEASE_DIRECTORY}/frontend-metadata.json"
            and metadata_reference["schemaVersion"] == "ccpc-frontend-metadata/v1"
            and metadata_reference["sha256"] == artifacts[metadata_reference["path"]]["sha256"], "Frontend metadata reference mismatch")
    frontend = load(root, metadata_reference["path"])
    keys(frontend, ["schemaVersion", "datasetVersion", "releasedAt", "source", "extraction", "methodology", "warnings",
                    "coverage", "privacy", "contracts", "reproducibility"], "frontend metadata")
    require(frontend["schemaVersion"] == "ccpc-frontend-metadata/v1" and frontend["datasetVersion"] == "1.0.0"
            and frontend["releasedAt"] == release["releasedAt"] and frontend["extraction"] == extraction,
            "Frontend metadata identity/extraction mismatch")
    require(frontend["source"] == {**release["provenance"], "title": "Conteos Censales de Participación Ciudadana (CCPC)"},
            "Frontend metadata must deliver the exact official provenance")
    methodology = frontend["methodology"]
    keys(methodology, ["unitOfAnalysis", "dimensions", "aggregation", "participation", "abstention", "unspecified", "noData", "samplePolicy"],
         "frontend methodology")
    require(methodology["dimensions"] == ["entityCode", "year", "sex", "ageGroup", "sectionType"]
            and methodology["aggregation"] == "sum_counts_then_divide", "Frontend methodology/aggregation mismatch")
    for name, field, numerator, denominator in [
        ("participation", "ccpcParticipationPct", "voted", "voted+didNotVote"),
        ("abstention", "ccpcAbstentionPct", "didNotVote", "voted+didNotVote"),
        ("unspecified", "unspecifiedPct", "unspecified", "nominalList"),
    ]:
        require(methodology[name] == {"field": field, "numerator": numerator, "denominator": denominator, "unit": "percent"},
                f"Frontend methodology {name} mismatch")
    require(all(nonempty(methodology[key]) for key in ["unitOfAnalysis", "noData", "samplePolicy"]), "Missing frontend methodology explanations")
    require(type(frontend["warnings"]) is list and len(frontend["warnings"]) >= 9, "Missing frontend warnings")
    warning_codes = []
    for warning in frontend["warnings"]:
        keys(warning, ["code", "message"], "frontend warning")
        require(nonempty(warning["code"]) and nonempty(warning["message"]), "Empty frontend warning")
        warning_codes.append(warning["code"])
    require(len(warning_codes) == len(set(warning_codes)) and {"NS_EXCLUDED_FROM_CCPC", "NO_DATA_IS_NOT_ZERO", "NON_BINARY_ONLY_2024",
            "SPARSE_COVERAGE", "ELECTIONS_NOT_A_PANEL", "AGGREGATE_SCOPE_ONLY", "SMALL_CELLS", "EXTRACTION_DATE_PRECISION"} <= set(warning_codes)
            and bool({"CARTOGRAPHIC_FRAMES_DIFFER", "CARTOGRAPHIC_FRAMES_MAY_DIFFER"} & set(warning_codes)), "Frontend warnings incomplete")
    require(frontend["coverage"] == {"years": YEARS, "entityCount": 32, "ageGroupCount": 18, "sectionTypeCount": 3,
                                      "observedCombinations": 20755, "missingCombinations": 10349}, "Frontend coverage mismatch")
    require(frontend["privacy"] == {"directIdentifiersIncluded": False, "assessment": "schema_allowlist_verified", "smallCellsPresent": True,
                                     "anonymityGuarantee": False}, "Frontend privacy explanation mismatch")
    require(frontend["contracts"] == {"dataset": "ccpc-participation/v1", "compact": "ccpc-compact/v1", "capabilities": "ccpc-capabilities/v1",
                                       "frontendMetadata": "ccpc-frontend-metadata/v1"}, "Frontend contracts mismatch")
    keys(frontend["reproducibility"], ["command", "documentation"], "frontend reproducibility")
    require(frontend["reproducibility"]["command"] == "npm run ccpc:release:regenerate -- --output /ruta/de/staging"
            and frontend["reproducibility"]["documentation"] == "docs/data06-release.md", "Frontend regeneration instructions mismatch")
    compact = load(root, COMPACT_PATH)
    keys(compact, ["schemaVersion", "kind", "scope", "years", "metricDefinitions", "dictionaries", "sources", "sourceEntityNames",
                   "columns", "records", "recordsSha256"], "compact")
    require(compact["schemaVersion"] == "ccpc-compact/v1" and compact["kind"] == "full" and compact["scope"] == "entity"
            and compact["years"] == YEARS and compact["columns"] == COLUMNS and compact["recordsSha256"] == RECORDS_SHA,
            "Compact contract mismatch")
    require(compact["dictionaries"] == {"sex": SEXES, "ageGroup": AGES, "sectionType": SECTIONS}, "Compact dimensions mismatch")
    require(len(compact["sources"]) == 192 and len(compact["sourceEntityNames"]) == 192 and len(compact["records"]) == 20755,
            "Compact count mismatch")
    sources = compact["sources"]
    require({(item["year"], item["entityCode"]) for item in sources} == {(year, entity) for year in YEARS for entity in ENTITIES},
            "Source/year/entity coverage mismatch")
    require(sum(item["rawRows"] for item in sources) == 54872712, "Source original row count mismatch")
    observed = set()
    for row in compact["records"]:
        require(type(row) is list and len(row) == 9 and all(integer(value) for value in row), "Invalid compact tuple")
        require(all(row[index] < size for index, size in enumerate([192, 3, 18, 3])) and row[8] > 0, "Invalid tuple index/sourceRows")
        require(row[4] == sum(row[5:8]), "Compact count invariant mismatch")
        key = tuple(row[:4]); require(key not in observed, "Duplicate compact cell"); observed.add(key)
    catalog = load(root, CATALOG_PATH)
    require(catalog["schemaVersion"] == "ccpc-capabilities/v1" and catalog["catalogVersion"] == "1.0.0"
            and catalog["dataset"]["fileSha256"] == COMPACT_SHA and catalog["dataset"]["recordsSha256"] == RECORDS_SHA,
            "Shared catalog release mismatch")
    dictionary = load(root, f"{RELEASE_DIRECTORY}/dictionary.json")
    keys(dictionary, ["schemaVersion", "datasetVersion", "contracts", "compactColumns", "normalizedFields", "dimensions", "metrics", "coverage",
                      "excludedDirectIdentifiers", "sourceReferences", "notes"], "dictionary")
    require(dictionary["schemaVersion"] == "ccpc-data-dictionary/v1" and dictionary["datasetVersion"] == "1.0.0", "Dictionary release mismatch")
    require([item["name"] for item in dictionary["compactColumns"]] == COLUMNS
            and [item["name"] for item in dictionary["normalizedFields"]] == NORMALIZED_FIELDS, "Dictionary field contract mismatch")
    require(REQUIRED_CONTRACTS <= {item["schemaVersion"] for item in dictionary["contracts"]}, "Dictionary contract versions incomplete")
    require(dictionary["dimensions"] == {"years": YEARS, "entityCodes": ENTITIES, "sexesByYear": catalog["dimensions"]["sexesByYear"],
                                           "ageGroups": AGES, "sectionTypes": SECTIONS}, "Dictionary dimensions mismatch")
    require(dictionary["metrics"]["officialDenominator"] == "voted+didNotVote"
            and dictionary["metrics"]["officialFields"] == ["ccpcParticipationPct", "ccpcAbstentionPct"], "Dictionary official methodology mismatch")
    full_manifest = load(root, "data/ccpc/full/manifest.json")
    require(full_manifest["generatedAt"] == extraction["aggregatePackagedAt"], "Original extraction/publication metadata mismatch")
    provenance = release["provenance"]
    keys(provenance, ["publisher", "landingUrl", "manualUrl", "archives"], "provenance")
    require(provenance["publisher"] == "Instituto Nacional Electoral"
            and provenance["landingUrl"] == "https://ine.mx/transparencia/datos-abiertos/visualizacion-datos/conteos-censales-participacion/"
            and provenance["manualUrl"] == "https://ine.mx/wp-content/uploads/2025/06/Manual-Conteos-Censales-2009-2024.pdf", "Official provenance mismatch")
    archives = provenance["archives"]
    require(type(archives) is list and [item["year"] for item in archives] == YEARS, "Archive source years mismatch")
    catalog_sources = load(root, "data/ccpc/sources.json")["sources"]
    acquired_sources = full_manifest["acquisition"]["downloads"]
    for archive, original, acquired in zip(archives, catalog_sources, acquired_sources):
        keys(archive, ["year", "url", "sha256", "acquiredAt"], "official archive")
        require((archive["year"], archive["url"], archive["sha256"]) == (original["year"], original["url"], original["sha256"]),
                "Archive provenance disagrees with source catalog")
        require(archive["acquiredAt"] == acquired["downloadedAt"] and archive["sha256"] == acquired["sha256"],
                "Archive acquisition timestamp/hash changed")
        utc(archive["acquiredAt"], "archive.acquiredAt")
    checksums = read(root, f"{RELEASE_DIRECTORY}/checksums.sha256").decode("ascii")
    checksum_entries = {}
    for line in checksums.splitlines():
        match = re.fullmatch(r"([a-f0-9]{64})  ([a-z0-9.-]+)", line)
        require(match and match[2] not in checksum_entries, "Invalid or duplicate release checksum entry")
        checksum_entries[match[2]] = match[1]
    require(set(checksum_entries) == {"dictionary.json", "frontend-metadata.json", "schema-lock.json", "release.json"},
            "Release checksums must cover exactly four frozen files")
    for name, expected in checksum_entries.items():
        require(digest(read(root, f"{RELEASE_DIRECTORY}/{name}")) == expected, f"Release checksum mismatch: {name}")
    require(checksums == "".join(f"{digest(read(root, f'{RELEASE_DIRECTORY}/{name}'))}  {name}\n"
                                for name in ["dictionary.json", "frontend-metadata.json", "schema-lock.json", "release.json"]),
            "Release checksum bytes/order/newlines differ from the frozen contract")
    keys(release["validation"], ["commands", "evidenceDirectory"], "validation")
    require(type(release["validation"]["commands"]) is list and all(nonempty(item) for item in release["validation"]["commands"])
            and release["validation"]["commands"] and release["validation"]["evidenceDirectory"] == "docs/data06-evidence", "Invalid validation specification")
    keys(release["reproducibility"], ["regenerator", "fixedMetadata", "noRawRecordsInRelease"], "reproducibility")
    require(release["reproducibility"] == {"regenerator": "scripts/ccpc/regenerate-dataset-v1.ts", "fixedMetadata": True,
                                          "noRawRecordsInRelease": True}, "Invalid reproduction policy")
    read(root, release["reproducibility"]["regenerator"])
    require(not any("/raw/" in path or "/processed/" in path or path.endswith(".zip") for path in artifacts),
            "Raw originals must not be frozen runtime artifacts")
    return {"schemaVersion": "ccpc-data06-independent-audit/v1", "status": "pass", "datasetVersion": "1.0.0",
            "releaseSha256": expected_sha, "datasetSha256": COMPACT_SHA, "catalogSha256": CATALOG_SHA,
            "frozenArtifacts": len(artifacts), "lockedFiles": len(locked_files), "checksummedReleaseFiles": 4,
            "records": 20755, "sources": 192, "sourceRows": 54872712, "independent": True,
            "productionImports": False, "networkUsed": False,
            "scope": "Frozen bytes, external pin, schema lock, provenance, dictionary and metadata; use DATA-04/05 audits for independent query/coverage calculations."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        result = audit(args.root.resolve())
        if args.output:
            target = args.output.resolve()
            root = args.root.resolve()
            require(not target.is_relative_to(root) or target.is_relative_to(root / "docs/data06-evidence"),
                    "Audit output inside package must be under docs/data06-evidence")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, KeyError, IndexError, TypeError) as error:
        print(json.dumps({"schemaVersion": "ccpc-data06-independent-audit/v1", "status": "fail", "error": str(error)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
