#!/usr/bin/env python3
"""Inventario y ZIP reproducibles de DATA-06, sin originales ni dependencias."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
IGNORED_DIRECTORIES = {"node_modules", ".git", "__pycache__"}
IGNORED_PREFIXES = {"data/ccpc/raw", "data/ccpc/processed"}


def delivery_files():
    files = []
    for directory, dirs, names in os.walk(ROOT, followlinks=False):
        parent = Path(directory)
        dirs[:] = sorted(name for name in dirs if name not in IGNORED_DIRECTORIES
                         and (parent / name).relative_to(ROOT).as_posix() not in IGNORED_PREFIXES)
        for name in dirs:
            if (parent / name).is_symlink():
                raise ValueError(f"No se distribuyen enlaces: {parent / name}")
        for name in sorted(names):
            path = parent / name
            if name in {".env", ".DS_Store"} or name.startswith(".env.") or path.suffix in {".zip", ".part", ".pyc"}:
                continue
            if path.is_symlink():
                raise ValueError(f"No se distribuyen enlaces: {path}")
            files.append(path)
    return sorted(files, key=lambda path: path.relative_to(ROOT).as_posix())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--update-manifest", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.suffix != ".zip":
        parser.error("--output debe terminar en .zip")
    manifest_path = ROOT / "DELIVERY-MANIFEST.json"
    files = delivery_files()
    inventory = [{"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size,
                  "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                 for path in files if path != manifest_path]
    manifest = {"schemaVersion": "ccpc-delivery/v1", "files": inventory}
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if args.update_manifest:
        manifest_path.write_bytes(manifest_bytes)
    elif not manifest_path.is_file() or manifest_path.read_bytes() != manifest_bytes:
        parser.error("Inventario desactualizado. Revisar cambios y usar --update-manifest al publicar.")
    files = delivery_files()
    if not (ROOT / "data/ccpc/full/participation.compact.json").is_file():
        parser.error("Falta el agregado full; no se publicará una entrega basada solo en la muestra.")
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            info = zipfile.ZipInfo("Ine-hacktoon-DATA-06/" + path.relative_to(ROOT).as_posix(), (2026, 10, 22, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP corrupto")
        expected = {"Ine-hacktoon-DATA-06/" + path.relative_to(ROOT).as_posix() for path in files}
        if set(archive.namelist()) != expected:
            raise ValueError("El ZIP no coincide con el inventario")
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(".zip.sha256").write_text(f"{digest}  {output.name}\n", encoding="utf-8")
    print(json.dumps({"zip": str(output), "bytes": output.stat().st_size, "files": len(files),
                      "sha256": digest, "rawOrDependenciesIncluded": False}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
