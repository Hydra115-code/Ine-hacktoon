# DATA-04 — Construir paquete CCPC completo

Objetivo: reemplazar la muestra como entrada principal del backend por un agregado completo, ligero y reproducible. La muestra permanece identificada como fixture. Base: rama Data, commit `10c219c322e06a21c27a73d59d09bc05aad0409a`; la entrega original no incluía `.git`.

Estado de ejecución: **COMPLETO — 8/8 puntos y 4/4 Definition of Done**. Se ejecutaron 122 pruebas en Node.js 24.19.0 sin fallos ni omisiones; TypeScript, auditoría independiente, reproducción y carga desde copia limpia aprobaron. Los puntos se cierran con evidencia de esta ejecución.

## Checklist obligatorio

- [x] **Procesar 2009, 2012, 2015, 2018, 2021 y 2024.** Recorrido real de los seis ZIP con hashes fijados del INE; log actual en `data04-evidence/rebuild-full.log` y adquisición en el manifiesto full.
- [x] **Incluir las 32 entidades.** Deben aparecer las 192 combinaciones entidad × año tanto en fuentes como en consultas; `coverage-report.json` y auditoría Python.
- [x] **Conservar sexo, grupo de edad y tipo de sección.** Tres categorías de sexo (no_binario solo observado en 2024), 18 bandas desde 18–19 hasta 100+, urbana/mixta/rural; sin rellenar cruces ausentes con ceros. Auditoría de claves, categorías, conteos y sourceRows.
- [x] **Generar JSON optimizado, SQLite o ambos.** Se entrega JSON compacto de nueve enteros por grupo y diccionarios comunes; rehidrata exactamente el contrato existente. Tamaño y SHA-256 en `data/ccpc/full/manifest.json`.
- [x] **Diferenciar claramente sample y full.** `data/ccpc/full/` y `kind: full` son la entrada principal; fixture anterior en `sample/` y `kind: sample`. El cargador full rechaza sample y no tiene fallback.
- [x] **Incluir versión, fecha, hash y procedencia.** Manifiesto del paquete, adquisición real de esta ejecución, URLs oficiales, SHA-256 ZIP/CSV/diccionario por fuente y pin externo del archivo publicado.
- [x] **No subir los 54 millones de registros originales.** El ZIP de entrega excluye raw/processed, ZIP INE, node_modules y enlaces locales; contiene únicamente agregado, muestra pequeña, código, documentación y evidencia.
- [x] **Ejecutar las cuatro consultas sobre el agregado.** `queries.json` contiene llamadas/salidas nuevas de los cuatro métodos. Cobertura automatizada de 192 entidad-año, desgloses, comparaciones, filtros y ausencia de datos; recalculadas con Python independiente.

## Definition of Done

| Requisito | Evidencia de aceptación |
| --- | --- |
| Las 32 entidades y los seis años pueden consultarse. | Cargador portable + `coverage-report.json`: 192 resúmenes y soportes, seis elecciones nacionales. |
| Las cuatro consultas del backend funcionan. | Contratos originales intactos; pruebas Node, `queries.json` y `independent-package-audit.json`. |
| Participación y abstención utilizan el denominador oficial. | Campos `ccpcParticipationPct`/`ccpcAbstentionPct` sobre SV+NV; NS separado; null con denominador cero; comparación oficial en puntos porcentuales. |
| Backend puede consumirlo sin modificar el ETL. | `createFullParticipationService()`; prueba desde una copia limpia sin raw/processed; los archivos anteriores de ETL se conservan byte a byte. |

Las tasas nominales históricas se conservan por compatibilidad con su nombre y definición original. Para el producto se documentan y comprueban los campos oficiales `ccpc*`, sin renombrar silenciosamente las métricas de DATA-02/03.

## Ejecución reproducible de aceptación

```sh
npm ci --ignore-scripts
npm run ccpc:check
npm run ccpc:verify-delivery
```

La ejecución de aceptación final, los hashes y el inventario del ZIP deben registrarse en `data04-evidence/acceptance.json`. La auditoría Python usa solo biblioteca estándar y no importa funciones de producción: reconstruye el CSV DATA-01, compara su SHA inmutable, revisa todas las fuentes/grupos y recalcula los resultados del backend. Los manifiestos son controles de integridad relativos a esta publicación; no son firmas digitales del INE.
