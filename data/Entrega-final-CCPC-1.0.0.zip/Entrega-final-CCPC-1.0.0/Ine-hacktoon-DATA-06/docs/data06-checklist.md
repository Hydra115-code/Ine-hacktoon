# DATA-06 — Checklist y aceptación de dataset 1.0.0

**Estado: 9/9 puntos implementados y verificados. Los cuatro criterios de aceptación se verifican en el paquete, el adaptador backend y el frontend de referencia incluidos.** [Guía de release](data06-release.md).

## Checklist obligatorio

| Requisito | Resultado y evidencia |
| --- | --- |
| Etiquetar dataset como 1.0.0 | `release.json`, diccionario, metadatos frontend y respuestas de consulta declaran 1.0.0; estado `frozen`. [Validación](data06-evidence/validation.json). |
| Calcular SHA-256 | Pin externo del manifiesto, hashes de los 13 artefactos y 14 archivos de contratos/regeneración; `checksums.sha256` del release y checksum externo del ZIP. [Auditoría independiente](data06-evidence/independent-release-audit.json). |
| Actualizar diccionario | [dictionary.json](../data/ccpc/releases/1.0.0/dictionary.json) y [explicación](data06-dictionary.md): 21 campos normalizados, nueve columnas compactas, dimensiones, unidades y fórmulas. |
| Registrar fuente oficial | Seis URLs INE, hashes y fechas de adquisición; página oficial y manual, en manifiesto y metadatos frontend. [release.json](../data/ccpc/releases/1.0.0/release.json). |
| Registrar fecha de extracción | Día UTC `2026-10-22`, adquisiciones reales y primer empaquetado `2026-10-22T00:59:19Z`; precisión y hora de filas desconocida explícitas. No se confunde con publicación del release. [Metadatos](../data/ccpc/releases/1.0.0/frontend-metadata.json). |
| Documentar limitaciones | Nueve advertencias frontend y límites de alcance, celdas pequeñas, cartografía, sexo, ausencia y comparaciones. [Guía](data06-release.md), [privacidad](data06-privacy.md). |
| Conservar script de regeneración | `ccpc:release:regenerate` reconstruye cinco archivos en staging y exige igualdad byte a byte; ETL DATA-04 y constructor de catálogo DATA-05 conservados. [Reproducción](data06-evidence/reproduction.json). |
| Guardar resultados de validación | 149 pruebas aprobadas, TypeScript y regresiones DATA-04/05, verificación de release, auditoría independiente, pruebas negativas, privacidad y navegador. [Checks](data06-evidence/checks.json), [log](data06-evidence/checks.log). |
| Confirmar que no hay datos personales directos | Auditoría estricta de 16 archivos de datos/metadatos: sin nombres personales, CURP, clave de elector, correo, teléfono, domicilio ni identificadores individuales. [Resultado](data06-evidence/privacy-audit.json). Se conservan celdas pequeñas; no se afirma anonimato absoluto. |

## Definition of Done

| Criterio | Comprobación |
| --- | --- |
| No se cambia el esquema después del 26 | Congelación efectiva desde este release, con límite local documentado `2026-10-26` en America/Monterrey. Cualquier deriva de los 14 archivos fijados impide el arranque; una modificación requiere otra versión. La inicialización repetida y la regeneración sobre la publicación son rechazadas. [Bloqueo](../data/ccpc/releases/1.0.0/schema-lock.json), [guardas](data06-evidence/publication-guards.json). |
| El backend verifica la integridad al iniciar | `createFrozenParticipationService` comprueba pin externo, manifiesto, archivos de datos, contratos, diccionario, metadatos y checksums antes de crear el servicio. La demostración espera ese arranque antes de `listen`. Pruebas alteran individualmente los 13 artefactos y 14 archivos bloqueados; todas las alteraciones son rechazadas. [Pruebas](data06-evidence/checks.log). |
| Frontend recibe fuente, metodología y advertencias | `GET /api/dataset` sirve el snapshot verificado. Edge muestra versión 1.0.0, fuente INE, manual, fórmulas, fechas y nueve advertencias. Las consultas y `no_data` conservan versión y hash. [Navegador](data06-evidence/browser-verification.json), [captura](data06-evidence/frontend-metadata.jpg). |
| La versión final es reproducible | Los cinco archivos del release se regeneran idénticos byte a byte a partir de las entradas fijadas DATA-04/05; el pin no cambia. La distribución ZIP usa metadatos de archivo fijos y un inventario. [Resultado](data06-evidence/reproduction.json). |

La política de congelación no depende del reloj: rechaza cambios hoy y después de la fecha límite. Esto verifica el mecanismo y los contratos publicados, sin afirmar control sobre futuras ediciones fuera de este paquete. Las aplicaciones externas del equipo deben adoptar el punto de entrada 1.0.0; no se proporcionaron sus repositorios para ejecutar ese despliegue.

## Evidencia adicional

- **Instalación limpia del ZIP extraído:** ocho dependencias instaladas desde caché y verificación completa aprobada. Los archivos de ejecución finales coinciden con los comprobados: [clean-validation.json](data06-evidence/clean-validation.json).
- **149 pruebas, 149 aprobadas, 0 fallos y 0 omitidas**, con Node.js 26.7.0 y Python 3.14.7: [checks.json](data06-evidence/checks.json).
- **22 casos negativos del auditor de release**, todos rechazados; incluye archivos alterados o ausentes, enlaces, manifiesto rehasheado, rutas, campos y fechas inválidas: [independent-negative-tests.json](data06-evidence/independent-negative-tests.json). Son pruebas del auditor independiente, además de las pruebas de arranque del backend.
- **26 casos negativos de privacidad** rechazados: [18 casos de payload/catálogo/CSV](data06-evidence/privacy-negative-tests.json), [ocho de metadatos/diccionario/bloqueo](data06-evidence/privacy-metadata-negative-tests.json).
- **Inicio desde otro directorio de trabajo**, sin crudos ni ETL: [cold-start-outside-cwd.json](data06-evidence/cold-start-outside-cwd.json).
- **148 archivos anteriores DATA-05 intactos**, incluidos datos, esquemas, ETL, catálogo y pruebas anteriores. Sólo README, metadatos npm e inventario raíz se actualizan; DATA-06 se añade en archivos nuevos: [preservación](data06-evidence/data05-preservation.json).
- **Privacidad:** 54 celdas full con LN=1 y 124 con LN de 1 a 4. Se confirma ausencia de identificadores personales directos, sin suprimir datos ni prometer anonimato absoluto.

La entrega publica un artefacto local versionado. No se creó una etiqueta Git ni una publicación remota de GitHub. Los informes históricos DATA-04/05 permanecen separados de las verificaciones actuales.
