# DATA-06 — Diccionario congelado de datos 1.0.0

La entrega final identifica el **dataset 1.0.0**, de alcance **entidad** y clase **full**. El [diccionario JSON](../data/ccpc/releases/1.0.0/dictionary.json) es su definición legible por máquinas. El agregado sigue los contratos de DATA-04 y el catálogo de DATA-05 sin cambiar sus nombres, tipos, unidades, nulos, claves ni semántica. La versión de datos y la versión de esquema son identidades distintas.

## Contratos congelados

| Esquema | Función |
| --- | --- |
| `ccpc-participation/v1` | Contrato normalizado existente: 21 campos por registro, conteos, métricas y procedencia; no cambia al etiquetar el dataset 1.0.0. |
| `ccpc-compact/v1` | Artefacto full existente con tuplas de nueve enteros e índices desde cero; reconstruye el contrato normalizado sin ETL. |
| `ccpc-capabilities/v1` | Catálogo compartido existente: dimensiones, matriz de cobertura de estados 0/1/2, cuatro consultas y reglas de no_data. |
| `ccpc-dataset-release/v1` | Manifiesto de versión, integridad, fuentes, extracción, regeneración e invariantes de congelamiento; acompaña los contratos existentes sin alterar sus campos. |
| `ccpc-frontend-metadata/v1` | Metadatos para frontend: fuente oficial, metodología y advertencias de la misma versión de datos. |
| `ccpc-schema-lock/v1` | Descriptor y huellas de los contratos congelados; rechazo de cambios de esquema sin una publicación nueva. |
| `ccpc-query-response/v1` | Envoltura de consulta que identifica versión de datos, contrato, fuentes, metodología y advertencias sin modificar el resultado previo del dominio. |
| `ccpc-data-dictionary/v1` | Este diccionario legible por máquinas, congelado con la versión 1.0.0. |

El esquema de esta publicación queda fijado desde su congelamiento, incluido el compromiso de no modificarlo después del **26 de octubre de 2026**, con fecha local y zona `America/Monterrey` declaradas en la política de congelamiento. Una corrección futura requiere otro artefacto y versión; una ruptura de contrato requiere una nueva versión mayor de esquema. La existencia del diccionario no modifica retroactivamente los archivos históricos de DATA-04 o DATA-05. Los hashes y controles de la publicación documentan la identidad comprobable; una política de congelamiento no garantiza por sí sola la adopción en repositorios externos.

## Identidad y campos normalizados

Clave única, con este orden: **`year|entityCode|sex|ageGroup|sectionType`**. Se suman primero los cuatro conteos de las filas originales del grupo y se calculan después las métricas. No se promedian porcentajes de otros grupos. Todos los conteos son enteros seguros no negativos; `sourceRows` es positivo.

| Campo | Tipo | Unidad | Nulo | Definición |
| --- | --- | --- | --- | --- |
| `entityCode` | `string` | `INE_entity_code` | no | Clave EDOCVE de dos dígitos entre 01 y 32; conserva cero inicial y forma parte de la clave compuesta. |
| `entityName` | `string` | `label` | no | EDONOM observado para la entidad y el año; se obtiene de sourceEntityNames. No sustituye a entityCode para unir cortes. |
| `year` | `integer` | `election_year` | no | Año AELEC permitido; forma parte de la clave compuesta. |
| `sex` | `string` | `category` | no | hombre, mujer o no_binario; forma parte de la clave. no_binario sólo aparece en 2024. |
| `ageGroup` | `string` | `age_band_years` | no | Una de 18 bandas de edad cumplida; 18-19 abarca dos edades y 100+ es abierto. Forma parte de la clave. |
| `sectionType` | `string` | `category` | no | urbana, mixta o rural; traduce U/M/R. Forma parte de la clave y no identifica una sección concreta. |
| `nominalList` | `integer` | `count` | no | Suma LN de los cuadernillos del universo CCPC; entero seguro no negativo. LN = SV + NV + NS. |
| `voted` | `integer` | `count` | no | Suma SV: registros con marca de voto, sin información de partido o candidatura. |
| `didNotVote` | `integer` | `count` | no | Suma NV: registros sin marca de voto; excluye los no especificados NS. |
| `unspecified` | `integer` | `count` | no | Suma NS: participación no especificada; no se reclasifica como abstención. |
| `classified` | `integer` | `count` | no | voted + didNotVote; denominador oficial de participación y abstención CCPC. |
| `participationRate` | `number` | `ratio_0_1` | sí | voted / nominalList; tasa nominal heredada, null cuando nominalList = 0. No es el indicador oficial CCPC. |
| `abstentionRate` | `number` | `ratio_0_1` | sí | didNotVote / nominalList; tasa nominal heredada, null cuando nominalList = 0. |
| `unspecifiedRate` | `number` | `ratio_0_1` | sí | unspecified / nominalList; null cuando nominalList = 0. |
| `participationPct` | `number` | `percent_0_100` | sí | 100 * voted / nominalList; porcentaje nominal heredado, null cuando nominalList = 0. No presentar como participación oficial CCPC. |
| `abstentionPct` | `number` | `percent_0_100` | sí | 100 * didNotVote / nominalList; porcentaje nominal heredado, null cuando nominalList = 0. |
| `unspecifiedPct` | `number` | `percent_0_100` | sí | 100 * unspecified / nominalList; null cuando nominalList = 0. |
| `ccpcParticipationPct` | `number` | `percent_0_100` | sí | 100 * voted / (voted + didNotVote); participación oficial, excluye NS; null cuando classified = 0. |
| `ccpcAbstentionPct` | `number` | `percent_0_100` | sí | 100 * didNotVote / (voted + didNotVote); abstención oficial, excluye NS; null cuando classified = 0. |
| `sourceId` | `string` | `source_key` | no | Identificador año:clave de entidad que referencia sources[].id; no contiene un identificador personal. |
| `sourceRows` | `integer` | `source_row_count` | no | Número positivo de filas CSV originales que contribuyeron al grupo; entero seguro y distinto de LN. |

`nominalList = voted + didNotVote + unspecified` es una identidad contable comprobada. `sourceRows` cuenta filas CSV agregadas y **no** personas. Un registro con `SV=0` y `SV+NV>0` tiene participación oficial de 0 %; eso es distinto de un cruce que carece de fila.

## Indicadores oficiales y campos heredados

Los indicadores oficiales que debe presentar la aplicación son **`ccpcParticipationPct`** y **`ccpcAbstentionPct`**. Usan `SV+NV`; los no especificados `NS` permanecen separados. Los campos heredados `participationRate`, `abstentionRate`, `participationPct` y `abstentionPct` usan `LN` para conservar compatibilidad y no deben rotularse como indicadores oficiales CCPC. `unspecifiedRate` y `unspecifiedPct` también usan LN.

Si LN es cero, las seis tasas y porcentajes nominales son `null`. Si `SV+NV` es cero, ambos porcentajes oficiales son `null`, aunque LN pueda ser positivo por NS. Ninguna división indefinida se sustituye por cero. Se conserva la precisión numérica de JavaScript sin redondeo editorial en el contrato normalizado; el CSV intermedio histórico utiliza hasta seis decimales.

En comparaciones, `ccpcParticipationPercentagePoints` y `ccpcAbstentionPercentagePoints` restan el porcentaje oficial del año base al del año actual; su unidad es **puntos porcentuales**. `participationPercentagePoints`, `abstentionPercentagePoints` y `participationRelativePercent` mantienen el significado nominal heredado. Este último es `100 × (actual-base) / base` sobre `participationPct`; es nulo si la base es cero o algún extremo es nulo. Las diferencias son nulas si falta un porcentaje de cualquiera de los extremos. El año base es el primero después de ordenar los años únicos de manera ascendente.

## Transporte compacto y procedencia

`participation.compact.json` mantiene `schemaVersion: "ccpc-compact/v1"`, `kind: "full"`, `scope: "entity"` y una tupla de **nueve enteros** por registro. El orden es parte del contrato y los índices comienzan en cero:

| Posición | Columna | Tipo | Interpretación |
| ---: | --- | --- | --- |
| 0 | `sourceIndex` | `integer` | Índice desde cero en sources y sourceEntityNames; resuelve year, entityCode, entityName y sourceId. |
| 1 | `sexIndex` | `integer` | Índice desde cero en dictionaries.sex. |
| 2 | `ageGroupIndex` | `integer` | Índice desde cero en dictionaries.ageGroup. |
| 3 | `sectionTypeIndex` | `integer` | Índice desde cero en dictionaries.sectionType. |
| 4 | `nominalList` | `integer` | Suma de LN; entero seguro no negativo. |
| 5 | `voted` | `integer` | Suma de SV; entero seguro no negativo. |
| 6 | `didNotVote` | `integer` | Suma de NV; entero seguro no negativo. |
| 7 | `unspecified` | `integer` | Suma de NS; entero seguro no negativo, separado de NV. |
| 8 | `sourceRows` | `integer` | Número positivo de filas CSV originales agregadas; no es un conteo de personas. |

`sourceIndex` identifica simultáneamente `sources[sourceIndex]` y `sourceEntityNames[sourceIndex]`. El primero aporta año, clave de entidad y `sourceId`; el segundo conserva la etiqueta territorial de ese corte. Los índices de sexo, edad y tipo se resuelven con los tres arreglos `dictionaries`. Las métricas se reconstruyen a partir de los cuatro conteos y se validan; no se almacenan porcentajes redondeados en las tuplas.

El objeto superior compacto tiene exactamente `columns`, `dictionaries`, `kind`, `metricDefinitions`, `records`, `recordsSha256`, `schemaVersion`, `scope`, `sourceEntityNames`, `sources` y `years`. `recordsSha256` identifica la representación canónica de los registros normalizados; el SHA-256 del archivo identifica sus bytes. Son comprobaciones distintas y ambas se conservan.

Cada elemento de `sources` tiene estos campos:

| Campo | Tipo y unidad | Significado |
| --- | --- | --- |
| `id` | texto | `año:clave`, único; lo referencia `sourceId`. |
| `entityCode` | texto de dos dígitos | Clave INE de la entidad del CSV. |
| `year` | entero, año | Corte electoral del CSV. |
| `url` | texto, URL | ZIP oficial de origen. |
| `archiveSha256` | texto hexadecimal, 64 caracteres | SHA-256 de los bytes originales del ZIP. |
| `member` | texto, ruta | Nombre completo del CSV dentro del ZIP. |
| `memberSha256` | texto hexadecimal, 64 caracteres | SHA-256 de los bytes originales del CSV. |
| `dictionarySha256` | texto hexadecimal, 64 caracteres | SHA-256 de los bytes originales del TXT de ese año. |
| `downloadedAt` | texto UTC o `null` | Fecha efectiva conocida de adquisición; nula cuando el contrato histórico carecía de registro fiable. |
| `rawRows` | entero positivo, filas | Número total de filas originales del CSV. |
| `totals` | objeto de cuatro enteros | `nominalList`, `voted`, `didNotVote`, `unspecified` de esa fuente. |

Las fechas de adquisición, verificación, agregación/extracción y congelamiento describen operaciones diferentes. La procedencia histórica nula del contrato no se inventa ni se reemplaza por el mtime. El manifiesto de publicación registra separadamente las fechas efectivamente acreditadas, y conserva las huellas de los seis ZIP, sus 192 CSV y seis TXT. El paquete ligero no distribuye esos originales.

## Dimensiones y cobertura

Años disponibles: **2009, 2012, 2015, 2018, 2021 y 2024**. Existen registros de las **32 entidades** en cada año; las claves son cadenas de `"01"` a `"32"` y no se convierten en números. Las etiquetas por año provienen de `dimensions.entities[].namesByYear` del catálogo. En la clave `09` se conserva `DISTRITO FEDERAL` de 2009 a 2018 y `CIUDAD DE MEXICO` en 2021 y 2024; la unión usa la clave, no la igualdad del nombre.

| Años | Categorías de sexo |
| --- | --- |
| 2009, 2012, 2015, 2018, 2021 | `hombre`, `mujer` |
| 2024 | `hombre`, `mujer`, `no_binario` |

La ausencia de `no_binario` en los cortes antiguos **no es una observación de cero**. Su presencia en 2024 tampoco garantiza todos los cruces de entidad, edad y tipo.

Los 18 grupos de edad son: `18-19`, `20-24`, `25-29`, `30-34`, `35-39`, `40-44`, `45-49`, `50-54`, `55-59`, `60-64`, `65-69`, `70-74`, `75-79`, `80-84`, `85-89`, `90-94`, `95-99`, `100+`. Se agrupa por edad cumplida; 100+ conserva todas las edades de 100 o más. Los tres tipos de sección son `urbana`, `mixta` y `rural`; no permiten identificar una sección electoral concreta.

La matriz del catálogo tiene forma `[6,32,3,18,3]` y ejes `year`, `entityCode`, `sex`, `ageGroup`, `sectionType`; la última dimensión cambia más rápido. Contiene **31,104 cruces posibles**, **20,755 observados** y **10,349 ausentes**. De los ausentes, 8,640 corresponden a `no_binario` antes de 2024 y 1,709 son cruces no observados entre categorías existentes en su año.

| Estado | Nombre de contrato | Significado |
| --- | --- | --- |
| `0` | `no_records` | No existe registro para el cruce; no se imputan conteos ni porcentajes. |
| `1` | `records_without_official_denominator` | Existe registro pero `SV+NV=0`; porcentajes oficiales nulos. |
| `2` | `records_with_official_denominator` | Existe registro y `SV+NV>0`. |

Esta versión no tiene celdas en estado `1`; el contrato conserva ese estado para tratar correctamente denominadores cero. El catálogo completo es el mismo para frontend y backend y no se deriva de las etiquetas del fixture. `kind=sample` identifica una muestra separada para desarrollo; no acredita cobertura completa ni puede sumarse con full.

## Consultas y ausencia de datos

Las cuatro consultas congeladas son `getParticipationSummary`, `compareElections`, `getParticipationBreakdown` y `getSupportingRecords`. El desglose permite `entity`, `year`, `sex`, `ageGroup` o `sectionType`. Los filtros permitidos son `year`, `entityCodes`, `sexes`, `ageGroups` y `sectionTypes`: OR dentro de una lista y AND entre dimensiones. Una consulta no comparativa sin año usa 2024. Las listas explícitas son no vacías y no contienen duplicados.

El adaptador de cobertura responde `status: "no_data"` y `result: null` cuando la combinación no existe o la comparación es inválida. No genera cifras cero para llenar huecos. Las comparaciones requieren entre dos y seis años únicos, datos en todos los años y presencia de cada categoría explícita en cada año; `no_binario` entre 2021 y 2024 no es una comparación válida. `getSupportingRecords` puede recuperar registros existentes sin denominador oficial positivo; las preguntas de indicadores no producen porcentajes definidos cuando falta ese denominador.

Una selección agregada puede sumar cruces observados y declarar los ausentes con `SPARSE_SELECTION`. No elimina silenciosamente una categoría explícita completamente ausente ni imputa los cruces vacíos. El onboarding evalúa cada solicitud antes de sugerirla y el backend vuelve a evaluarla. Un fallo de integridad impide iniciar el servicio y **no** se transforma en `no_data`.

## Fuente oficial, alcance y datos personales directos

Las referencias ya registradas en la entrega son:

- [INE: Conteos Censales de Participación Ciudadana](https://ine.mx/transparencia/datos-abiertos/visualizacion-datos/conteos-censales-participacion/)
- [INE: Manual de Conteos Censales de Participación Ciudadana 2009-2024, pp. 12-13 y 17-18](https://ine.mx/wp-content/uploads/2025/06/Manual-Conteos-Censales-2009-2024.pdf)
- [INE: ZIP oficial CCPC 2009](https://ine.mx/wp-content/uploads/2022/04/DatosAbiertos_DECEyEC_ConteosCensales2009.zip)
- [INE: ZIP oficial CCPC 2012](https://ine.mx/wp-content/uploads/2022/04/DatosAbiertos_DECEyEC_ConteosCensales2012.zip)
- [INE: ZIP oficial CCPC 2015](https://ine.mx/wp-content/uploads/2022/04/DatosAbiertos_DECEyEC_ConteosCensales2015.zip)
- [INE: ZIP oficial CCPC 2018](https://ine.mx/wp-content/uploads/2022/04/DatosAbiertos_DECEyEC_ConteosCensales2018.zip)
- [INE: ZIP oficial CCPC 2021](https://ine.mx/wp-content/uploads/2022/04/DatosAbiertos_DECEyEC_ConteosCensales2021.zip)
- [INE: ZIP oficial CCPC 2024](https://ine.mx/wp-content/uploads/2025/08/DatosAbiertos_DECEyEC_ConteosCensales2024.zip)

El manual fundamenta los grupos y sexo en pp. 12-13, y los denominadores en pp. 17-18. El universo CCPC excluye casillas especiales y voto desde el extranjero según sus diccionarios. No se intercambia con cómputos electorales sin cotejar el universo.

Los cortes describen participación agregada. No identifican a las mismas personas o secciones entre años ni prueban causas. Se conservan las advertencias `ELECTIONS_NOT_A_PANEL`, `CARTOGRAPHIC_FRAMES_MAY_DIFFER` y `SEX_CATEGORIES_MAY_DIFFER`. Tampoco responden por partido/candidatura, edad exacta, municipio, distrito, casilla o sección específica, ingreso, escolaridad, etnia, menores de 18 años, años fuera del catálogo, causalidad o predicción. El catálogo detalla estas preguntas fuera de alcance.

La revisión del esquema de entrada y de los campos exportados confirma la **ausencia de identificadores personales directos**: nombre personal, domicilio personal, teléfono, correo, CURP, RFC, clave de elector, número de credencial o identificador individual. `entityName` es un lugar y `sourceId` identifica un archivo de datos. Municipio, distrito, sección exacta y edad exacta tampoco se distribuyen en el agregado final.

Se mantienen celdas pequeñas, incluidas LN=1. Esta constatación de campos excluidos no equivale a certificar anonimato absoluto o imposibilidad de inferencia por cruces externos. La entrega no suprime, redistribuye ni inventa conteos. La evidencia de validación de DATA-06 debe leerse junto con los resultados históricos y no se sustituye con este diccionario.

La adopción del catálogo y los metadatos en las aplicaciones reales del equipo se verifica al integrar los adaptadores en esos repositorios; este diccionario define el contrato que deben consumir.
