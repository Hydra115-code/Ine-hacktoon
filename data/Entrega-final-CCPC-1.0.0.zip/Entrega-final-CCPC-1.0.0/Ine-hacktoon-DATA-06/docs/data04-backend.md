# DATA-04: agregado completo portátil para backend

El backend puede cargar el agregado completo de los seis cortes una vez al iniciar y reutilizar las cuatro consultas síncronas de DATA-03. Esta ruta usa `data/ccpc/full/participation.compact.json`; no descarga ZIP, no lee CSV crudos ni la referencia CSV de DATA-01 y no ejecuta el ETL. El ETL y la ruta anterior de muestra conservan su contrato.

## Integración

Requiere las dependencias del módulo y Node.js `^22.18.0 || >=23.6.0`, con ESM y soporte nativo de TypeScript. Desde la raíz del proyecto, instalar con `npm ci --ignore-scripts`. Esta instalación puede necesitar el registro npm; la carga y las consultas posteriores son locales y no requieren claves de modelos.

Guardar como `backend-example.mjs` en la raíz del módulo y ejecutar `node backend-example.mjs`:

```javascript
import { createFullParticipationService } from './src/data/full-participation.ts';

// Inicialización: leer y validar una vez; reutilizar engine entre solicitudes.
const engine = await createFullParticipationService();

const summary = engine.getParticipationSummary({
  year: 2024, entityCodes: ['06'],
});
const comparison = engine.compareElections({
  entityCodes: ['06'],
}, [2018, 2024]);
const breakdown = engine.getParticipationBreakdown({
  year: 2024, entityCodes: ['06'],
}, 'sex');
const supportingRecords = engine.getSupportingRecords({
  year: 2024, entityCodes: ['01'], sexes: ['hombre'],
  ageGroups: ['18-19'], sectionTypes: ['urbana'],
});

console.log(JSON.stringify({ summary, comparison, breakdown, supportingRecords }, null, 2));
```

Las API se exportan desde `src/data/full-participation.ts`:

| API | Resultado y responsabilidad |
| --- | --- |
| `loadFullParticipationDataset(path?: string \| URL)` | Promesa del `ParticipationDataset` v1 completo, tras verificar bytes, formato compacto, cobertura, conteos y huella histórica de registros. |
| `createFullParticipationService(path?: string \| URL)` | Promesa del servicio DATA-03 sobre un repositorio inmutable del dataset cargado. |
| `decodeCompactDataset(input: unknown)` | Rehidrata un objeto compacto en memoria y comprueba el contrato completo y la huella histórica de registros. La comprobación de los bytes del archivo y su procedencia de release corresponde al loader. |

El archivo predeterminado se resuelve desde `import.meta.url` del módulo; no depende del directorio de trabajo del proceso. Para una ubicación explícita, pasar una ruta absoluta o una URL de archivo:

```javascript
const engine = await createFullParticipationService(
  new URL('./data/ccpc/full/participation.compact.json', import.meta.url),
);
```

Un archivo ausente, alterado o incompleto hace fallar la carga. El backend debe fallar esa publicación y comunicar el error, sin sustituirla silenciosamente por la muestra. Registrar herramientas MCP, resolver autenticación y paginar el transporte siguen siendo responsabilidades del backend. Ninguna consulta llama a Gemini o a otro modelo.

## Contrato de las cuatro consultas

Los métodos, tipos y esquemas de salida son los originales de DATA-03. Los filtros aceptan `year`, `entityCodes`, `sexes`, `ageGroups` y `sectionTypes`; rechazan campos desconocidos, listas vacías o duplicadas y valores fuera del dominio. El año es numérico y la entidad es una cadena de dos dígitos, de `'01'` a `'32'`. Hay OR dentro de una lista y AND entre dimensiones.

| Método | Regla temporal y resultado |
| --- | --- |
| `getParticipationSummary(filters?)` | Un año; suma conteos y luego calcula métricas. |
| `compareElections(filters, years)` | Entre dos y seis años únicos, ordenados por el servicio; no admite `filters.year`. Cada elección conserva su universo y se compara con el primer año. |
| `getParticipationBreakdown(filters, dimension)` | Un año, agrupado por `entity`, `year`, `sex`, `ageGroup` o `sectionType`. El desglose por `year` no convierte la llamada en una comparación multianual. |
| `getSupportingRecords(filters?)` | Los registros agregados que justifican el resultado, con sus fuentes y filas contribuyentes. No devuelve las filas crudas de los CSV. |

Si resumen, desglose o soporte omiten el año, seleccionan 2024 en este release y lo declaran en `filters.year`, con `DEFAULT_YEAR_SELECTED`. Para selectores de la UI, pasar el año explícitamente. No se suman elecciones distintas como si fueran una sola población. Las diferencias `*PercentagePoints` son puntos porcentuales; `participationRelativePercent` es cambio relativo en porcentaje y usa el porcentaje nominal existente.

Las respuestas conservan `status`, `filters`, `units`, `warnings` y `evidence`. `evidence.dataset.kind` es `'full'`; la huella del snapshot completo es `evidence.dataset.recordsSha256`, mientras que `evidence.recordsSha256` corresponde a la selección. `matchedSourceRows` cuenta filas contribuyentes de los CSV, no personas. Los totales de `evidence.sources` describen cada archivo de origen completo; los resultados filtrados están en `totals`.

## Indicadores oficiales y campos nominales existentes

El [manual oficial CCPC del INE, páginas 17–18](https://ine.mx/wp-content/uploads/2025/06/Manual-Conteos-Censales-2009-2024.pdf#page=17), define participación y abstención sobre los registros clasificados: SV + NV. El porcentaje de no especificados usa la lista nominal. El servicio mantiene esos indicadores y también los campos nominales anteriores:

| Campo | Fórmula y unidad |
| --- | --- |
| `ccpcParticipationPct` | `100 × SV / (SV + NV)`, porcentaje oficial CCPC. |
| `ccpcAbstentionPct` | `100 × NV / (SV + NV)`, porcentaje oficial CCPC. |
| `participationRate`, `abstentionRate` | `SV / LN`, `NV / LN`, razones nominales entre 0 y 1. |
| `participationPct`, `abstentionPct` | Las razones nominales anteriores multiplicadas por 100. |
| `unspecifiedRate`, `unspecifiedPct` | `NS / LN` y `100 × NS / LN`. |

Para presentar «participación CCPC» en la UI, usar `ccpcParticipationPct`. No renombrar ni reinterpretar `participationPct`: su denominador sigue siendo LN por compatibilidad. En el total nacional 2024, los conteos del release son LN 98,330,348; SV 54,899,228; NV 37,105,466; NS 6,325,654. Producen 59.670029444367266 % oficial y 55.83141839384113 % nominal. Su diferencia responde a los denominadores, no a un redondeo.

NS se mantiene separado de NV. Siempre se cumple LN = SV + NV + NS; primero se agregan los conteos y luego se calculan los porcentajes, sin promediar tasas de grupos. Si un denominador es cero, la métrica es `null`. Ausencia de registros produce `status: 'no_data'` y `totals: null`, o listas vacías según el método; no produce un porcentaje cero. Un grupo observado con LN cero es un caso distinto y conserva conteos cero con métricas nulas.

`no_binario` existe únicamente en 2024. Consultarlo en elecciones anteriores conserva la ausencia como `no_data` y emite `NON_BINARY_UNAVAILABLE`. Las comparaciones mantienen los avisos sobre categorías, marcos cartográficos y ausencia de panel; `sectionType` clasifica urbana/mixta/rural y no identifica una sección electoral. El alcance geográfico sigue siendo entidad.

## Formato compacto y comprobaciones

El objeto `ccpc-compact/v1` es estricto. Contiene `kind: 'full'`, `scope: 'entity'`, los seis años en orden, `metricDefinitions`, `dictionaries`, `sources`, `sourceEntityNames`, `columns`, `records` y `recordsSha256`. Los diccionarios deben coincidir exactamente, incluido su orden, con `SEXES`, `AGE_GROUPS` y `SECTION_TYPES` del dominio. Los 192 objetos `sources` conservan URL oficial, hashes de ZIP/CSV/diccionario, fecha de adquisición conocida o `null`, filas y totales de origen. `sourceEntityNames` tiene un nombre histórico por fuente, en el mismo orden.

Cada registro contiene nueve enteros, según este orden fijo de `columns`:

```text
[sourceIndex, sexIndex, ageGroupIndex, sectionTypeIndex,
 nominalList, voted, didNotVote, unspecified, sourceRows]
```

Los cuatro índices comienzan en cero. Año, clave de entidad y `sourceId` se obtienen de la fuente; el nombre, de `sourceEntityNames`. El loader calcula las métricas con las funciones existentes del dominio y reconstruye `ccpc-participation/v1`. Después, el esquema original comprueba combinaciones, orden, categorías, fórmulas y conservación por fuente. La publicación completa exige 20,755 grupos, 192 fuentes, las 32 entidades en cada uno de los seis años y 54,872,712 filas originales contribuyentes.

`src/data/ccpc-release.ts` contiene el pin SHA-256 del archivo entregado y la huella histórica de todos los registros canónicos DATA-02: `8d06184746e12b21a5166117e37787537a6643a659493f12d9c6efef3fd44e38`. El pin del archivo se valida antes de interpretar el JSON. La huella de registros calculada y la declarada deben coincidir con el ancla histórica. Alterar conteos y recalcular una huella dentro del paquete no actualiza esos pines externos.

Los pines comprueban coincidencia con el release en el que el equipo decidió confiar; no son una firma digital del INE ni acreditan por sí solos quién entregó el módulo. Distribuir código de pines y datos por un canal de release revisado. Una actualización debe revisar la nueva fuente y fijar su publicación explícitamente, sin desactivar comprobaciones para aceptar datos distintos. La validación detallada de DATA-02 contra DATA-01 sigue disponible para la preparación del release; no se repite al iniciar backend con este paquete.

La evidencia de las consultas mantiene `validation: 'runtime_schema'`: describe las comprobaciones del repositorio, sin cambiar los esquemas DATA-03. La comprobación de archivo de DATA-04 está en la frontera de carga. Los agregados conservan celdas pequeñas y el aviso `SMALL_CELLS`; una descarga completa no elimina esa condición de los datos originales.

## Muestra de desarrollo: ruta anterior explícita

La muestra original permanece en `data/ccpc/sample/data02/participation.json`. Contiene 150 grupos y no representa los totales estatales o nacionales. Su carga anterior usa `validateFile`, el repositorio y el servicio:

```javascript
import { fileURLToPath } from 'node:url';
import { validateFile } from './scripts/ccpc/validate-data.ts';
import { createParticipationRepository } from './src/repositories/participation.repository.ts';
import { createParticipationService } from './src/services/participation.service.ts';

const samplePath = fileURLToPath(new URL(
  './data/ccpc/sample/data02/participation.json', import.meta.url,
));
const sample = await validateFile(samplePath);
const sampleEngine = createParticipationService(createParticipationRepository(sample));
console.log(sampleEngine.getParticipationSummary({ year: 2024 }));
```

Esta selección es deliberada: las respuestas declaran `kind: 'sample'` y `SAMPLE_DATA`. El loader completo no acepta el formato de muestra ni una muestra etiquetada como completa. La carpeta de descarga original `Ine-hacktoon-Data` se conserva separada de esta entrega `Ine-hacktoon-DATA-04`.

## Pruebas

```sh
npm run typecheck
node --test tests/full-participation.test.ts
npm test
```

Las pruebas nuevas comprueban el archivo real publicado y la rehidratación completa, los dos denominadores con conteos nacionales 2024, las cuatro API y su evidencia, la ausencia histórica de `no_binario`, el rechazo de archivos corruptos o ausentes, muestras disfrazadas, cobertura incompleta, índices inválidos y conteos redistribuidos que conservan totales pero alteran la huella histórica. Las pruebas de DATA-01 a DATA-03 permanecen como regresión.
