# DATA-05 — Matriz de cobertura y catálogo compartido

DATA-05 describe exactamente qué puede responderse con el agregado **full** de DATA-04. No vuelve a ejecutar el ETL ni cambia los conteos, las fuentes o los indicadores de DATA-04. La disponibilidad se deriva de los registros existentes, no del producto cartesiano de etiquetas ni de ejemplos escritos a mano.

El archivo que comparten frontend y backend es [`data/ccpc/catalog/capabilities.json`](../data/ccpc/catalog/capabilities.json), con contrato `ccpc-capabilities/v1` y versión de catálogo `1.0.0`. Contiene dimensiones, matriz exacta, cuatro consultas soportadas, definiciones de indicadores, reglas de comparación, preguntas fuera de alcance y plantillas de onboarding. Identifica los hashes del archivo y los registros de DATA-04; [`src/data/capabilities-release.ts`](../src/data/capabilities-release.ts) fija el hash del catálogo distribuido.

## Cobertura disponible

Los seis años disponibles son **2009, 2012, 2015, 2018, 2021 y 2024**. Hay registros de las 32 entidades en cada año. La clave de entidad es una cadena de dos dígitos: se usa `"01"`, no el número `1`.

| Clave INE | Nombre en 2024 | Clave INE | Nombre en 2024 |
| --- | --- | --- | --- |
| 01 | AGUASCALIENTES | 17 | MORELOS |
| 02 | BAJA CALIFORNIA | 18 | NAYARIT |
| 03 | BAJA CALIFORNIA SUR | 19 | NUEVO LEON |
| 04 | CAMPECHE | 20 | OAXACA |
| 05 | COAHUILA | 21 | PUEBLA |
| 06 | COLIMA | 22 | QUERETARO |
| 07 | CHIAPAS | 23 | QUINTANA ROO |
| 08 | CHIHUAHUA | 24 | SAN LUIS POTOSI |
| 09 | CIUDAD DE MEXICO | 25 | SINALOA |
| 10 | DURANGO | 26 | SONORA |
| 11 | GUANAJUATO | 27 | TABASCO |
| 12 | GUERRERO | 28 | TAMAULIPAS |
| 13 | HIDALGO | 29 | TLAXCALA |
| 14 | JALISCO | 30 | VERACRUZ |
| 15 | MEXICO | 31 | YUCATAN |
| 16 | MICHOACAN | 32 | ZACATECAS |

Se conservan las etiquetas de las fuentes. `dimensions.entities[].namesByYear` guarda el nombre por año; la clave `09` incluye el nombre histórico `DISTRITO FEDERAL` en los cortes que lo documentan. Los cambios de nombre no crean otra entidad.

| Año | Categorías de sexo observadas | Celdas observadas | Celdas ausentes, universo global | Ausentes entre categorías de ese año |
| --- | --- | ---: | ---: | ---: |
| 2009 | `hombre`, `mujer` | 3,450 | 1,734 | 6 |
| 2012 | `hombre`, `mujer` | 3,449 | 1,735 | 7 |
| 2015 | `hombre`, `mujer` | 3,451 | 1,733 | 5 |
| 2018 | `hombre`, `mujer` | 3,450 | 1,734 | 6 |
| 2021 | `hombre`, `mujer` | 3,452 | 1,732 | 4 |
| 2024 | `hombre`, `mujer`, `no_binario` | 3,503 | 1,681 | 1,681 |

`no_binario` sólo está documentado en 2024 y su ausencia anterior no equivale a cero. Que una categoría exista en un año tampoco garantiza que exista en todas las entidades, edades y tipos de sección de ese año.

Los **18 grupos de edad** son: `18-19`, `20-24`, `25-29`, `30-34`, `35-39`, `40-44`, `45-49`, `50-54`, `55-59`, `60-64`, `65-69`, `70-74`, `75-79`, `80-84`, `85-89`, `90-94`, `95-99`, `100+`. El último grupo es abierto; no permite reconstruir edades exactas.

Los tres tipos de sección son **`urbana`, `mixta` y `rural`**. Son categorías del agregado; no son identificadores de una sección electoral concreta.

## Matriz exacta y archivos de consulta

La matriz tiene ejes en este orden: `year`, `entityCode`, `sex`, `ageGroup`, `sectionType`. Su forma es `[6, 32, 3, 18, 3]`: **31,104 celdas posibles**, de las cuales **20,755 están observadas** y **10,349 carecen de registros**. De las ausentes, 8,640 corresponden a `no_binario` antes de 2024 y 1,709 a cruces no observados entre categorías disponibles en su año.

`matrix.cells` es una cadena de estados de una posición por celda. La última dimensión cambia más rápido y cada eje sigue el orden de `dimensions`. El estado `0` significa ausencia de registros; `1`, registros existentes sin denominador oficial positivo; `2`, registros con denominador oficial positivo. El agregado de esta entrega no tiene celdas en estado `1`; el contrato contempla ese caso para impedir porcentajes inventados.

Se distribuyen también archivos legibles para revisión:

- [`matrix-by-year.csv`](../data/ccpc/catalog/matrix-by-year.csv): resumen anual con ambos universos de categorías.
- [`missing-combinations.csv`](../data/ccpc/catalog/missing-combinations.csv): las 10,349 combinaciones ausentes, con motivo `category_not_in_year` o `no_observed_records`.
- [`comparison-coverage.csv`](../data/ccpc/catalog/comparison-coverage.csv): cobertura de selecciones atómicas para los 15 pares de años; distingue presencia en ambos, ausencia en uno y ausencia en ambos.
- [`checksums.sha256`](../data/ccpc/catalog/checksums.sha256): hashes de los cuatro archivos anteriores, incluido el JSON.

Los CSV ayudan a inspeccionar la cobertura. Las decisiones de disponibilidad de la aplicación usan el JSON compartido y el evaluador común; no requieren mantener otro catálogo.

## Consultas respondibles y denominador

| Consulta | Qué responde | Parámetros específicos |
| --- | --- | --- |
| `getParticipationSummary` | Conteos y participación/abstención oficiales de la selección | `filters` |
| `compareElections` | Resúmenes por año y cambio descriptivo de participación | `years`: de dos a seis años únicos; sin `filters.year` |
| `getParticipationBreakdown` | Desglose de la selección | `dimension`: `entity`, `year`, `sex`, `ageGroup` o `sectionType` |
| `getSupportingRecords` | Registros agregados que respaldan la consulta | `filters` |

Los filtros son `year`, `entityCodes`, `sexes`, `ageGroups` y `sectionTypes`. Las listas de una dimensión se combinan con **OR**; las dimensiones, con **AND**. Si se omite un filtro se incluyen las categorías disponibles de esa dimensión. Si se omite el año en una consulta no comparativa se usa `defaultYear`, que en esta entrega es 2024. Las listas explícitas deben ser no vacías, sin duplicados y con valores canónicos del catálogo.

Los indicadores oficiales son `ccpcParticipationPct = 100 × SV / (SV + NV)` y `ccpcAbstentionPct = 100 × NV / (SV + NV)`. `NS` queda fuera de ese denominador. Los campos heredados calculados sobre lista nominal mantienen su significado y no deben presentarse como el indicador oficial CCPC. Las diferencias entre porcentajes se expresan en puntos porcentuales.

## Ausencia de datos, cero observado y agregados dispersos

La disponibilidad se evalúa antes de ejecutar la consulta. Una selección atómica inexistente devuelve `status: "no_data"` y `result: null`; no se rellena con conteos o porcentajes cero. Por ejemplo, la combinación `2024 / 01 / no_binario / 18-19 / rural` no tiene registros.

Un cero observado sí puede responderse: `2009 / 01 / hombre / 100+ / mixta` contiene `SV=0`, `NV=13`, `NS=1`; tiene denominador 13 y participación oficial de 0 %. No se confunde esa celda existente con una ausente.

En una selección agregada puede haber cruces vacíos y otros observados. El agregado suma únicamente los registros observados, informa `matchedCells` y `missingCells` y añade la advertencia `SPARSE_SELECTION`; los huecos nunca se imputan. Cada valor **explícitamente solicitado** debe aparecer al menos una vez en el resto de la selección, en cada año requerido. Si falta por completo una categoría solicitada, se devuelve `no_data` en lugar de eliminarla silenciosamente. Esto permite consultar, por ejemplo, un total estatal aunque falte un cruce de edad y sección, sin afirmar que ese cruce tiene cero personas.

Los registros sin denominador oficial positivo permiten consultar evidencia con `getSupportingRecords`; las preguntas de indicadores devuelven `no_data` cuando la selección de un año no tiene denominador positivo. El inicio del servicio falla si el agregado o el catálogo están corruptos o no corresponden a los hashes fijados: un fallo de integridad no se presenta como una ausencia de observaciones.

## Comparaciones inválidas y límites de interpretación

El evaluador rechaza con `no_data`, motivo y mensaje explícitos:

- Una comparación con menos de dos años, más de seis, años repetidos o años fuera del catálogo.
- `years` junto con `filters.year`, o `years` en una consulta que no sea comparativa.
- Un extremo sin registros o sin denominador oficial para los indicadores.
- Una categoría explícita ausente en cualquiera de los años; por ejemplo, `no_binario` entre 2021 y 2024.
- Códigos, categorías, dimensiones, filtros o consultas fuera del contrato, incluidas listas de filtros vacías o mal formadas.

La existencia de datos en ambos años permite una comparación **descriptiva** de cortes. No prueba que se observe a las mismas personas o secciones. El catálogo advierte `ELECTIONS_NOT_A_PANEL`, `CARTOGRAPHIC_FRAMES_MAY_DIFFER` y `SEX_CATEGORIES_MAY_DIFFER`. El consumidor debe mostrar estas advertencias y los años elegidos, no convertir diferencias en explicaciones causales o en trayectorias individuales.

Las preguntas fuera de alcance están en `outOfScope`, con un identificador y una razón de rechazo: resultados por partido o candidatura; municipio, distrito, casilla o sección específica; identidad o historial de una persona; edad exacta; años distintos de los seis disponibles; menores de 18 años y dimensiones como ingreso, escolaridad o etnia; causalidad o predicción; seguimiento longitudinal de las mismas personas o secciones; y categoría `no_binario` antes de 2024.

## Un mismo contrato para frontend, backend y onboarding

[`src/client/coverage-client.ts`](../src/client/coverage-client.ts) es un módulo puro, sin Node ni ETL. `createCatalogClient(json)` valida el catálogo, toma una copia inmutable y expone `getCatalog()`, `evaluate(request)` y `getOnboardingQuestions(context?, limit?)`. El backend usa exactamente ese mismo evaluador mediante [`src/data/coverage-participation.ts`](../src/data/coverage-participation.ts).

```ts
import { createCoverageParticipationService } from './src/data/coverage-participation.ts';

const ccpc = await createCoverageParticipationService();
const response = ccpc.execute({
  query: 'getParticipationSummary',
  filters: { year: 2024, entityCodes: ['01'], sexes: ['mujer'] },
});
// response.status: 'ok' o 'no_data'; response.result es null cuando no hay respuesta.
```

`execute(request)` devuelve `{ status, coverage, result, catalog }`. `coverage` incluye el motivo, mensaje, selección normalizada, número de celdas observadas y ausentes, cobertura por año y advertencias. `catalog` incluye `schemaVersion`, `catalogVersion`, `sha256` y `datasetRecordsSha256`, para identificar la versión que produjo la decisión. En `result` se conserva el resultado de la consulta existente de DATA-04 cuando puede responderse. `loadCapabilitiesCatalog()` permite cargar por separado el mismo catálogo verificado.

El frontend debe descargar el catálogo servido por el backend y crear su cliente con ese contenido:

```ts
import { createCatalogClient } from './coverage-client.js';

const response = await fetch('/api/capabilities');
if (!response.ok) throw new Error('No se pudo cargar el catálogo CCPC.');
const ccpc = createCatalogClient(await response.json());
const suggestions = ccpc.getOnboardingQuestions({ year: 2024, entityCodes: ['01'] });
// Cada sugerencia contiene { id, title, request }; enviar request al backend.
```

El onboarding parte de siete plantillas del catálogo y evalúa cada solicitud candidata antes de sugerirla. Propaga el contexto; no cambia de entidad, sexo o edad para obtener una respuesta. La comparación usa el corte anterior disponible y el año del contexto y se elimina si ese contexto no tiene cobertura en ambos. Un contexto inexistente o fuera de alcance devuelve una lista vacía. Por defecto se ofrecen como máximo seis preguntas; el límite puede ajustarse. El backend vuelve a evaluar la solicitud al ejecutarla, aunque haya sido sugerida por el frontend.

La demostración ejecutable de [`examples/data05`](../examples/data05) utiliza `GET /api/capabilities` y `POST /api/query`; se inicia con `npm run ccpc:demo`. Sirve para comprobar el recorrido navegador → catálogo → onboarding → consulta → resultado o `no_data`. Este paquete incluye adaptadores y una demostración funcional; no se proporcionó el repositorio real del frontend ni el backend de Bryan, por lo que su despliegue e integración finales se validan en esos repositorios al adoptar este contrato.

## Generación y verificación

[`scripts/ccpc/build-capabilities.ts`](../scripts/ccpc/build-capabilities.ts) lee el agregado full validado y genera el JSON, los tres CSV, los checksums, el hash fijado y el módulo JavaScript para navegador. No necesita descargar ni procesar los 54 millones de registros originales. Los archivos DATA-04 se conservan como fuente inmutable de esta etapa.

La verificación debe comprobar la matriz contra cada registro, enumerar ausencias y los 15 pares de comparación, ejecutar las cuatro consultas, revisar onboarding por contexto y probar rechazos sin cifras. El auditor independiente [`scripts/audit/data05/verify_coverage.py`](../scripts/audit/data05/verify_coverage.py) contrasta la cobertura contra el agregado compacto sin importar el evaluador TypeScript.

El estado de las comprobaciones y del checklist se registra en [`data05-checklist.md`](data05-checklist.md). La documentación distingue las propiedades comprobables del paquete de la adopción pendiente en los repositorios reales del equipo.
