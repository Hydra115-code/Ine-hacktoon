# DATA-05 — Checklist y criterios de aceptación

Objetivo: documentar exactamente qué preguntas pueden responderse con el agregado full de DATA-04, con una decisión de cobertura compartida por frontend y backend. El alcance y el contrato están en [`data05-coverage.md`](data05-coverage.md).

**Checklist: 9/9. Los tres criterios de aceptación se verificaron en el módulo y en la demostración de referencia incluidos.** Las evidencias enlazadas abajo permiten revisar cada comprobación.

## Checklist solicitado

- [x] **Enumerar años disponibles.** El catálogo enumera 2009, 2012, 2015, 2018, 2021 y 2024 en `dimensions.years`; el informe anual enumera cobertura por año.
- [x] **Enumerar entidades y claves INE.** `dimensions.entities` contiene las 32 claves de dos dígitos, su nombre de referencia y nombres históricos por año; la documentación incluye las 32.
- [x] **Registrar categorías de sexo por año.** `dimensions.sexesByYear` documenta `hombre` y `mujer` en los seis cortes y `no_binario` exclusivamente en 2024; no se inventa su presencia anterior.
- [x] **Registrar grupos de edad.** Se enumeran los 18 grupos desde `18-19` hasta `100+`, con el último intervalo abierto.
- [x] **Registrar tipos de sección.** Se enumeran `urbana`, `mixta` y `rural`, sin confundirlos con claves geográficas de sección.
- [x] **Identificar combinaciones sin registros.** Matriz exacta de 31,104 posiciones: 20,755 observadas y 10,349 ausentes; [`missing-combinations.csv`](../data/ccpc/catalog/missing-combinations.csv) enumera todas las ausencias y sus motivos.
- [x] **Identificar comparaciones inválidas.** El catálogo declara las reglas; [`comparison-coverage.csv`](../data/ccpc/catalog/comparison-coverage.csv) enumera los 15 pares de años y el evaluador rechaza selecciones sin datos en cualquiera de los extremos, categorías ausentes por año y solicitudes inválidas.
- [x] **Documentar preguntas fuera del alcance de CCPC.** `outOfScope` contiene preguntas y razones sobre resultados electorales por partido, geografía más fina, personas, edades exactas, otros años o variables, causalidad, predicción y panel longitudinal.
- [x] **Exportar catálogo de capacidades en JSON.** [`capabilities.json`](../data/ccpc/catalog/capabilities.json), contrato `ccpc-capabilities/v1`, versión `1.0.0`, referencia hashes de DATA-04 y acompaña archivos de revisión y checksums.

## Definition of Done

| Criterio | Implementación entregada | Verificación ejecutada |
| --- | --- | --- |
| Frontend y backend consumen el mismo catálogo | Un JSON distribuido, un evaluador compartido en `src/client/coverage-client.ts` y un adaptador backend en `src/data/coverage-participation.ts`; la demostración entrega ese JSON mediante `GET /api/capabilities` | Hash del catálogo idéntico en auditoría, verificador y navegador; paridad de decisiones en 31,104 selecciones y 77,760 comparaciones; integración Edge comprobada |
| El onboarding sólo sugiere preguntas respondibles | Cada plantilla candidata se convierte en una solicitud con el contexto actual y pasa por `evaluate`; sólo se ofrecen decisiones `ok` | 141,780 sugerencias validadas en 31,104 contextos; cero sugerencias para contextos ausentes; 1,312 ejecuciones backend sobre 192 contextos año/entidad |
| Una combinación inexistente produce `no_data`, no cifras inventadas | El adaptador verifica cobertura antes de consultar; el sobre contiene `status: "no_data"` y `result: null`; nunca se imputan huecos | Pruebas y navegador confirman resultado nulo para ausencia y comparación incompleta; 0% observado conserva status ok. Fixture independiente prueba denominador cero y entradas inválidas |

La adopción y el despliegue dentro de los repositorios reales de frontend y de Bryan no están ejecutados aquí: no se proporcionaron esos repositorios. Lo entregado permite integrar ambos sin modificar el ETL de DATA-04 y comprobar el contrato en la demostración incluida.

## Casos de aceptación verificados

1. Las seis anualidades y las 32 entidades coinciden con los 20,755 registros full; no se usa la muestra para inferir cobertura.
2. Las cuatro consultas operan sobre el agregado con filtros soportados y exponen la versión del catálogo usado.
3. `2024 / 01 / no_binario / 18-19 / rural` devuelve `no_data` y resultado nulo; no una participación de 0 %.
4. Comparar `no_binario` entre 2021 y 2024 devuelve `no_data` aunque la categoría tenga registros en el último año.
5. `2009 / 01 / hombre / 100+ / mixta` conserva el cero observado de participación con `SV=0`, `NV=13`, `NS=1` y denominador oficial 13.
6. Las selecciones agregadas dispersas suman sólo celdas observadas, informan huecos y advertencias y no omiten categorías explícitas sin datos.
7. Un contexto inválido o ausente genera cero sugerencias; cada sugerencia emitida puede ejecutarse con su solicitud exacta.
8. El auditor independiente coincide con la matriz, los CSV, la cobertura por año y las comparaciones sin utilizar el evaluador TypeScript.
9. Una regeneración del catálogo conserva los archivos esperados y sus hashes; los datos full y sample de DATA-04 permanecen intactos.

## Estado de verificación

- **142 pruebas aprobadas; 0 fallos, 0 omitidas**, junto con TypeScript y regresiones DATA-04: [`checks.json`](data05-evidence/checks.json) y [`checks.log`](data05-evidence/checks.log). Runtime: Node.js 26.7.0 y Python 3.14.7.
- **31,104 selecciones** contrastadas con el agregado: 20,755 disponibles y 10,349 ausentes. **77,760 comparaciones atómicas**: 51,749 válidas y 26,011 inválidas. Paridad del evaluador TypeScript con su distribución JavaScript para navegador: [`verification.json`](data05-evidence/verification.json).
- **Onboarding:** 141,780 sugerencias validadas, cero contextos ausentes con sugerencias; 1,312 consultas reales de las cuatro funciones sobre 192 contextos año/entidad, en la misma evidencia.
- **Auditoría independiente Python**, sin importar el generador ni el evaluador TypeScript: reconstrucción exacta de matriz, dimensiones y tres CSV: [`independent-coverage-audit.json`](data05-evidence/independent-coverage-audit.json).
- **Navegador Edge:** selección ausente sin sugerencias ni métricas anteriores, cero observado, comparación inválida y sugerencia ejecutada correctamente: [`browser-verification.json`](data05-evidence/browser-verification.json). Capturas: [ausencia](data05-evidence/browser-no-data.jpg), [cero observado](data05-evidence/browser-observed-zero.jpg), [comparación inválida](data05-evidence/browser-invalid-comparison.jpg), [onboarding](data05-evidence/browser-onboarding.jpg).
- **Instalación limpia del ZIP extraído:** ocho dependencias instaladas desde caché con `npm ci --offline`; verificación completa y 142 pruebas aprobadas. Archivos de ejecución finales idénticos a los comprobados: [`clean-validation.json`](data05-evidence/clean-validation.json).
- **Reproducción determinista:** siete archivos regenerados idénticos byte por byte: [`reproduction.json`](data05-evidence/reproduction.json).
- **115 archivos originales DATA-04 intactos**, incluidos datos, muestras, ETL, consultas y pruebas: [`data04-preservation.json`](data05-evidence/data04-preservation.json). Sólo cambian README, metadatos npm e inventario raíz; DATA-05 se agrega en archivos nuevos.

El catálogo versión 1.0.0 fija la fecha de publicación `2026-10-23T01:27:34Z`, correspondiente al **22 de octubre de 2026 en America/Monterrey**. Su SHA-256 se fija en `src/data/capabilities-release.ts` y se registra en los informes. La evidencia histórica DATA-04 permanece identificada como tal.
