# Reproducir DATA-04

## Consultar y verificar sin fuentes pesadas

El ZIP de entrega incluye el agregado completo. Para backend basta Node/npm; para la auditoría independiente se añade Python 3, sin paquetes Python externos.

```sh
npm ci --ignore-scripts
npm run ccpc:check
npm run ccpc:verify-delivery
```

No descargar fuentes ni ejecutar ETL para servir consultas. La entrada principal es `data/ccpc/full/participation.compact.json`, identificada como `full` y fijada mediante SHA-256 en `src/data/ccpc-release.ts`. La muestra anterior sigue en `data/ccpc/sample/`; para generar sus ejemplos se usa explícitamente `npm run ccpc:queries:sample`.

## Reconstruir desde las seis fuentes oficiales

Los seis ZIP del catálogo suman 292,480,437 bytes en esta publicación. Su adquisición necesita conexión al INE y espacio local para los ZIP. El recorrido valida 54,872,712 filas, por lo que tarda varios minutos y utiliza CPU. Los originales se mantienen fuera de Git y del ZIP final.

```sh
npm ci --ignore-scripts
npm run ccpc:download -- --year all
npm run ccpc:full:rebuild
```

El nuevo orquestador `scripts/ccpc/rebuild-full-data.ts` hace **una sola lectura** de cada ZIP llamando a las funciones originales `inspectArchive`, `sortRows`, `toCsv`, `compareEntityNames`, `normalizeInspectedArchives`, `publishDataset` y `validateFile`. Los archivos anteriores del ETL no se editan. El JSON DATA-02 y el CSV DATA-01 quedan en `data/ccpc/processed/`, que no se distribuye.

Se comparan el CSV completo y los conteos/grupos con las anclas anteriores fijadas, además de validar catálogos, hashes de ZIP/CSV/diccionarios, fórmulas y sourceRows. Un archivo oficial distinto falla; cambiar anclas no es una operación de regeneración rutinaria.

Si los ZIP están en otro directorio:

```sh
npm run ccpc:full:rebuild -- --raw-dir /ruta/a/los/seis/zip
```

Los nombres deben coincidir con `data/ccpc/sources.json`. La adquisición conocida se conserva aparte en `processed/acquisition.json`. Para reproducir la publicación auditada, el orquestador conserva los campos históricos `downloadedAt` del contrato DATA-02 como `null`; esto no borra ni inventa las nuevas fechas de adquisición, que se declaran por separado en el manifiesto DATA-04. No se usa el mtime de un ZIP local como prueba de su fecha histórica de descarga.

La vía anterior también sigue disponible, con dos recorridos de las fuentes:

```sh
npm run ccpc:inspect -- --year all --sample
npm run ccpc:pipeline
```

Esta ruta regenera la procedencia del fixture y actualiza sus metadatos de inspección/adquisición. No es necesaria para consumir ni verificar el paquete DATA-04.

## Empaquetar el agregado validado

Elegir una fecha UTC real y explícita para la publicación; sustituir `ISO_UTC_DEL_RELEASE` por un valor como `2026-10-22T01:00:00.000Z` que corresponda a esa ejecución.

```sh
npm run ccpc:full:build -- --released-at ISO_UTC_DEL_RELEASE --acquisition data/ccpc/processed/acquisition.json --update-release-pin
npm run ccpc:check
```

`--update-release-pin` es una operación explícita de publicación después de validar las fuentes. Actualiza el pin del archivo compacto; el hash inmutable de los registros históricos completos no se recalcula para aceptar datos diferentes. Para un paquete alterno puede usarse `--output /ruta/a/otro/directorio`; sin `--update-release-pin` no cambia el cargador de la entrega actual.

El empaquetador comprueba el roundtrip exacto al contrato `ccpc-participation/v1`, escribe el JSON compacto, el manifiesto y sus checksums. La fecha del release y las fechas de adquisición son **metadatos de entrada**: los mismos ZIP y metadatos, con el mismo runtime de referencia, producen los mismos bytes. Una adquisición realizada después conserva los mismos conteos y hash de registros si los ZIP son idénticos, pero cambia las fechas y el hash del manifiesto. La entrega incluye evidencia de dos empaquetados con entradas y metadatos idénticos.

## Qué incluir al compartir la rama de Datos

Compartir código, lockfile, catálogo y anclas, `data/ccpc/full/`, la muestra identificada, documentación y evidencia. Excluir:

- `data/ccpc/raw/` y `data/ccpc/processed/`.
- Los seis ZIP INE y los CSV originales.
- `node_modules/`, cachés, archivos temporales y enlaces a rutas locales.

`data/ccpc/full/` se encuentra fuera de las rutas ignoradas y queda versionado normalmente. No crear ZIP mediante una copia indiscriminada de toda la carpeta de desarrollo. El inventario `DELIVERY-MANIFEST.json` debe regenerarse al publicar cambios; no es una firma digital del INE y no autentica archivos añadidos después.

Para generar un ZIP de distribución e inventario de todos sus archivos:

```sh
npm run ccpc:package -- --output /ruta/de/salida/Ine-hacktoon-DATA-04.zip --update-manifest
npm run ccpc:verify-delivery
```

El script excluye expresamente las fuentes pesadas, dependencias y temporales; fija metadatos de archivo del ZIP para que su compresión sea reproducible. Escribe un `.zip.sha256` externo. Usar `--update-manifest` únicamente al publicar cambios ya revisados. Los documentos de aceptación internos identifican los datos y comprobaciones, mientras que el hash del archivo de distribución queda fuera del ZIP para evitar dependencias circulares.
