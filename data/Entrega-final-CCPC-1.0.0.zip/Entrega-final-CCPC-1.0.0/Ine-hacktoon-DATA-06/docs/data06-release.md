# DATA-06 — Dataset final 1.0.0

La versión final es **1.0.0**, identificada por `data/ccpc/releases/1.0.0/release.json`. El dato full y el catálogo de capacidades conservan exactamente sus bytes DATA-04/05. La nueva versión agrega un manifiesto de release, un diccionario actualizado, metadatos para el frontend y un bloqueo verificable de contratos.

## Identidad y congelación

- Versión de datos: `1.0.0`; estado: `frozen`.
- SHA-256 del manifiesto de release: `5992059695eac4920cf959b1589114d4327e149f237c467c7574d75c4d51d2e4`.
- SHA-256 del compacto full: `d7e546928465d25702fe1b625eafb91c8435f7c5ddedd1c30a5278f89c29489c`.
- SHA-256 del catálogo: `5dd6c03fdcad5466cf069a82d1bb86c1c7ebd0d14e56a8d9ba8777c0db995f9b`.
- Fecha fijada de publicación: `2026-10-23T01:44:23Z`, correspondiente al **22 de octubre de 2026 en America/Monterrey**.
- Límite solicitado: **26 de octubre de 2026**, en America/Monterrey. La versión 1.0.0 queda congelada desde esta entrega, antes de ese límite. Sus bytes y contratos no se actualizan, tampoco antes del límite. Un cambio requiere otra versión y otro pin.

El paquete npm actual también se etiqueta como 1.0.0, pero esa etiqueta es independiente de los metadatos históricos: `full/manifest.json` conserva su `packageVersion` DATA-04 original, y el catálogo sigue con su propia versión 1.0.0. Esas fechas y versiones no se reescriben para aparentar una extracción nueva.

`schema-lock.json` fija los hashes de 14 archivos que definen dominios, esquema normalizado, formato compacto, catálogo, puertos de consulta, adaptadores y regeneración. Registra ocho identificadores de contrato: participación, compacto, capacidades, release, metadatos frontend, diccionario, bloqueo y respuesta de consulta. El manifiesto fija además 13 artefactos de datos y metadatos.

El bloqueo es independiente de la fecha del reloj: una alteración falla hoy y también después del 26. Es un control de integridad y una política de versionado; no impide que alguien edite un archivo en su disco. El backend rechaza esa copia alterada en lugar de servirla como 1.0.0. El pin externo debe permanecer en el código revisado; no es una firma del INE.

## Fechas de origen y extracción

La extracción DATA-04 se documenta con precisión de **día UTC: 2026-10-22**. Las seis adquisiciones registradas están entre `00:41:29.448Z` y `00:43:29.736Z`; el primer paquete agregado quedó registrado a `00:59:19Z`. La hora exacta de extracción de cada fila no fue registrada y permanece `null`. No se usa el mtime de archivos ni la fecha de este release como sustituto de esas evidencias.

El manifiesto y `frontend-metadata.json` incluyen la página oficial del INE, el manual metodológico y, para cada año, URL del ZIP, SHA-256 y fecha real de adquisición. Son las mismas fuentes auditadas en DATA-04: 54,872,712 filas de origen, 192 CSV, seis años y 32 entidades. Los originales no se distribuyen.

## Arranque del backend

```ts
import { createFrozenParticipationService } from './src/data/dataset-v1.ts';

// Esperar este arranque antes de escuchar peticiones o anunciar disponibilidad.
const ccpc = await createFrozenParticipationService();
const result = ccpc.execute({
  query: 'getParticipationSummary',
  filters: { year: 2024, entityCodes: ['19'] },
});
console.log(result.release.datasetVersion); // 1.0.0
```

El arranque verifica, en orden:

1. El hash de `release.json` contra el pin externo `src/data/dataset-v1-release.ts`.
2. Rutas, tamaños y SHA-256 de los 13 artefactos; rechaza archivos ausentes y enlaces simbólicos.
3. Los 14 archivos del bloqueo de contratos, versiones y reglas de congelación.
4. Las referencias a metadatos, diccionario y checksums exactos del release.
5. La carga normalizada full y el catálogo fijados DATA-04/05 antes de crear el servicio de consultas.

La demostración ejecuta este proceso **antes de `listen`**. Un fallo de integridad detiene el inicio; no se convierte en `no_data` ni activa una muestra de respaldo. Las consultas utilizan un snapshot en memoria. Los manifiestos, diccionario y metadatos expuestos por el servicio están congelados y no se vuelven a leer de un archivo mutable al servir cada petición.

Se mantienen las cuatro consultas y las guardas DATA-05. La respuesta nueva declara `schemaVersion: "ccpc-query-response/v1"` y agrega `release`, con versión y hash del release. No se modifica el contrato histórico DATA-04/05: los nuevos consumidores utilizan el punto de entrada congelado. Una combinación ausente devuelve `no_data`, `result: null`; un 0% observado sigue siendo válido.

## Lo que recibe el frontend

```sh
npm run ccpc:demo
```

La demostración está en `http://127.0.0.1:4186` y usa estos endpoints:

| Ruta | Contenido |
| --- | --- |
| `GET /api/dataset` | Snapshot verificado de `frontend-metadata.json`: fuente, metodología, advertencias, cobertura, extracción y versión. |
| `GET /api/release` | Manifiesto 1.0.0 verificado. |
| `GET /api/capabilities` | Catálogo compartido DATA-05. |
| `POST /api/query` | Consulta validada y versión/hash de los datos utilizados. |

El frontend de referencia muestra la versión, los enlaces al INE y al manual, las fechas, las fórmulas y las advertencias recibidas del backend. Sus sugerencias siguen utilizando el evaluador compartido DATA-05. El proyecto externo del equipo debe conectar estos endpoints o importar el adaptador; no se proporcionó su repositorio para ejecutar ese despliegue.

Las advertencias cubren el denominador oficial y NS, ausencia frente a cero, categoría no binaria sólo en 2024, cobertura dispersa, comparaciones descriptivas, cartografía diferente, alcance geográfico y temático, celdas pequeñas y precisión de las fechas.

## Diccionario y limitaciones

El diccionario vigente está en [`dictionary.json`](../data/ccpc/releases/1.0.0/dictionary.json), explicado en [`data06-dictionary.md`](data06-dictionary.md). Enumera las nueve columnas compactas, los 21 campos normalizados, dimensiones, unidades, fórmulas, fuentes y reglas de consulta. El diccionario DATA-01 anterior se conserva como documento histórico.

Participación oficial: `100 × SV / (SV + NV)`; abstención oficial: `100 × NV / (SV + NV)`. NS permanece separado. Los campos heredados sobre LN conservan su denominador y no deben usarse para presentar el indicador oficial. Se suman conteos antes de dividir. La selección sin registros no se completa con ceros.

La matriz tiene 31,104 cruces posibles, 20,755 observados y 10,349 ausentes. `no_binario` sólo está documentado en 2024. El agregado no identifica personas, municipios, distritos ni secciones específicas; no permite recuperar edad exacta, partido, candidatura, causas o predicciones. Las comparaciones no constituyen un panel de las mismas personas o secciones.

La auditoría de esquema y valores confirma **ausencia de identificadores personales directos en los archivos de datos entregados**. Persisten 54 celdas full con LN=1 y 124 con LN entre 1 y 4; esa confirmación no equivale a certificar anonimato absoluto. Véase [`data06-privacy.md`](data06-privacy.md) y su evidencia.

## Regeneración reproducible del release

```sh
npm ci --ignore-scripts
npm run ccpc:release:regenerate -- --output /ruta/de/staging-vacio
```

Este comando valida primero la publicación existente, reconstruye en un directorio externo vacío los cinco archivos del release y compara cada byte y el hash final. Usa el agregado y el catálogo auditados como entradas fijadas. No cambia los pins, las fechas, los datos ni los esquemas publicados. Rechaza un staging dentro del paquete y no sobreescribe un staging con archivos existentes.

`build-dataset-v1.ts --initialize` es el constructor de la primera publicación: se conserva para trazabilidad y rechaza su ejecución si ya existe manifiesto o pin 1.0.0. El helper interno `buildDatasetV1` no es una interfaz de publicación para consumidores. Los comandos históricos que actualizan pins DATA-04 no forman parte del flujo de regeneración 1.0.0.

Para reconstruir los **conteos desde los ZIP originales**, se conserva el ETL DATA-04 y su documentación [`data04-reproduction.md`](data04-reproduction.md): descargar o aportar los seis ZIP anclados y ejecutar `ccpc:full:rebuild` hacia un staging externo. El resultado normalizado puede volver a compactarse mediante `encodeCompactDataset` de `build-full-package.ts`; su compacto debe coincidir con el SHA fijado. Los metadatos históricos de adquisición, versión y empaquetado son entradas versionadas del release y se conservan exactamente. Una nueva descarga tiene su propia fecha y no debe reescribir retrospectivamente esas entradas. DATA-05 documenta la regeneración del catálogo. La regeneración DATA-06 no afirma releer los 54 millones de registros: ese recorrido ya se verificó en la etapa DATA-04.

## Validación y distribución

```sh
npm run ccpc:check
npm run ccpc:release:verify
npm run ccpc:release:audit
npm run ccpc:privacy:audit
npm run ccpc:verify-delivery
```

Se conservan informes de validación, auditoría independiente, casos negativos, privacidad, reproducción y navegador en `docs/data06-evidence/`. Los resultados históricos DATA-04/05 permanecen identificados con su etapa; el checklist DATA-06 enlaza las ejecuciones actuales.

El ZIP final se genera mediante `scripts/package-data06.py` con inventario y `.zip.sha256` externo. Excluye originales, ZIP INE, dependencias, cachés y enlaces. El checksum del ZIP permanece fuera para evitar una dependencia circular; el release tiene su propio pin y checksums internos. Esta entrega publica el artefacto local versionado; no crea una etiqueta Git ni un release remoto de GitHub.
