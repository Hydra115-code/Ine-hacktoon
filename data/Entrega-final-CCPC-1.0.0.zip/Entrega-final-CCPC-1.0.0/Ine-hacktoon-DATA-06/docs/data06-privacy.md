# DATA-06: revisión de identificadores personales directos

La publicación de datos **1.0.0 no contiene identificadores personales directos en sus registros agregados**. La revisión independiente utiliza sólo la biblioteca estándar de Python, sin importar el ETL ni el cargador TypeScript. El resultado y las huellas de los archivos revisados se guardan en [privacy-audit.json](data06-evidence/privacy-audit.json).

La afirmación es sobre los campos y valores entregados. **No constituye una garantía de anonimato absoluto**: se conservan celdas pequeñas de los agregados oficiales y no se aplicó supresión estadística.

## Qué se revisa

- El conjunto `full` contiene 20,755 tuplas de exactamente nueve enteros. Sólo admite índices de fuente y categorías, LN, SV, NV, NS y número de filas originales agregadas. Se rechazan campos adicionales, índices fuera de dominio y valores no numéricos.
- La muestra normalizada conserva exactamente los 21 campos del contrato existente. Sólo admite las seis elecciones, claves de entidad 01–32, categorías publicadas de sexo, 18 bandas de edad y tres tipos de sección. Sus nombres se comparan contra una lista cerrada de entidades; no son nombres de personas.
- Los identificadores de fuente tienen la forma `año:entidad`, por ejemplo `2024:01`. Identifican un CSV agregado, no un ciudadano. Se comprueban también los campos de procedencia y sus conteos.
- El CSV de muestra utiliza una lista cerrada de 15 columnas y conteos o porcentajes numéricos. Los tres CSV de cobertura sólo admiten sus columnas publicadas, categorías y números.
- El catálogo compartido y sus nombres geográficos se validan mediante listas de campos y dominios permitidos. El diccionario y los nuevos metadatos de frontend, manifiesto y bloqueo de esquema también tienen comprobaciones de estructura.
- Se inspeccionan recursivamente las claves y cadenas de los JSON de datos y procedencia para detectar campos de identificación directa y patrones de correo, CURP o teléfono. Se rechazan archivos adicionales no revisados y enlaces simbólicos dentro de `data/ccpc`.

Los registros no contienen nombres personales, apellidos, CURP, RFC, clave de elector, número de credencial, correos, teléfonos, domicilios, fecha de nacimiento ni identificadores individuales. Tampoco incluyen número de sección, municipio, distrito o casilla: la geografía entregada se limita a entidad y **tipo** de sección. La edad se entrega por bandas.

Las descripciones de metodología, advertencias y preguntas del catálogo son texto editorial revisado, no registros de personas. Los documentos y el código fuente quedan fuera del escaneo de valores: pueden explicar palabras como “CURP” sin contener un identificador real. Los hashes SHA-256 se registran para relacionar la revisión con los archivos concretos; la verificación de integridad de la publicación corresponde además al cargador y auditor de versión.

## Celdas pequeñas que permanecen publicadas

| Artefacto | Registros agregados | LN mínimo | Celdas con LN = 1 | Celdas con LN entre 1 y 4 |
|---|---:|---:|---:|---:|
| Full | 20,755 | 1 | 54 | 124 |
| Muestra normalizada | 150 | 1 | 4 | 9 |
| CSV de muestra | 150 | 1 | 4 | 9 |

La muestra normalizada y su CSV representan los mismos 150 grupos y no se suman entre sí ni al conjunto `full`. `sourceRows` cuenta filas de origen, no personas. La presencia de una celda con LN = 1 impide afirmar que sea imposible inferir información sobre una persona usando datos externos. El frontend recibe `smallCellsPresent: true` y `anonymityGuarantee: false` junto con la advertencia `SMALL_CELLS`.

## Cómo repetir la revisión

Desde la raíz del proyecto:

```sh
python3 scripts/audit/data06/audit_privacy.py
```

El comando imprime el informe JSON y termina con código `0` si pasa o `1` si falla. No escribe archivos por defecto. Puede ejecutarse desde otra ubicación con `--root /ruta/al/proyecto` y guardar un informe mediante:

```sh
python3 scripts/audit/data06/audit_privacy.py \
  --output docs/data06-evidence/privacy-audit.json
```

La revisión no altera los archivos de datos. Durante DATA-06 se probaron además **26 alteraciones negativas sobre copias de trabajo**, todas rechazadas: campos desconocidos en tuplas, registros, fuentes, catálogo y metadatos; inyección de identificadores; nombres no geográficos; categorías adicionales; encabezado CSV ajeno; archivo adicional y una afirmación de anonimato absoluto. Tras restaurar las copias, ambas baterías volvieron a pasar. Los archivos de producción conservaron sus huellas.

Esta validación se limita a la versión entregada y no certifica el contenido de servicios externos, datos que el equipo añada después o los 54 millones de registros originales, que no se distribuyen en el paquete.
