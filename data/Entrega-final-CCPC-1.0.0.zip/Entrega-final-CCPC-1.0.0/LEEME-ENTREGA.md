# Qué entregar al equipo

Entrega **`Entrega-final-CCPC-1.0.0.zip` y `Entrega-final-CCPC-1.0.0.zip.sha256`**. Este único paquete incorpora DATA-04, DATA-05 y DATA-06, los datos completos, el código, las auditorías y la integración de referencia.

**Resultado de auditoría:** aprobado para la entrega del módulo de Datos. Los 26 puntos de checklist están implementados; las 149 pruebas pasan. Las condiciones y dos observaciones históricas no bloqueantes están en [AUDITORIA-FINAL.md](AUDITORIA-FINAL.md).

## Comprobar y arrancar

Junto al ZIP recibido:

```sh
sha256sum -c Entrega-final-CCPC-1.0.0.zip.sha256
unzip Entrega-final-CCPC-1.0.0.zip
cd Entrega-final-CCPC-1.0.0/Ine-hacktoon-DATA-06
npm ci --ignore-scripts
npm run ccpc:verify-delivery
npm run ccpc:check
npm run ccpc:demo
```

Abre **http://127.0.0.1:4186** y deja esa terminal abierta. Requisitos: Node.js/npm y Python ≥3.10 para las auditorías. Esta auditoría usó Node.js 26.7.0 y Python 3.14.7. La instalación necesita npm o su caché; las consultas posteriores son locales.

## Qué debe conectar cada parte

| Responsable | Acción necesaria |
| --- | --- |
| Backend/Bryan | Incorporar completa la carpeta `Ine-hacktoon-DATA-06/`, instalar sus dependencias y esperar `createFrozenParticipationService()` de `src/data/dataset-v1.ts` **antes de abrir el servidor**. Mapear las cuatro consultas y servir catálogo y metadatos. |
| Frontend | Consumir el catálogo de `GET /api/capabilities`, los metadatos de `GET /api/dataset` y las consultas de `POST /api/query`. Usar el cliente compartido para onboarding. |
| Indicadores | Mostrar `ccpcParticipationPct` y `ccpcAbstentionPct` (SV+NV). Conservar `no_data` como ausencia, separado de un 0% observado. |
| Integración | Mantener los archivos y sus finales de línea, incluida `.gitattributes`; no formatear ni actualizar pins del módulo 1.0.0. |

La guía [INTEGRACION.md](INTEGRACION.md) contiene imports, endpoints, ejemplos de las cuatro consultas y una prueba HTTP repetible.

La demostración ya conecta frontend y backend incluidos. **La conexión con las aplicaciones reales del equipo debe hacerse en esos repositorios**; no fueron proporcionados para esta auditoría. El paquete se entrega como 1.0.0, con revisión documental preparada para la rama `Data` de GitHub.

## Contenido

- `Ine-hacktoon-DATA-06/`: proyecto completo de 190 archivos, con datos y contratos congelados; esta revisión actualiza README e inventario. Incluye las etapas anteriores.
- `INTEGRACION.md`: instrucciones para el equipo.
- `AUDITORIA-FINAL.md` y `.json`: veredicto, requisitos y límites de comprobación.
- `evidencias/`: nueva instalación y ejecución limpia, revisión independiente y prueba HTTP.
- `MANIFEST-ENTREGA.json`: inventario adicional de este paquete consolidado.

Los originales del INE y `node_modules` se excluyen de la entrega. Los scripts de reproducción permanecen incluidos. La auditoría no detectó identificadores personales directos; las celdas pequeñas y sus límites están documentados.
