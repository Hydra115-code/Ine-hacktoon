# Entrega e integración CCPC 1.0.0 — DATA-04, DATA-05 y DATA-06

Entrega al equipo **el ZIP final consolidado completo y su archivo `.sha256` externo**. Dentro conserva la carpeta `Ine-hacktoon-DATA-06/` íntegra y los documentos de entrega y auditoría. DATA-06 ya incorpora DATA-04 y DATA-05: no hay que instalar los tres ZIP por separado ni combinar versiones.

El módulo entregado funciona como referencia ejecutable de datos y consultas. La auditoría verifica ese módulo y su servidor local; no acredita una conexión ni un despliegue dentro de aplicaciones externas del equipo que no se proporcionaron. No se creó una etiqueta Git ni un release remoto: se entrega el artefacto local congelado.

## 1. Comprobar y ejecutar la entrega

En la carpeta donde recibas el ZIP y el checksum, ejecuta `sha256sum -c NOMBRE-EXACTO-DEL-ZIP.zip.sha256`, sustituyendo el nombre por el archivo recibido. Sólo continúa si dice `OK`. Extrae el ZIP final y, desde su raíz `Entrega-final-CCPC-1.0.0/`, ejecuta:

```sh
cd Ine-hacktoon-DATA-06
node --version
python3 --version
npm ci --ignore-scripts
npm run ccpc:check
npm run ccpc:verify-delivery
npm run ccpc:demo
```

Abre `http://127.0.0.1:4186`. El servidor sólo escucha en la interfaz local; la terminal debe continuar abierta. Detén la demostración con Ctrl+C. Para cambiar de puerto en Linux/macOS: `CCPC_RELEASE_PORT=4187 npm run ccpc:demo`.

Requisitos: Node.js y npm; `package.json` declara `^22.18.0 || >=23.6.0`. La integración de esta auditoría se ejecutó con **Node.js 26.7.0**. Python **≥3.10** se usa en las auditorías; esta ejecución usó 3.14.7. No se han ensayado aquí todas las versiones admitidas por el rango declarado. TypeScript se ejecuta mediante el soporte nativo de Node, con imports `.ts` y ESM; `npm run typecheck` comprueba tipos por separado.

`npm ci` necesita acceso a npm o una caché que ya contenga las dependencias. Después de instalar, las consultas, la demostración y las verificaciones de la entrega no necesitan red ni credenciales. No requieren los ZIP originales del INE ni ejecutar el ETL.

## 2. Qué incorporar en el backend

La opción verificada es colocar **toda la carpeta** `Ine-hacktoon-DATA-06/` como módulo independiente dentro o junto al backend, preservando las rutas y bytes interiores. Instala sus dependencias desde esa carpeta. No copies sólo el JSON ni sólo el servicio y no sobrescribas el `package.json` del backend con el del módulo.

Conserva también `.gitattributes` y los archivos ocultos incluidos. Excluye este módulo congelado de Prettier, formateadores automáticos y conversiones de fin de línea: un cambio de formato de un contrato bloqueado cambia su hash y detiene el arranque aunque no cambie su lógica. La auditoría y la guía externas no requieren modificar ningún archivo de la publicación.

El punto de entrada final es **`src/data/dataset-v1.ts`**. No uses los cargadores históricos de muestra ni el adaptador sin bloqueo para la entrega congelada. Si un archivo ESM del backend está junto a la carpeta del módulo, el arranque es:

```js
import { createFrozenParticipationService }
  from './Ine-hacktoon-DATA-06/src/data/dataset-v1.ts';

// Inicializar una vez y esperar el resultado ANTES de listen/readiness.
const ccpc = await createFrozenParticipationService();

const envelope = ccpc.execute({
  query: 'getParticipationSummary',
  filters: { year: 2024, entityCodes: ['19'] },
});
console.log(envelope.status, envelope.release.datasetVersion);
// Registrar las rutas del servidor existente y sólo después abrir su puerto.
```

La ruta relativa del import se ajusta a la ubicación del archivo **del backend**; los archivos internos del módulo permanecen iguales. Node resuelve las dependencias desde el módulo y localiza su raíz a partir de `import.meta.url`, no del directorio desde el que lanzas el proceso. Para un almacenamiento alternativo íntegro existe `createFrozenParticipationService({ root: '/ruta/absoluta/al/modulo' })`.

El arranque verifica el SHA-256 de `release.json` contra el pin del código revisado, 13 artefactos y 14 archivos de contratos y regeneración. Debe fallar el inicio si hay corrupción: no captures ese fallo para devolver `no_data`, servir la muestra o abrir el puerto como si todo estuviera disponible. El servicio conserva un snapshot en memoria. Cambiar archivos después del arranque no actualiza ese snapshot; la nueva carga debe volver a verificarse.

El pin es un control de integridad dentro del código confiable de la entrega, no una firma del INE. Conserva el checksum externo recibido y los archivos de pins revisados; recalcularlos para aceptar cambios elimina la garantía de esta versión.

## 3. Rutas y cuatro consultas

El servidor ejecutable está en `scripts/ccpc/serve-dataset-v1.ts`. Es la integración HTTP de referencia; puedes usarlo localmente o trasladar su mapeo de rutas al servidor existente. No se entregó un contrato Swagger/OpenAPI del backend externo. No deben inventarse rutas o capas de autenticación que supuestamente ya existan.

| Ruta de referencia | Fuente del servicio | Uso |
| --- | --- | --- |
| `GET /api/capabilities` | `ccpc.getCatalog()` | Mismo catálogo para frontend, onboarding y backend. |
| `GET /api/dataset` | `ccpc.getDatasetMetadata()` | Fuente, metodología, fechas, advertencias y cobertura. |
| `GET /api/release` | `ccpc.getRelease()` | Manifiesto congelado 1.0.0. |
| `POST /api/query` | `ccpc.execute(cuerpoJSON)` | Enviar el objeto de consulta y conservar su respuesta completa. |

Los métodos públicos también exponen `getParticipationSummary(filters)`, `getParticipationBreakdown(filters, dimension)`, `getSupportingRecords(filters)` y `compareElections(filters, years)`. Los filtros son `year`, `entityCodes`, `sexes`, `ageGroups` y `sectionTypes`. Años numéricos; claves INE de dos dígitos como cadenas. Las listas son OR dentro de una dimensión y AND entre dimensiones; omitir una dimensión incluye las categorías observadas. Lee las categorías exactas del catálogo.

Ejemplos de cuerpos para `POST /api/query`, probados sobre la entrega:

```json
{"query":"getParticipationSummary","filters":{"year":2024,"entityCodes":["19"]}}
```

```json
{"query":"getParticipationBreakdown","filters":{"year":2024,"entityCodes":["19"]},"dimension":"sex"}
```

```json
{"query":"getSupportingRecords","filters":{"year":2024,"entityCodes":["19"]}}
```

```json
{"query":"compareElections","filters":{"entityCodes":["19"]},"years":[2021,2024]}
```

Comparaciones: entre dos y seis años únicos; no añadir `filters.year`. Desgloses soportados: `entity`, `year`, `sex`, `ageGroup`, `sectionType`; resumen, soporte y desglose consultan un solo año. El desglose `year` no convierte una consulta en comparación histórica. Pasa explícitamente el año seleccionado: si falta en una consulta de un solo año, se utiliza el predeterminado del catálogo.

## 4. Qué conectar en el frontend

Conserva el cliente compartido: en un frontend TypeScript importa `createCatalogClient` desde `src/client/coverage-client.ts`; en un navegador sin compilación sirve la copia JavaScript **exacta** `examples/data05/coverage-client.js`, como hace la demostración. Esa copia fue verificada contra el comportamiento del cliente de backend. No reescribas la matriz ni una lista paralela de categorías.

Ejemplo de inicialización en el navegador, con el módulo JavaScript servido como `/coverage-client.js`:

```js
import { createCatalogClient } from '/coverage-client.js';

const [catalogResponse, metadataResponse] = await Promise.all([
  fetch('/api/capabilities'), fetch('/api/dataset'),
]);
if (!catalogResponse.ok || !metadataResponse.ok) {
  throw new Error('No se pudo cargar la publicación de datos');
}
const client = createCatalogClient(await catalogResponse.json());
const metadata = await metadataResponse.json();
const filters = { year: 2024, entityCodes: ['19'] };
const suggestions = client.getOnboardingQuestions(filters, 6);
// Cada sugerencia ya contiene request. Enviarlo sin traducir ni completar cifras.
const request = suggestions[0]?.request;
if (request) {
  const response = await fetch('/api/query', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify(request),
  });
  if (!response.ok) throw new Error('No se pudo completar la consulta');
  const envelope = await response.json();
  console.log(envelope.status, envelope.result, metadata.warnings);
}
```

Construye los selectores con `catalog.dimensions` y el onboarding con `getOnboardingQuestions(filters)`. Puedes evaluar una petición con `client.evaluate(request)` antes de enviarla; el backend vuelve a comprobarla. Sirve y consulta estos recursos desde el mismo origen o configura expresamente el proxy/CORS del proyecto; la demostración incluida ya usa un solo origen.

Muestra desde `metadata` la versión, `source.landingUrl`, `source.manualUrl`, las fórmulas de `methodology`, `extraction` y todos los mensajes de `warnings`. El ejemplo completo `examples/data06/index.html` los recibe de `GET /api/dataset` en cada carga. No sustituyas esos metadatos dinámicos por texto independiente que pueda quedar desactualizado.

Para mostrar resultados, conserva `status`, `coverage`, `catalog`, `release`, `result.evidence` y advertencias. La estructura exacta de `result` varía entre las cuatro consultas; no se presupone `result.totals` para todas. En resumen, los indicadores oficiales están en `result.totals.ccpcParticipationPct` y `result.totals.ccpcAbstentionPct`.

## 5. Reglas que deben mantenerse

- **Indicadores oficiales:** `ccpcParticipationPct = 100 × SV/(SV+NV)` y `ccpcAbstentionPct = 100 × NV/(SV+NV)`. Se suman conteos antes de dividir. NS se conserva separado. Los campos heredados `participationPct`, `abstentionPct`, `participationRate` y `abstentionRate` usan LN; no son el indicador oficial. Para diferencias oficiales de elecciones usa los campos de comparación `ccpc…PercentagePoints`, no diferencias nominales ni variaciones relativas heredadas.
- **Ausencia frente a cero:** `status: 'no_data'` lleva `result: null`. Muestra un estado sin datos, sin convertirlo en 0%. Un 0% observado con denominador positivo sigue siendo un dato válido; una métrica `null` tiene otra semántica y no debe transformarse en cero. Las selecciones dispersas conservan sus advertencias: no se completan cruces ausentes.
- **Ámbito:** seis años (2009, 2012, 2015, 2018, 2021, 2024), 32 entidades, sexo, 18 grupos de edad y tres tipos de sección. `no_binario` sólo aparece en 2024; una comparación que lo solicita antes de ese año es inválida. Tipo de sección no es clave de sección. No se responde por municipio, partido, candidatura, edad exacta, causas ni predicciones.
- **Privacidad:** no contiene identificadores personales directos; sí hay celdas pequeñas. No presentar la auditoría como certificación de anonimato absoluto.
- **Congelación:** 1.0.0 está fijada antes del 26 de octubre de 2026, zona America/Monterrey. Ningún cambio de datos o esquema debe publicarse con el mismo pin y versión; requiere otra versión revisada. No ejecutar constructores históricos con actualización de pins sobre esta carpeta para hacer una modificación pasar por 1.0.0.

## 6. Reproducción y evidencia

El paquete conserva `docs/data04-reproduction.md`, `docs/data05-coverage.md`, `docs/data06-release.md` y los scripts de regeneración. Para reconstruir el manifiesto, metadatos, diccionario y bloqueo a partir de las entradas fijadas, usa un directorio externo vacío:

```sh
npm run ccpc:release:regenerate -- --output /ruta/absoluta/staging-vacio
```

Este comando compara bytes y no altera la publicación. No relee los 54 millones de registros. Para reconstruir los conteos desde los seis ZIP oficiales consulta DATA-04; la disponibilidad futura del INE y una nueva fecha de descarga son condiciones separadas. Los archivos originales y dependencias no se distribuyen en el ZIP final.

La auditoría de integración adjunta conserva código y reporte `evidencias/handoff/smoke.mjs`, `http-smoke.json` y `http-smoke.log` (su ubicación final puede indicarse en el índice de auditoría). Verifica en una copia extraída: cuatro consultas, catálogo byte a byte, cliente JavaScript compartido, siete sugerencias respondibles, dos escenarios `no_data`, un 0% observado, metadatos con nueve advertencias y respuestas HTTP iguales al servicio en memoria. Se lanzó el servidor desde `/tmp` con puerto local aleatorio; no ejecutó ETL. La conexión posterior con el proyecto real del equipo debe probarse en ese repositorio antes del despliegue.

Desde la raíz del ZIP consolidado puedes repetir ese smoke test, después de instalar dependencias del módulo:

```sh
node evidencias/handoff/smoke.mjs ./Ine-hacktoon-DATA-06
```

El script abre un puerto temporal en `127.0.0.1`, lo cierra al terminar y guarda `http-smoke.json` junto a su propio archivo. La comprobación principal e inmutable del módulo sigue siendo `npm run ccpc:check` y `npm run ccpc:verify-delivery` dentro de su carpeta.
