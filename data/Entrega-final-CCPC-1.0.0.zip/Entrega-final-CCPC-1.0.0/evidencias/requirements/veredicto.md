# Auditoría independiente de requisitos DATA-04, DATA-05 y DATA-06

Resultado: **aprobado para el paquete de Datos 1.0.0 y sus adaptadores/demostración incluidos**. No se identificaron errores bloqueantes de datos o consultas. Los 26 puntos de checklist (8 + 9 + 9) están implementados. Los 11 criterios de aceptación se satisfacen bajo el contrato del módulo entregado, con el alcance externo que se describe abajo.

Esta auditoría fue de sólo lectura sobre `outputs/Ine-hacktoon-DATA-06` y su ZIP. No se editaron datos, manifiestos, esquemas, pins, documentación o ZIP publicados.

## Comprobaciones nuevas, independientes de los generadores

- Python estándar reconstruyó desde las 20,755 tuplas el producto cartesiano de 31,104 posiciones: 20,755 observadas y 10,349 ausentes, idéntico a la matriz y al CSV de ausencias publicados. Reconstruyó las 77,760 comparaciones atómicas: 51,749 válidas y 26,011 inválidas.
- Se verificaron seis años exactos, 32 entidades por año, 192 fuentes, 18 grupos de edad, tres tipos de sección, categorías de sexo por año y 54,872,712 filas de procedencia. Se comprobaron unicidad de claves e invariante LN = SV + NV + NS en todas las tuplas.
- Se compararon 23 archivos esenciales DATA-04 con el ZIP de esa etapa, y nueve archivos esenciales DATA-05 con su ZIP: todos conservan sus bytes. Se incluyen el full, la muestra identificada, los dominios/puertos/servicios originales, el catálogo, el cliente y el adaptador de cobertura.
- Se ejecutó el punto de entrada final real `createFrozenParticipationService` desde la extracción limpia con Node 26.7.0: 192 resúmenes entidad/año coinciden con una suma independiente de los conteos y las fórmulas oficiales SV/(SV+NV) y NV/(SV+NV).
- Las **10,349 selecciones atómicas ausentes** se ejecutaron contra el servicio final: todas retornaron `no_data`, `result: null` y cero sugerencias de onboarding. Las cuatro consultas funcionan; una comparación no binaria 2021/2024 devuelve `no_data` y una participación observada de 0% permanece `ok`.
- El manifiesto 1.0.0 fija 13 artefactos y 14 archivos de contratos. Se comprobaron tamaños y SHA-256 de todos. El backend espera la verificación antes de crear el servicio y antes de `listen`. La congelación es incondicional, anterior al límite del 26 de octubre de 2026; los cambios de bytes se rechazan como 1.0.0.
- El frontend de referencia obtiene `/api/dataset` y `/api/capabilities`, usa el mismo evaluador y presenta las métricas `ccpc*` oficiales. El endpoint entrega fuente oficial, metodología, nueve advertencias, extracción con precisión de día y límites de privacidad. La UI limpia métricas/sugerencias anteriores al cambiar a una selección ausente.
- El ZIP tiene CRC correcto, 190 archivos, sin originales, dependencias o repositorio Git. Todos sus miembros coinciden byte a byte con el directorio final. SHA-256: `1799bba4821927f92e649e27d190adbdde8c5d84859f5e3c3309159e6d035545`.

El nuevo recorrido no releyó los 54 millones de registros originales. La verificación de esos registros y la reproducción completa del ETL se realizó en la auditoría DATA-04 anterior. La conservación byte a byte del full vincula esa evidencia con la entrega actual. Los originales se excluyen correctamente de la distribución.

## Observaciones heredadas y su efecto actual

1. El auditor Python aislado DATA-04 aún admite campos superiores desconocidos y no compara el SHA del compacto con el pin externo. Una copia coordinadamente alterada de sus manifiestos podría dar PASS en esa herramienta aislada. **No permite servir datos alterados mediante el servicio final**: el arranque congelado comprueba el manifiesto externo, el hash de cada artefacto y después el cargador estricto; el auditor independiente DATA-06 también fija esos hashes. No utilizar el auditor DATA-04 aislado como criterio de aceptación de la entrega final.
2. El constructor histórico `build-full-package.ts` aún valida fechas con `Date.parse` sin roundtrip y puede aceptar fechas calendáricas imposibles. La fecha publicada actual es válida. Este constructor no es el flujo de regeneración 1.0.0; el flujo final valida primero los bytes congelados y reproduce los metadatos fijados. No ejecutar `--update-release-pin` para modificar una versión congelada.
3. El mínimo Python se corrigió en el README vigente: **Python >=3.10**. Los documentos DATA-04 se conservan como contexto histórico. El runtime de consultas sólo necesita Node/npm.

Estas observaciones están documentadas y no bloquean el uso de la publicación congelada. Corregirlas después de congelar código perteneciente al bloqueo exige otra versión/pin cuando corresponda; no debe cambiarse silenciosamente 1.0.0.

## Alcance y entrega al equipo

- Entregar el ZIP DATA-06 v1.0.0 completo y su checksum externo. Incluye DATA-04, DATA-05, DATA-06, datos full, catálogo, código, lockfile, scripts, pruebas, diccionario, metadatos y evidencias; no hacen falta tres ZIP acumulativos.
- Instalar mediante `npm ci --ignore-scripts`, comprobar `npm run ccpc:check` y `npm run ccpc:verify-delivery`, y ejecutar `npm run ccpc:demo` para la demostración local en `http://127.0.0.1:4186`.
- Bryan debe iniciar `await createFrozenParticipationService()` antes de escuchar solicitudes. La integración debe distribuir los artefactos y los archivos fijados con sus rutas; el verificador necesita comprobarlos al arrancar.
- El frontend real debe conectar los endpoints o el catálogo/evaluador compartidos, respetar `no_data` y usar `ccpcParticipationPct` y `ccpcAbstentionPct` para indicadores oficiales. Los campos históricos sobre LN siguen siendo intencionadamente distintos.
- No se proporcionaron los repositorios externos del frontend o backend del equipo. Su integración/despliegue real no se ejecutó aquí. El artefacto local versionado está listo; no se creó etiqueta ni release remoto de GitHub. Una demostración local verificada no prueba que esos repositorios externos ya estén conectados.

## Evidencia de esta auditoría

- `independent-requirements.json` y `independent_requirements.py`: comprobaciones independientes de datos, catálogo, conservación y distribución.
- `runtime-requirements.json` y `runtime-requirements.ts`: ejecuciones nuevas del servicio congelado.

Las ejecuciones completas de instalación limpia, suite de pruebas, regeneración, integridad y entrega se coordinan por el agente principal en la misma auditoría final, sin duplicarlas aquí.
