import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { resolve, sep } from 'node:path';

const root = resolve(process.argv[2] ?? fileURLToPath(new URL('./extract/Ine-hacktoon-DATA-06/', import.meta.url))) + sep;
const { createFrozenParticipationService } = await import(pathToFileURL(root + 'src/data/dataset-v1.ts').href);
const { createCatalogClient } = await import(pathToFileURL(root + 'examples/data05/coverage-client.js').href);
const service = await createFrozenParticipationService({ root });
const catalog = service.getCatalog();
const client = createCatalogClient(catalog);
const requests = [
  { query: 'getParticipationSummary', filters: { year: 2024, entityCodes: ['19'] } },
  { query: 'getParticipationBreakdown', filters: { year: 2024, entityCodes: ['19'] }, dimension: 'sex' },
  { query: 'getSupportingRecords', filters: { year: 2024, entityCodes: ['19'] } },
  { query: 'compareElections', filters: { entityCodes: ['19'] }, years: [2021, 2024] },
  { query: 'getParticipationSummary', filters: { year: 2024, entityCodes: ['03'], sexes: ['no_binario'] } },
  { query: 'compareElections', filters: { sexes: ['no_binario'] }, years: [2021, 2024] },
  { query: 'getParticipationSummary', filters: { year: 2024, entityCodes: ['02'], sexes: ['mujer'], ageGroups: ['100+'], sectionTypes: ['mixta'] } },
];
const results = requests.map((request, i) => {
  const local = client.evaluate(request), backend = service.execute(request);
  assert.deepEqual(local, backend.coverage);
  assert.equal(backend.status, i === 4 || i === 5 ? 'no_data' : 'ok');
  assert.equal(backend.release.datasetVersion, '1.0.0');
  if (i === 4 || i === 5) assert.equal(backend.result, null);
  if (i === 6) { assert.equal(backend.result.totals.ccpcParticipationPct, 0); assert.equal(backend.result.totals.ccpcAbstentionPct, 100); }
  return { request, status: backend.status, reason: backend.coverage.reason, release: backend.release,
    ...(i === 6 ? { totals: backend.result.totals } : {}) };
});
const onboarding = client.getOnboardingQuestions({ year: 2024, entityCodes: ['19'] }, 10);
assert(onboarding.length > 0);
for (const question of onboarding) assert.equal(service.execute(question.request).status, 'ok');
assert.equal(client.getOnboardingQuestions({ year: 2024, entityCodes: ['03'], sexes: ['no_binario'] }).length, 0);
const catalogBytes = await readFile(root + 'data/ccpc/catalog/capabilities.json');
assert.equal(Buffer.from(JSON.stringify(catalog, null, 2) + '\n').compare(catalogBytes), 0);
const metadata = service.getDatasetMetadata();
assert.equal(metadata.source.publisher, 'Instituto Nacional Electoral');
assert.equal(metadata.warnings.length, 9);

const child = spawn(process.execPath, [root + 'scripts/ccpc/serve-dataset-v1.ts'], {
  cwd: '/tmp', env: { ...process.env, CCPC_RELEASE_PORT: '0' }, stdio: ['ignore', 'pipe', 'pipe'],
});
let stderr = '', stdout = '';
child.stderr.on('data', chunk => { stderr += chunk; });
const url = await new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error('Demo did not start: ' + stderr)), 15000);
  child.stdout.on('data', chunk => {
    stdout += chunk;
    const match = stdout.match(/http:\/\/127\.0\.0\.1:\d+/);
    if (match) { clearTimeout(timer); resolve(match[0]); }
  });
  child.on('error', error => { clearTimeout(timer); reject(error); });
  child.on('exit', code => { if (!stdout.match(/http:/)) { clearTimeout(timer); reject(new Error('Demo exited ' + code + ': ' + stderr)); } });
});
try {
  const httpResults = [];
  for (const [path, expected] of [['/api/dataset', metadata], ['/api/capabilities', catalog], ['/api/release', service.getRelease()]]) {
    const response = await fetch(url + path); assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), expected); httpResults.push({ path, statusCode: response.status });
  }
  for (const request of requests) {
    const response = await fetch(url + '/api/query', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(request) });
    assert.equal(response.status, 200); assert.deepEqual(await response.json(), service.execute(request));
  }
  const js = await fetch(url + '/coverage-client.js'); assert.equal(js.status, 200);
  assert.equal(await js.text(), await readFile(root + 'examples/data05/coverage-client.js', 'utf8'));
  const home = await fetch(url + '/'); assert.equal(home.status, 200);
  const html = await home.text();
  assert(html.includes("fetch('/api/dataset')")); assert(html.includes("fetch('/api/capabilities')"));
  assert(html.includes('ccpcParticipationPct')); assert(html.includes('ccpcAbstentionPct'));
  const evidence = { status: 'pass', node: process.version, startingCwd: '/tmp', fullPackageRoot: root,
    checks: { backendQueries: 4, noDataScenarios: 2, matchedFrontendBackendEvaluations: results.length,
      onboardingSuggestions: onboarding.length, onboardingAllAnswerable: true, noDataOnboardingQuestions: 0,
      exactCatalogBytes: true, officialMetricFieldsInUi: true, httpQueryMatchesInMemory: results.length,
      metadataWarnings: metadata.warnings.length, observedZeroPreserved: true, noEtlRun: true },
    identity: { release: results[0].release, catalogSha256: createHash('sha256').update(catalogBytes).digest('hex') },
    results, httpResults, stdout, stderr };
  await writeFile(new URL('./http-smoke.json', import.meta.url), JSON.stringify(evidence, null, 2) + '\n');
  console.log(JSON.stringify(evidence.checks));
} finally { child.kill('SIGTERM'); }
